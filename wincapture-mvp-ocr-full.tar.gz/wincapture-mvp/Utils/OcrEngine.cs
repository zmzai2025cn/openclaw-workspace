using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using Tesseract;

namespace WinCaptureMVP.Utils
{
    public static class OcrEngine
    {
        private static bool _isInitialized = false;
        private static string _tesseractDataPath = "";

        static OcrEngine()
        {
            Initialize();
        }

        private static void Initialize()
        {
            try
            {
                // 获取程序所在目录
                var exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? "";
                _tesseractDataPath = Path.Combine(exePath, "tessdata");

                // 检查语言包是否存在
                var chiSimPath = Path.Combine(_tesseractDataPath, "chi_sim.traineddata");
                var engPath = Path.Combine(_tesseractDataPath, "eng.traineddata");

                if (File.Exists(chiSimPath) || File.Exists(engPath))
                {
                    _isInitialized = true;
                    Console.WriteLine($"OCR 初始化成功，数据路径: {_tesseractDataPath}");
                }
                else
                {
                    Console.WriteLine($"OCR 语言包未找到: {_tesseractDataPath}");
                    _isInitialized = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OCR 初始化失败: {ex.Message}");
                _isInitialized = false;
            }
        }

        public static string Recognize(Bitmap image)
        {
            if (!_isInitialized)
            {
                return "";
            }

            if (image == null)
            {
                return "";
            }

            try
            {
                // 将 Bitmap 转换为 Pix
                using (var pix = ConvertBitmapToPix(image))
                {
                    if (pix == null)
                    {
                        return "";
                    }

                    // 尝试中文识别，失败则用英文
                    string result = RecognizeWithLanguage(pix, "chi_sim+eng");
                    
                    return result?.Trim() ?? "";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OCR 识别失败: {ex.Message}");
                return "";
            }
        }

        private static string RecognizeWithLanguage(Pix pix, string lang)
        {
            try
            {
                using (var engine = new TesseractEngine(_tesseractDataPath, lang, EngineMode.Default))
                {
                    engine.SetVariable("tessedit_char_whitelist", "");
                    
                    using (var page = engine.Process(pix))
                    {
                        return page.GetText();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OCR {lang} 识别失败: {ex.Message}");
                return "";
            }
        }

        private static Pix? ConvertBitmapToPix(Bitmap bitmap)
        {
            try
            {
                // 保存为内存流，然后加载为 Pix
                using (var ms = new MemoryStream())
                {
                    // 转换为 24bpp RGB 格式（Tesseract 推荐）
                    using (var rgbBitmap = new Bitmap(bitmap.Width, bitmap.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb))
                    {
                        using (var g = Graphics.FromImage(rgbBitmap))
                        {
                            g.DrawImage(bitmap, 0, 0);
                        }
                        rgbBitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    }
                    
                    ms.Position = 0;
                    return Pix.LoadFromMemory(ms.ToArray());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"转换图片失败: {ex.Message}");
                return null;
            }
        }

        public static bool IsInitialized => _isInitialized;
    }
}
# Tesseract OCR 内嵌说明

## 文件结构

程序发布后，需要在 EXE 同级目录创建以下结构：

```
publish/
├── WinCaptureMVP.exe
├── tessdata/                    # Tesseract 语言包目录
│   ├── chi_sim.traineddata     # 中文语言包（必需）
│   ├── eng.traineddata         # 英文语言包（必需）
│   └── ...                     # 其他语言包（可选）
└── ...
```

## 下载语言包

### 中文语言包
- 下载地址：https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata
- 文件大小：约 40MB
- 版本：4.1.0+

### 英文语言包
- 下载地址：https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata
- 文件大小：约 4MB
- 版本：4.1.0+

## 打包步骤

1. 编译程序
   ```powershell
   dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
   ```

2. 创建 tessdata 目录
   ```powershell
   mkdir .\bin\Release\net6.0-windows\win-x64\publish\tessdata
   ```

3. 下载语言包到 tessdata 目录

4. 最终结构检查
   - WinCaptureMVP.exe
   - tessdata/chi_sim.traineddata
   - tessdata/eng.traineddata

## 体积估算

| 组件 | 大小 |
|------|------|
| 程序本身 | ~5MB |
| Tesseract 依赖 | ~15MB |
| 中文语言包 | ~40MB |
| 英文语言包 | ~4MB |
| **总计** | **~64MB** |

## 注意事项

1. 语言包版本必须与 Tesseract 版本匹配（4.1.0+）
2. 首次运行可能需要几秒钟加载语言包
3. OCR 识别会占用一定 CPU 和内存
4. 中文识别准确率约 85-90%，取决于屏幕清晰度

## 离线安装包制作

如需制作完整离线安装包：

```powershell
# 1. 编译
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true

# 2. 下载语言包
Invoke-WebRequest -Uri "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata" -OutFile ".\bin\Release\net6.0-windows\win-x64\publish\tessdata\chi_sim.traineddata"
Invoke-WebRequest -Uri "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata" -OutFile ".\bin\Release\net6.0-windows\win-x64\publish\tessdata\eng.traineddata"

# 3. 打包
Compress-Archive -Path ".\bin\Release\net6.0-windows\win-x64\publish\*" -DestinationPath "WinCaptureMVP-OCR-Complete.zip"
```

最终得到一个约 65MB 的完整安装包。
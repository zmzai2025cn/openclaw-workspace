using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace WinCaptureMVP.Config
{
    public sealed class UserConfig
    {
        public string UserId { get; set; } = string.Empty;
        public string DeviceId { get; set; } = Guid.NewGuid().ToString("N");
        public string DataDirectory { get; set; } = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), 
            "WinCaptureMVP");
        public List<string> WhiteList { get; set; } = new List<string>();

        private static string ConfigPath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "WinCaptureMVP",
            "config.json");

        public static UserConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var config = JsonSerializer.Deserialize<UserConfig>(json);
                    if (config != null)
                    {
                        config.UserId ??= string.Empty;
                        config.DeviceId ??= Guid.NewGuid().ToString("N");
                        config.DataDirectory ??= Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "WinCaptureMVP");
                        config.WhiteList ??= new List<string>();
                        return config;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config load failed: {ex.Message}");
            }
            return new UserConfig();
        }

        public void Save()
        {
            try
            {
                var dir = Path.GetDirectoryName(ConfigPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                var json = JsonSerializer.Serialize(this, new JsonSerializerOptions 
                { 
                    WriteIndented = true 
                });
                File.WriteAllText(ConfigPath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config save failed: {ex.Message}");
            }
        }
    }
}

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace WinCaptureMVP.Utils
{
    public static class OcrEngine
    {
        private static readonly object InitLock = new object();
        private static bool _isInitialized;
        private static PaddleOCRSharp.PaddleOCREngine? _ocrEngine;
        private static string _logPath = Path.Combine(AppContext.BaseDirectory, "ocr_log.txt");

        static OcrEngine()
        {
            Initialize();
        }

        private static void Log(string message)
        {
            try
            {
                File.AppendAllText(_logPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}\n");
            }
            catch { }
        }

        private static void Initialize()
        {
            lock (InitLock)
            {
                if (_isInitialized) return;

                try
                {
                    var exePath = GetExecutableDirectory();
                    var modelPath = Path.Combine(exePath, "paddleocr_models");

                    Log($"Exe path: {exePath}");
                    Log($"Model path: {modelPath}");

                    var detPath = Path.Combine(modelPath, "ch_PP-OCRv4_det_infer");
                    var recPath = Path.Combine(modelPath, "ch_PP-OCRv4_rec_infer");
                    var clsPath = Path.Combine(modelPath, "ch_ppocr_mobile_v2.0_cls_infer");
                    var keysPath = Path.Combine(modelPath, "ppocr_keys.txt");

                    Log($"det exists: {Directory.Exists(detPath)}");
                    Log($"rec exists: {Directory.Exists(recPath)}");
                    Log($"cls exists: {Directory.Exists(clsPath)}");
                    Log($"keys exists: {File.Exists(keysPath)}");

                    if (!Directory.Exists(detPath) || !Directory.Exists(recPath) || !File.Exists(keysPath))
                    {
                        Log("PaddleOCR models not found");
                        return;
                    }

                    var config = new PaddleOCRSharp.OCRModelConfig
                    {
                        det_infer = detPath,
                        rec_infer = recPath,
                        cls_infer = clsPath,
                        keys = keysPath
                    };

                    var parameter = new PaddleOCRSharp.OCRParameter
                    {
                        cpu_math_library_num_threads = 4,
                        enable_mkldnn = true,
                        cls = true,
                        use_angle_cls = true,
                        det_db_thresh = 0.3f,
                        det_db_box_thresh = 0.5f,
                        det_db_unclip_ratio = 2.0f,
                        max_side_len = 2000
                    };

                    Log("Creating PaddleOCREngine...");
                    _ocrEngine = new PaddleOCRSharp.PaddleOCREngine(config, parameter);
                    _isInitialized = true;
                    Log("PaddleOCR initialized successfully");
                }
                catch (Exception ex)
                {
                    Log($"PaddleOCR init failed: {ex.Message}");
                    Log($"Stack trace: {ex.StackTrace}");
                }
            }
        }

        private static string GetExecutableDirectory()
        {
            try
            {
                var mainModule = System.Diagnostics.Process.GetCurrentProcess().MainModule;
                if (mainModule?.FileName != null)
                {
                    return Path.GetDirectoryName(mainModule.FileName) ?? AppContext.BaseDirectory;
                }
            }
            catch (Exception ex)
            {
                Log($"GetExecutableDirectory failed: {ex.Message}");
            }
            return AppContext.BaseDirectory;
        }

        public static string? Recognize(Bitmap? image)
        {
            if (!_isInitialized || _ocrEngine == null || image == null)
            {
                Log($"Recognize skipped: initialized={_isInitialized}, engine={_ocrEngine != null}, image={image != null}");
                return null;
            }

            try
            {
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    image.Save(ms, ImageFormat.Png);
                    imageBytes = ms.ToArray();
                }

                var result = _ocrEngine.DetectText(imageBytes);
                var text = result?.Text?.Trim();
                Log($"OCR result length: {text?.Length ?? 0}");
                return text;
            }
            catch (Exception ex)
            {
                Log($"OCR failed: {ex.Message}");
                return null;
            }
        }

        public static void Dispose()
        {
            lock (InitLock)
            {
                _ocrEngine?.Dispose();
                _ocrEngine = null;
                _isInitialized = false;
                Log("OCR engine disposed");
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;

namespace WinCaptureMVP.Sanitizer
{
    public static class AppFilter
    {
        private static readonly HashSet<string> DefaultWhiteList = new HashSet<string>
        {
            "visual studio code", "vscode",
            "visual studio",
            "intellij idea",
            "eclipse",
            "chrome", "edge", "firefox",
            "outlook",
            "word", "excel", "powerpoint",
            "terminal", "cmd", "powershell",
            "docker",
            "git",
            "slack", "teams", "feishu", "dingtalk"
        };

        private static readonly HashSet<string> DefaultBlackList = new HashSet<string>
        {
            "wechat", "微信",
            "qq",
            "game",
            "steam",
            "netflix",
            "youtube"
        };

        public static bool IsAllowed(string appName, List<string> customWhiteList)
        {
            if (string.IsNullOrEmpty(appName)) return false;

            var lowerName = appName.ToLower();

            // 黑名单优先
            if (DefaultBlackList.Any(b => lowerName.Contains(b)))
                return false;

            // 白名单检查
            var whiteList = customWhiteList?.Count > 0 ? customWhiteList : DefaultWhiteList.ToList();
            return whiteList.Any(w => lowerName.Contains(w.ToLower()));
        }
    }
}
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace WinCaptureMVP.Config
{
    public class UserConfig
    {
        public string UserId { get; set; } = "";
        public string DeviceId { get; set; } = Guid.NewGuid().ToString("N");
        public string ServerUrl { get; set; } = "";
        public string EncryptionKey { get; set; } = "default-key-change-in-production";
        public string DataDirectory { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WinCaptureMVP");
        public List<string> WhiteList { get; set; } = new List<string>();
        public int CpuThreshold { get; set; } = 10;
        public int MemoryThreshold { get; set; } = 100; // MB

        private static string ConfigPath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "WinCaptureMVP",
            "config.json"
        );

        public static UserConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    return JsonSerializer.Deserialize<UserConfig>(json) ?? new UserConfig();
                }
            }
            catch { }

            return new UserConfig();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath));
                var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(ConfigPath, json);
            }
            catch { }
        }
    }
}
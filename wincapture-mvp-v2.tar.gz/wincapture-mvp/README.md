# Windows 采集端 MVP

## 项目结构

```
WinCaptureMVP/
├── Program.cs                 # 入口
├── CaptureEngine.cs           # 采集引擎
├── Triggers/                  # 触发器
│   ├── ITrigger.cs
│   ├── WindowSwitchTrigger.cs
│   ├── PixelDiffTrigger.cs
│   └── IntervalTrigger.cs
├── Sanitizer/                 # 脱敏
│   ├── ImageSanitizer.cs
│   ├── FaceBlur.cs
│   └── AppFilter.cs
├── Storage/                   # 存储
│   └── UploadQueue.cs
├── UI/                        # 界面
│   ├── TrayIcon.cs
│   └── ConfigForm.cs
├── Utils/                     # 工具
│   ├── ScreenCapture.cs
│   ├── ImageDiff.cs
│   ├── PerformanceMonitor.cs
│   └── WindowHelper.cs
├── Config/                    # 配置
│   └── UserConfig.cs
└── WinCaptureMVP.csproj
```

## 功能

- 3级触发：窗口切换、像素差分、定时兜底
- 分层脱敏：人脸模糊、AES加密、应用过滤
- 本地缓存：SQLite队列，弱网支持
- 托盘运行：无界面后台运行

## 构建

```bash
dotnet publish -c Release
```

输出：`bin/Release/net6.0-windows/win-x64/publish/WinCaptureMVP.exe`
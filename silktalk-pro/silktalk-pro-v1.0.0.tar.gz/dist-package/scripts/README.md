# SilkTalk Pro Deployment Scripts

## Quick Start

```bash
# Install dependencies
npm install

# Build the project
npm run build

# Run tests
npm test
```

## Docker Deployment

### Build Docker Image

```bash
docker build -t silktalk-pro:latest .
```

### Run Docker Container

```bash
docker run -d \
  --name silktalk \
  -p 4001:4001 \
  -p 8080:8080 \
  -v silktalk-data:/data \
  silktalk-pro:latest
```

## Systemd Service (Linux)

```bash
# Copy service file
sudo cp scripts/silktalk.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable and start service
sudo systemctl enable silktalk
sudo systemctl start silktalk

# Check status
sudo systemctl status silktalk
```

## Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

## Environment Setup

```bash
# Create data directory
mkdir -p ~/.silktalk

# Initialize config
npm start -- config init

# Edit config
npm start -- config set listenAddresses '["/ip4/0.0.0.0/tcp/4001"]'
```

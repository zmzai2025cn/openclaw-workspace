# SilkTalk Pro - Enterprise P2P Communication System

## Overview

SilkTalk Pro is an enterprise-grade peer-to-peer communication system designed to operate in any network environment without manual configuration. It leverages the full power of libp2p to provide seamless connectivity across LAN, WAN, NAT, and firewall-restricted networks.

## Key Features

- **Universal Connectivity**: Works in any network environment
  - LAN (mDNS discovery)
  - WAN (TCP direct)
  - NAT traversal (STUN/TURN)
  - Firewall bypass (WebSocket/WSS)
  - Relay fallback (Circuit Relay v2)
  - DHT routing (Kademlia, no bootstrap needed)

- **Auto Configuration**: Zero manual setup required
  - AutoNAT for network type detection
  - Automatic transport selection
  - Best path selection

- **Enterprise Ready**: Production-grade reliability
  - TypeScript strict mode
  - Comprehensive test coverage (>80%)
  - Full observability
  - Security hardened

## Quick Start

```bash
# Install dependencies
npm install

# Build
npm run build

# Start a node
npm start -- --port 0 --ws-port 8080

# Or in development mode
npm run dev -- --port 0 --ws-port 8080
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md) - System design and data flow
- [Protocol](docs/PROTOCOL.md) - Message protocol specification
- [Network](docs/NETWORK.md) - Network strategies and NAT traversal
- [API](docs/API.md) - Public API documentation
- [Deployment](docs/DEPLOYMENT.md) - Deployment guide
- [Testing](docs/TESTING.md) - Testing strategy
- [Security](docs/SECURITY.md) - Security considerations
- [Changelog](docs/CHANGELOG.md) - Version history

## Project Structure

```
silktalk-pro/
├── src/
│   ├── core/           # Core modules (node, identity, config)
│   ├── network/        # Network layer (transports, connection manager)
│   ├── protocol/       # Protocol layer (messaging, serialization)
│   ├── routing/        # Routing layer (DHT, discovery)
│   ├── bridge/         # OpenClaw bridge integration
│   └── cli/            # Command-line interface
├── tests/
│   ├── unit/           # Unit tests
│   ├── integration/    # Integration tests
│   └── e2e/            # End-to-end tests
├── docs/               # Documentation
├── scripts/            # Deployment scripts
└── config/             # Configuration files
```

## License

MIT

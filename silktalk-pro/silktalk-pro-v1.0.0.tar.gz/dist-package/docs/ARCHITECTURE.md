# Architecture

## System Overview

SilkTalk Pro is built on a layered architecture that separates concerns while maintaining tight integration between components.

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Layer                         │
│              (CLI, Bridge, User Applications)                │
├─────────────────────────────────────────────────────────────┤
│                    Protocol Layer                            │
│         (Message Protocol, Serialization, Encryption)        │
├─────────────────────────────────────────────────────────────┤
│                     Routing Layer                            │
│           (DHT, Peer Discovery, Content Routing)             │
├─────────────────────────────────────────────────────────────┤
│                     Network Layer                            │
│    (Transport Manager, Connection Manager, NAT Traversal)    │
├─────────────────────────────────────────────────────────────┤
│                      Core Layer                              │
│         (Node Lifecycle, Identity, Configuration)            │
└─────────────────────────────────────────────────────────────┘
```

## Layer Descriptions

### Core Layer

The foundation of the system, responsible for:
- **Node Lifecycle**: Starting, stopping, and managing the libp2p node
- **Identity**: Cryptographic key generation and management
- **Configuration**: Environment-aware configuration management

### Network Layer

Handles all network connectivity concerns:
- **Transport Manager**: Manages multiple transports (TCP, WebSocket, WebRTC)
- **Connection Manager**: Maintains optimal connection pool, handles reconnection
- **NAT Traversal**: STUN/TURN, UPnP, AutoNAT for network detection
- **Circuit Relay**: Fallback relay connections when direct connection fails

### Routing Layer

Peer and content discovery:
- **Kademlia DHT**: Distributed hash table for peer routing
- **mDNS**: Local network discovery
- **Bootstrap**: Initial peer discovery (optional)

### Protocol Layer

Application-level communication:
- **Message Protocol**: Structured message format
- **Serialization**: Protocol Buffers / CBOR
- **Encryption**: End-to-end encryption for messages

### Application Layer

User-facing interfaces:
- **CLI**: Command-line interface for node management
- **Bridge**: OpenClaw integration for external communication

## Data Flow

### Outgoing Message

```
Application
    ↓
Protocol Layer (serialize, encrypt)
    ↓
Routing Layer (find peer route)
    ↓
Network Layer (select transport, establish connection)
    ↓
Wire (TCP/WebSocket/Relay)
```

### Incoming Message

```
Wire (TCP/WebSocket/Relay)
    ↓
Network Layer (demux to protocol)
    ↓
Protocol Layer (decrypt, deserialize)
    ↓
Application Layer (deliver to handler)
```

## Component Interactions

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│     CLI     │────→│  SilkNode   │←────│   Bridge    │
└─────────────┘     └──────┬──────┘     └─────────────┘
                           │
           ┌───────────────┼───────────────┐
           ↓               ↓               ↓
    ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
    │   Network   │ │   Routing   │ │  Protocol   │
    │   Manager   │ │   Manager   │ │   Handler   │
    └──────┬──────┘ └──────┬──────┘ └─────────────┘
           │               │
    ┌──────┴──────┐ ┌──────┴──────┐
    │  Transports │ │     DHT     │
    │  (TCP/WS)   │ │  (Kademlia) │
    └─────────────┘ └─────────────┘
```

## Key Design Decisions

### 1. Multi-Transport Strategy

The system simultaneously listens on multiple transports:
- **TCP**: Default for direct connections
- **WebSocket**: Firewall-friendly, works in restrictive networks
- **Circuit Relay**: Fallback when direct connection impossible

### 2. Connection Manager

Intelligent connection management:
- Maintains minimum viable connection count
- Prioritizes low-latency paths
- Automatically upgrades relay connections to direct when possible (DCUtR)

### 3. Zero Bootstrap Philosophy

The system can operate without bootstrap nodes:
- mDNS for local discovery
- DHT for global discovery
- Optional bootstrap for faster initial connection

### 4. Modular Protocol Stack

Protocols are registered dynamically:
- Core protocols (identify, ping) always enabled
- Optional protocols (DHT, relay) configurable
- Custom protocols can be added without core changes

## Scalability Considerations

### Horizontal Scaling

- Each node is independent
- No central coordinator
- DHT provides O(log n) lookup

### Resource Management

- Connection limits per peer
- Bandwidth throttling (configurable)
- Memory-efficient streaming

## Fault Tolerance

### Connection Resilience

- Automatic reconnection with exponential backoff
- Multiple transport attempts
- Relay fallback for failed direct connections

### Network Partition Handling

- DHT maintains routing table
- mDNS rediscovers local peers
- Bootstrap reconnection on partition heal

## Security Architecture

See [SECURITY.md](SECURITY.md) for detailed security documentation.

Highlights:
- All connections encrypted (Noise protocol)
- Peer identity verified via cryptographic keys
- No plaintext communication

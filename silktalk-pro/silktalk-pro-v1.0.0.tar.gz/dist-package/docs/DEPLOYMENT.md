# Deployment Guide

## Overview

This guide covers deployment options for SilkTalk Pro, from local development to production environments.

## System Requirements

### Minimum Requirements

- **OS**: Linux, macOS, Windows (WSL2 recommended)
- **Node.js**: 18.0.0 or higher
- **Memory**: 512 MB RAM
- **Storage**: 100 MB disk space
- **Network**: Internet connection (for DHT/bootstrap)

### Recommended Requirements

- **OS**: Linux (Ubuntu 22.04 LTS or newer)
- **Node.js**: 20.x LTS
- **Memory**: 2 GB RAM
- **Storage**: 1 GB disk space
- **Network**: Public IP or UPnP-enabled router

## Installation

### From npm (Recommended)

```bash
npm install -g silktalk-pro
silktalk --version
```

### From Source

```bash
git clone https://github.com/silktalk/silktalk-pro.git
cd silktalk-pro
npm install
npm run build
npm link  # Makes 'silktalk' available globally
```

### Docker

```bash
docker pull silktalk/pro:latest
docker run -p 4001:4001 -p 8080:8080 silktalk/pro:latest
```

## Configuration

### Configuration File

Default location: `~/.silktalk/config.json`

```json
{
  "identity": {
    "privateKeyPath": "~/.silktalk/identity.key"
  },
  "network": {
    "listenAddresses": [
      "/ip4/0.0.0.0/tcp/0",
      "/ip4/0.0.0.0/tcp/8080/ws"
    ],
    "announceAddresses": []
  },
  "transports": {
    "tcp": { "enabled": true },
    "websocket": { "enabled": true }
  },
  "nat": {
    "upnp": true,
    "autonat": true,
    "dcutr": true
  },
  "relay": {
    "enabled": true,
    "hop": {
      "enabled": false,
      "active": false
    },
    "autoRelay": {
      "enabled": true,
      "maxListeners": 2
    }
  },
  "discovery": {
    "mdns": true,
    "dht": true,
    "bootstrap": []
  },
  "connection": {
    "maxConnections": 300,
    "minConnections": 10,
    "maxConnectionsPerPeer": 5
  },
  "logging": {
    "level": "info",
    "pretty": false
  }
}
```

### Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `SILKTALK_LOG_LEVEL` | Logging level | `debug` |
| `SILKTALK_CONFIG_PATH` | Config file path | `/etc/silktalk/config.json` |
| `SILKTALK_DATA_PATH` | Data directory | `/var/lib/silktalk` |
| `SILKTALK_PRIVATE_KEY` | Private key (hex) | `0x...` |

## Deployment Scenarios

### 1. Local Development

```bash
# Quick start with defaults
npm run dev

# Or with specific options
npm run dev -- --port 4001 --ws-port 8080 --log-level debug
```

### 2. Single Node (Personal Use)

```bash
# Create config directory
mkdir -p ~/.silktalk

# Initialize config
silktalk config init

# Start node
silktalk start --port 4001 --ws-port 8080

# Run as systemd service (Linux)
sudo tee /etc/systemd/system/silktalk.service > /dev/null <<EOF
[Unit]
Description=SilkTalk Pro P2P Node
After=network.target

[Service]
Type=simple
User=$USER
ExecStart=$(which silktalk) start --port 4001 --ws-port 8080
Restart=always
RestartSec=10
Environment="SILKTALK_LOG_LEVEL=info"

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable silktalk
sudo systemctl start silktalk
```

### 3. Relay Server

Relay servers help other nodes connect when direct connection fails.

```bash
# Start as relay server
silktalk start \
  --port 4001 \
  --ws-port 8080 \
  --relay-hop \
  --max-connections 1000
```

**Docker Compose**:

```yaml
version: '3.8'

services:
  silktalk-relay:
    image: silktalk/pro:latest
    ports:
      - "4001:4001"
      - "8080:8080"
    command: >
      start
      --port 4001
      --ws-port 8080
      --relay-hop
      --max-connections 1000
      --log-level info
    volumes:
      - ./data:/data
    restart: unless-stopped
```

### 4. Bootstrap Node

Bootstrap nodes help new nodes discover the network.

```bash
# Start as bootstrap node
silktalk start \
  --port 4001 \
  --dht \
  --relay-hop
```

**Kubernetes**:

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: silktalk-bootstrap
spec:
  serviceName: silktalk-bootstrap
  replicas: 3
  selector:
    matchLabels:
      app: silktalk-bootstrap
  template:
    metadata:
      labels:
        app: silktalk-bootstrap
    spec:
      containers:
      - name: silktalk
        image: silktalk/pro:latest
        ports:
        - containerPort: 4001
          name: tcp
        - containerPort: 8080
          name: websocket
        command:
        - silktalk
        - start
        - --port=4001
        - --ws-port=8080
        - --dht
        - --relay-hop
        volumeMounts:
        - name: data
          mountPath: /data
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi
---
apiVersion: v1
kind: Service
metadata:
  name: silktalk-bootstrap
spec:
  selector:
    app: silktalk-bootstrap
  ports:
  - port: 4001
    name: tcp
  - port: 8080
    name: websocket
  clusterIP: None
```

### 5. High Availability Cluster

For production deployments requiring high availability.

```yaml
# docker-compose.ha.yml
version: '3.8'

services:
  silktalk-1:
    image: silktalk/pro:latest
    ports:
      - "4001:4001"
      - "8080:8080"
    command: >
      start
      --port 4001
      --ws-port 8080
      --bootstrap /dns4/silktalk-2/tcp/4001/p2p/Qm...
      --bootstrap /dns4/silktalk-3/tcp/4001/p2p/Qm...
    volumes:
      - node1-data:/data

  silktalk-2:
    image: silktalk/pro:latest
    ports:
      - "4002:4001"
      - "8081:8080"
    command: >
      start
      --port 4001
      --ws-port 8080
      --bootstrap /dns4/silktalk-1/tcp/4001/p2p/Qm...
      --bootstrap /dns4/silktalk-3/tcp/4001/p2p/Qm...
    volumes:
      - node2-data:/data

  silktalk-3:
    image: silktalk/pro:latest
    ports:
      - "4003:4001"
      - "8082:8080"
    command: >
      start
      --port 4001
      --ws-port 8080
      --bootstrap /dns4/silktalk-1/tcp/4001/p2p/Qm...
      --bootstrap /dns4/silktalk-2/tcp/4001/p2p/Qm...
    volumes:
      - node3-data:/data

volumes:
  node1-data:
  node2-data:
  node3-data:
```

## Network Configuration

### Firewall Rules

```bash
# UFW (Ubuntu)
sudo ufw allow 4001/tcp
sudo ufw allow 8080/tcp

# iptables
sudo iptables -A INPUT -p tcp --dport 4001 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 8080 -j ACCEPT

# firewalld (CentOS/RHEL)
sudo firewall-cmd --permanent --add-port=4001/tcp
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

### Port Forwarding

If behind NAT without UPnP, manually forward ports:

```bash
# Check current port mappings
silktalk status

# Configure router to forward:
# External 4001 -> Internal IP:4001
# External 8080 -> Internal IP:8080
```

### Reverse Proxy (Nginx)

For WebSocket connections behind a reverse proxy:

```nginx
server {
    listen 443 ssl;
    server_name silktalk.example.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location /ws {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;
    }
}
```

## Monitoring

### Health Check Endpoint

```bash
# Check node health
curl http://localhost:8080/health

# Expected response
{
  "status": "healthy",
  "peerId": "Qm...",
  "peers": 10,
  "uptime": 3600
}
```

### Prometheus Metrics

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'silktalk'
    static_configs:
      - targets: ['localhost:9090']
```

### Grafana Dashboard

Import dashboard from `config/grafana-dashboard.json`

## Backup and Recovery

### Backup Identity

```bash
# Backup private key
cp ~/.silktalk/identity.key /secure/backup/identity.key

# Or export via CLI
silktalk config get identity.privateKey > /secure/backup/identity.hex
```

### Restore Identity

```bash
# Restore from backup
cp /secure/backup/identity.key ~/.silktalk/identity.key

# Or import via CLI
silktalk config set identity.privateKey $(cat /secure/backup/identity.hex)
```

## Troubleshooting

### Check Node Status

```bash
silktalk status --json
```

### View Logs

```bash
# Systemd journal
sudo journalctl -u silktalk -f

# Docker logs
docker logs -f silktalk
```

### Network Diagnostics

```bash
# Run network diagnostics
silktalk start --diagnose

# Check NAT type
curl https://api.stunprotocol.org/your-ip
```

### Common Issues

| Issue | Solution |
|-------|----------|
| Cannot connect to peers | Check firewall rules, enable UPnP, or use relay |
| High memory usage | Reduce maxConnections, disable DHT if not needed |
| Slow message delivery | Check relay usage, enable DCUtR |
| DHT not finding peers | Add bootstrap nodes, check network connectivity |

## Security Best Practices

1. **Run as non-root user**
2. **Use firewall to restrict access**
3. **Keep private keys secure**
4. **Regularly update to latest version**
5. **Monitor for unusual activity**
6. **Use TLS for WebSocket connections**

# WinCapture OCR - Tesseract 版

## 快速开始

### 1. 编译
```powershell
cd WinCaptureOCR
dotnet build
```

### 2. 下载中文语言包

**方式 A：GitHub 官方（需要翻墙）**
```powershell
mkdir tessdata
Invoke-WebRequest -Uri "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata" -OutFile "tessdata/chi_sim.traineddata"
Invoke-WebRequest -Uri "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata" -OutFile "tessdata/eng.traineddata"
```

**方式 B：国内镜像（推荐）**
```powershell
mkdir tessdata

# Gitee 镜像
Invoke-WebRequest -Uri "https://gitee.com/mirrors/tesseract-ocr-tessdata/raw/main/chi_sim.traineddata" -OutFile "tessdata/chi_sim.traineddata"
Invoke-WebRequest -Uri "https://gitee.com/mirrors/tesseract-ocr-tessdata/raw/main/eng.traineddata" -OutFile "tessdata/eng.traineddata"
```

**方式 C：手动下载**
1. 访问 https://digi.bib.uni-mannheim.de/tesseract/tessdata_fast/
2. 下载 `chi_sim.traineddata`（中文）
3. 下载 `eng.traineddata`（英文）
4. 放到 `tessdata/` 目录

### 3. 运行
```powershell
dotnet run
```

## 目录结构
```
WinCaptureOCR/
├── WinCaptureOCR.csproj
├── Program.cs
└── tessdata/              ← 语言包目录
    ├── chi_sim.traineddata  ← 中文（必须）
    └── eng.traineddata      ← 英文（可选）
```

## 依赖
- .NET 6.0
- Tesseract 5.2.0 (NuGet 自动下载)
- 中文语言包（手动下载）

## 体积
- 程序: ~2MB
- 中文语言包: ~10MB
- 英文语言包: ~4MB
- 总计: ~16MB

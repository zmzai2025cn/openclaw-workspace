# WinCaptureOCR 质量管理要求

## 每次检查前必读

### 1. 依赖完整性检查
- [ ] 所有 NuGet 包已正确引用
- [ ] 所有 DLL 依赖已识别
- [ ] 运行时依赖已列出（VC++、.NET 等）
- [ ] 语言包依赖已说明

### 2. 健壮性检查
- [ ] 所有异常已捕获
- [ ] 资源释放已确保（using/finally）
- [ ] null 检查已添加
- [ ] 边界条件已处理
- [ ] 用户输入已验证

### 3. 发布准备检查
- [ ] 一键发布脚本可用
- [ ] 脚本无需管理员权限
- [ ] 依赖自动下载/检查
- [ ] 错误提示清晰明确

### 4. 测试验证
- [ ] 编译无警告
- [ ] 运行无异常
- [ ] 功能正常
- [ ] 错误处理正常

---

## 常见 DLL 依赖问题

### Tesseract 依赖链
```
WinCaptureOCR.exe
  ├── Tesseract.dll (C# wrapper)
  ├── Tesseract.Drawing.dll
  ├── leptonica-1.82.0.dll (C++ native)
  ├── tesseract50.dll (C++ native)
  └── VC++ 2015-2022 Redistributable
```

### 常见问题
1. **leptonica DLL 未找到** → 安装 VC++ 运行时
2. **x86/x64 不匹配** → 强制 x64 平台
3. **语言包版本不匹配** → 使用 Tesseract 5.x 语言包

---

## 发布前必须完成

1. 一键发布脚本测试通过
2. 在干净环境测试通过
3. 所有依赖自动处理或明确提示

# WinCaptureOCR 项目文档体系

## 文档目的
避免重复劳动，确保知识沉淀，新人快速上手。

## 文档结构

```
WinCaptureOCR/
├── README.md              # 项目简介和快速开始
├── docs/                  # 详细文档
│   ├── 01-QUICKSTART.md   # 5分钟上手
│   ├── 02-ARCHITECTURE.md # 架构设计
│   ├── 03-DEPENDENCIES.md # 依赖管理
│   ├── 04-COMMON-ISSUES.md # 常见问题
│   ├── 05-RELEASE.md      # 发布流程
│   └── 06-CHECKLIST.md    # 检查清单
├── scripts/               # 自动化脚本
│   ├── setup.ps1          # 环境初始化
│   ├── build.ps1          # 编译
│   ├── test.ps1           # 测试
│   └── release.ps1        # 发布
└── templates/             # 模板
    ├── issue-template.md
    └── pr-template.md
```

## 核心原则

### 1. 问题只解决一次
- 遇到的问题 → 记录到 04-COMMON-ISSUES.md
- 解决方案 → 详细记录，包括错误信息和解决步骤
- 避免下次重复踩坑

### 2. 流程标准化
- 每个操作都有脚本
- 每个发布都有检查清单
- 每个依赖都有版本记录

### 3. 知识可传承
- 设计决策 → 记录原因
- 技术选型 → 记录对比
- 经验教训 → 记录总结

## 快速导航

| 我想... | 看这里 |
|---------|--------|
| 快速运行 | README.md |
| 了解架构 | docs/02-ARCHITECTURE.md |
| 解决报错 | docs/04-COMMON-ISSUES.md |
| 发布版本 | docs/05-RELEASE.md + scripts/release.ps1 |
| 添加功能 | docs/06-CHECKLIST.md |

## 维护责任

- 发现问题 → 立即更新 04-COMMON-ISSUES.md
- 流程变更 → 立即更新相关脚本和文档
- 版本发布 → 更新 05-RELEASE.md 记录

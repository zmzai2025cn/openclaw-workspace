# 快速开始 (5分钟上手)

## 环境要求
- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)

## 安装步骤

### 1. 下载项目
```powershell
git clone <仓库地址>
cd WinCaptureOCR
```

### 2. 一键设置
```powershell
.\scripts\setup.ps1
```
自动完成：
- 检查 .NET 版本
- 检查 VC++ 运行时
- 下载语言包（如果未下载）

### 3. 编译运行
```powershell
.\scripts\build.ps1
.\scripts\run.ps1
```

## 常见问题

### 问题1: "找不到 .NET 6.0"
**解决**: 下载安装 https://dotnet.microsoft.com/download/dotnet/6.0

### 问题2: "Tesseract 初始化失败"
**解决**: 安装 VC++ 运行时 https://aka.ms/vs/17/release/vc_redist.x64.exe

### 问题3: "找不到语言包"
**解决**: 运行 `setup.ps1` 自动下载，或手动下载放到 `tessdata/` 目录

## 下一步
- 了解架构: 02-ARCHITECTURE.md
- 开发指南: 03-DEVELOPMENT.md
- 发布流程: 05-RELEASE.md

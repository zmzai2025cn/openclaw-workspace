# Setup script for WinCaptureOCR (ASCII version with debug logging)
# Created: 2026-02-20
# Purpose: Initialize environment without UTF-8 encoding issues

param([switch]$SkipVCCheck = $false, [switch]$Debug = $false)

$ErrorActionPreference = "Stop"

# Debug logging function
function Write-DebugLog($msg) {
    if ($Debug) {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "[DEBUG $timestamp] $msg" -ForegroundColor Magenta
    }
}

# Standard output functions
function Write-Step($msg) { 
    Write-Host "[STEP] $msg" -ForegroundColor Cyan 
    Write-DebugLog "STEP: $msg"
}

function Write-Ok($msg) { 
    Write-Host "[OK] $msg" -ForegroundColor Green 
    Write-DebugLog "OK: $msg"
}

function Write-Warn($msg) { 
    Write-Host "[WARN] $msg" -ForegroundColor Yellow 
    Write-DebugLog "WARN: $msg"
}

function Write-ErrorLog($msg) { 
    Write-Host "[ERROR] $msg" -ForegroundColor Red 
    Write-DebugLog "ERROR: $msg"
}

# Main script
Write-DebugLog "Script started"
Write-DebugLog "Parameters: SkipVCCheck=$SkipVCCheck, Debug=$Debug"
Write-DebugLog "PowerShell Version: $($PSVersionTable.PSVersion)"
Write-DebugLog "Current Directory: $(Get-Location)"

Write-Step "WinCaptureOCR Setup"

# Check .NET 6.0
Write-Step "Checking .NET 6.0 SDK"
Write-DebugLog "Running: dotnet --version"

try {
    $ver = dotnet --version 2>&1
    Write-DebugLog "dotnet version output: $ver"
    
    if ($ver.StartsWith("6.0")) {
        Write-Ok ".NET 6.0 SDK installed: $ver"
    } else {
        Write-Warn ".NET version mismatch: $ver"
        Write-ErrorLog "Please install .NET 6.0 SDK"
        Write-DebugLog "Exiting with code 1"
        exit 1
    }
} catch {
    Write-ErrorLog ".NET SDK not found"
    Write-DebugLog "Exception: $_"
    exit 1
}

# Check VC++ Runtime
if (-not $SkipVCCheck) {
    Write-Step "Checking VC++ 2015-2022 Runtime"
    Write-DebugLog "Checking registry keys"
    
    $vcInstalled = $false
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"
    )
    
    foreach ($path in $regPaths) {
        Write-DebugLog "Checking: $path"
        if (Test-Path $path) { 
            $vcInstalled = $true 
            Write-DebugLog "Found: $path"
            break 
        }
    }
    
    if ($vcInstalled) {
        Write-Ok "VC++ Runtime installed"
    } else {
        Write-Warn "VC++ Runtime not installed"
        Write-Host "Download: https://aka.ms/vs/17/release/vc_redist.x64.exe" -ForegroundColor Yellow
        Write-DebugLog "VC++ Runtime not found in registry"
    }
} else {
    Write-DebugLog "Skipped VC++ check"
}

# Check language pack
Write-Step "Checking language pack"
Write-DebugLog "Checking tessdata directory"

$tessdataDir = "tessdata"
if (-not (Test-Path $tessdataDir)) {
    Write-DebugLog "Creating directory: $tessdataDir"
    New-Item -ItemType Directory -Path $tessdataDir | Out-Null
    Write-DebugLog "Directory created"
} else {
    Write-DebugLog "Directory exists: $tessdataDir"
}

$chiSim = "$tessdataDir\chi_sim.traineddata"
Write-DebugLog "Checking file: $chiSim"

if (Test-Path $chiSim) {
    $fileSize = (Get-Item $chiSim).Length
    Write-Ok "Chinese language pack exists ($fileSize bytes)"
    Write-DebugLog "File size: $fileSize bytes"
} else {
    Write-Warn "Missing Chinese language pack"
    Write-Host "Download: https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata" -ForegroundColor Yellow
    Write-DebugLog "File not found: $chiSim"
}

# Build test
Write-Step "Building project"
Write-DebugLog "Running: dotnet build -c Release"

dotnet build -c Release 2>&1 | ForEach-Object {
    Write-DebugLog "BUILD: $_"
    $_
}

if ($LASTEXITCODE -eq 0) {
    Write-Ok "Build successful"
    Write-DebugLog "Build exit code: 0"
} else {
    Write-ErrorLog "Build failed"
    Write-DebugLog "Build exit code: $LASTEXITCODE"
    exit 1
}

Write-Step "Setup complete!"
Write-Host "Run: dotnet run" -ForegroundColor Green
Write-DebugLog "Script completed successfully"

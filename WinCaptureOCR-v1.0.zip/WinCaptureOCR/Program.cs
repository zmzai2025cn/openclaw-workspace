using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Tesseract;

namespace WinCaptureOCR
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.ThreadException += (s, e) => 
            {
                MessageBox.Show($"Unhandled exception: {e.Exception.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                MessageBox.Show($"Fatal error: {e.ExceptionObject}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    public class MainForm : Form
    {
        private Button btnCapture = null!;
        private TextBox txtResult = null!;
        private TesseractEngine? engine;
        private bool isInitialized = false;

        public MainForm()
        {
            Text = "WinCapture OCR - Tesseract";
            Size = new Size(800, 600);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(400, 300);

            CreateControls();
            this.Load += (s, e) => InitializeTesseractAsync();
        }

        private void CreateControls()
        {
            btnCapture = new Button
            {
                Text = "Capture & OCR",
                Location = new Point(10, 10),
                Size = new Size(120, 35),
                Enabled = false
            };
            btnCapture.Click += async (s, e) => await OnCaptureClickAsync();

            txtResult = new TextBox
            {
                Multiline = true,
                Location = new Point(10, 55),
                Size = new Size(760, 490),
                ScrollBars = ScrollBars.Both,
                ReadOnly = true,
                Text = "Initializing Tesseract..."
            };

            this.Resize += (s, e) =>
            {
                txtResult.Size = new Size(this.ClientSize.Width - 20, this.ClientSize.Height - 65);
            };

            Controls.Add(btnCapture);
            Controls.Add(txtResult);
        }

        private async void InitializeTesseractAsync()
        {
            await System.Threading.Tasks.Task.Run(() => InitializeTesseract());
        }

        private void InitializeTesseract()
        {
            try
            {
                var tessdataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tessdata");
                
                if (!Directory.Exists(tessdataPath))
                {
                    Invoke(() => ShowError("Missing tessdata directory",
                        "Please download language pack to tessdata folder:\n" +
                        "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata"));
                    return;
                }

                var chiSimPath = Path.Combine(tessdataPath, "chi_sim.traineddata");
                if (!File.Exists(chiSimPath))
                {
                    Invoke(() => ShowError("Missing language pack",
                        "Please download chi_sim.traineddata to tessdata folder."));
                    return;
                }

                var engPath = Path.Combine(tessdataPath, "eng.traineddata");
                var lang = File.Exists(engPath) ? "chi_sim+eng" : "chi_sim";

                Invoke(() => txtResult.Text = "Loading OCR engine...");
                
                engine = new TesseractEngine(tessdataPath, lang, EngineMode.Default);
                isInitialized = true;

                Invoke(() =>
                {
                    btnCapture.Enabled = true;
                    txtResult.Text = $"Tesseract initialized!\nVersion: {engine.Version}\nLanguage: {lang}\n\nClick 'Capture & OCR' to start.";
                });
            }
            catch (TesseractException ex) when (ex.Message.Contains("Failed to initialise"))
            {
                Invoke(() => ShowError("Tesseract init failed",
                    "Possible causes:\n" +
                    "1. Missing VC++ 2015-2022 x64 runtime\n" +
                    "2. Language pack version mismatch\n" +
                    "3. Missing leptonica DLL\n\n" +
                    "Install VC++: https://aka.ms/vs/17/release/vc_redist.x64.exe\n\n" +
                    $"Error: {ex.Message}"));
            }
            catch (DllNotFoundException ex)
            {
                Invoke(() => ShowError("Missing DLL",
                    $"Required DLL not found: {ex.Message}\n\n" +
                    "Please install VC++ 2015-2022 x64 runtime."));
            }
            catch (Exception ex)
            {
                Invoke(() => ShowError("Init failed",
                    $"{ex.GetType().Name}: {ex.Message}\n\n{ex.StackTrace}"));
            }
        }

        private async System.Threading.Tasks.Task OnCaptureClickAsync()
        {
            if (!isInitialized || engine == null)
            {
                MessageBox.Show("OCR engine not initialized", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnCapture.Enabled = false;
            txtResult.Text = "Capturing and recognizing...";

            try
            {
                this.WindowState = FormWindowState.Minimized;
                await System.Threading.Tasks.Task.Delay(500);

                var result = await System.Threading.Tasks.Task.Run(() => CaptureAndRecognize());
                
                this.WindowState = FormWindowState.Normal;
                this.Activate();
                txtResult.Text = result;
            }
            catch (Exception ex)
            {
                this.WindowState = FormWindowState.Normal;
                txtResult.Text = $"Recognition failed:\n{ex.GetType().Name}: {ex.Message}\n\n{ex.StackTrace}";
            }
            finally
            {
                btnCapture.Enabled = true;
            }
        }

        private string CaptureAndRecognize()
        {
            var screen = Screen.PrimaryScreen;
            if (screen == null) return "Error: Cannot get screen info";

            int width = Math.Min(screen.Bounds.Width, 3840);
            int height = Math.Min(screen.Bounds.Height, 2160);

            using var bitmap = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            using (var g = Graphics.FromImage(bitmap))
            {
                g.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, new Size(width, height));
            }

            var tempPath = Path.Combine(Path.GetTempPath(), $"ocr_{Guid.NewGuid()}.png");
            try
            {
                bitmap.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);

                using var img = Pix.LoadFromFile(tempPath);
                using var page = engine!.Process(img);
                var text = page.GetText()?.Trim();
                var confidence = page.GetMeanConfidence();

                if (string.IsNullOrWhiteSpace(text))
                {
                    return "No text recognized.\n\nTip: Make sure there is clear text on screen.";
                }

                return $"Result:\n{text}\n\nConfidence: {confidence:P}\nResolution: {width}x{height}\nChars: {text.Length}";
            }
            finally
            {
                try { File.Delete(tempPath); } catch { }
            }
        }

        private void ShowError(string title, string message)
        {
            txtResult.Text = $"ERROR: {title}\n\n{message}";
            txtResult.ForeColor = Color.DarkRed;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { engine?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }
}

using System;
using System.Diagnostics;

namespace WinCaptureMVP.Utils
{
    public static class PerformanceMonitor
    {
        private static PerformanceCounter? _cpuCounter;
        private static bool _isDisposed;

        static PerformanceMonitor()
        {
            try
            {
                _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                _cpuCounter.NextValue(); // 首次调用返回0
            }
            catch
            {
                // 某些环境可能无法访问性能计数器
                _cpuCounter = null;
            }
        }

        public static float GetCpuUsage()
        {
            if (_isDisposed) return 0;
            try
            {
                return _cpuCounter?.NextValue() ?? 0;
            }
            catch
            {
                return 0;
            }
        }

        public static long GetMemoryUsage()
        {
            try
            {
                using (var proc = Process.GetCurrentProcess())
                {
                    return proc.WorkingSet64 / 1024 / 1024; // MB
                }
            }
            catch
            {
                return 0;
            }
        }

        public static void Cleanup()
        {
            if (!_isDisposed)
            {
                _cpuCounter?.Dispose();
                _cpuCounter = null;
                _isDisposed = true;
            }
        }
    }
}
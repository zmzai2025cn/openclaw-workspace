using System;
using System.IO;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    /// <summary>
    /// 程序入口
    /// </summary>
    internal static class Program
    {
        private static readonly string LogPath;
        private static System.Threading.Mutex? _instanceMutex; // 保持引用防止GC回收

        static Program()
        {
            // 初始化日志路径
            string logDir;
            try
            {
                var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (!string.IsNullOrEmpty(localAppData))
                {
                    logDir = Path.Combine(localAppData, "WinCaptureMVP");
                }
                else
                {
                    logDir = AppContext.BaseDirectory;
                }
            }
            catch
            {
                logDir = AppContext.BaseDirectory;
            }
            
            // 确保 logDir 不为空
            if (string.IsNullOrEmpty(logDir))
            {
                logDir = ".";
            }
            
            LogPath = Path.Combine(logDir, "app_log.txt");
        }

        /// <summary>
        /// 写入日志 - 多层备用机制
        /// </summary>
        private static void Log(string message)
        {
            var logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{System.Threading.Thread.CurrentThread.ManagedThreadId}] {message}";
            
            // 尝试 1: 主日志路径（如果 LogPath 有效）
            if (!string.IsNullOrEmpty(LogPath))
            {
                try
                {
                    var dir = Path.GetDirectoryName(LogPath);
                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }
                    File.AppendAllText(LogPath, logEntry + Environment.NewLine);
                    return; // 成功，直接返回
                }
                catch { }
            }
            
            // 尝试 2: 备用路径（程序目录）
            try
            {
                var fallbackPath = Path.Combine(AppContext.BaseDirectory ?? ".", "app_log.txt");
                File.AppendAllText(fallbackPath, logEntry + Environment.NewLine);
                return;
            }
            catch { }
            
            // 尝试 3: 当前工作目录
            try
            {
                File.AppendAllText("app_log.txt", logEntry + Environment.NewLine);
                return;
            }
            catch { }
            
            // 尝试 4: Windows 事件日志（最后手段）
            try
            {
                System.Diagnostics.EventLog.WriteEntry("Application", $"WinCaptureMVP: {logEntry}", System.Diagnostics.EventLogEntryType.Information);
            }
            catch { }
        }

        /// <summary>
        /// 写入错误日志
        /// </summary>
        private static void LogError(string message, Exception? ex = null)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"[ERROR] {message}");
            if (ex != null)
            {
                sb.AppendLine($"  Exception: {ex.GetType().Name}");
                sb.AppendLine($"  Message: {ex.Message}");
                sb.AppendLine($"  StackTrace: {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    sb.AppendLine($"  InnerException: {ex.InnerException.Message}");
                }
            }
            Log(sb.ToString());
        }

        [STAThread]
        private static void Main()
        {
            Log("==============================================");
            Log("应用程序启动");

            // 检查是否已有实例在运行
            if (IsAlreadyRunning())
            {
                Log("检测到已有实例在运行，退出");
                MessageBox.Show("采集端已在运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                // 初始化 Windows 窗体应用程序
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Log("UI 框架初始化完成");

                // 加载配置
                Config.UserConfig config;
                try
                {
                    config = Config.UserConfig.Load();
                    Log($"配置加载完成，用户ID: {config.UserId ?? "(未设置)"}");
                }
                catch (Exception ex)
                {
                    Log($"配置加载失败: {ex.Message}，使用默认配置");
                    config = new Config.UserConfig();
                }

                // 首次运行显示配置界面
                if (string.IsNullOrWhiteSpace(config.UserId))
                {
                    Log("首次运行，显示配置界面");
                    using var form = new UI.ConfigForm(config);
                    var result = form.ShowDialog();
                    if (result != DialogResult.OK)
                    {
                        Log("用户取消配置，退出程序");
                        return;
                    }
                    Log("配置完成");
                }

                // 再次检查配置是否有效
                if (string.IsNullOrWhiteSpace(config.UserId))
                {
                    Log("错误: 用户ID仍为空");
                    MessageBox.Show("配置无效，请重新运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 创建采集引擎
                CaptureEngine engine;
                try
                {
                    Log("正在创建采集引擎...");
                    engine = new CaptureEngine(config);
                    Log("采集引擎创建成功");
                }
                catch (Exception ex)
                {
                    Log($"创建采集引擎失败: {ex.Message}");
                    Log($"堆栈跟踪: {ex.StackTrace}");
                    MessageBox.Show($"初始化失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 创建托盘图标
                UI.TrayIcon tray;
                try
                {
                    Log("正在创建托盘图标...");
                    tray = new UI.TrayIcon(engine);
                    Log("托盘图标创建成功");
                }
                catch (Exception ex)
                {
                    Log($"创建托盘图标失败: {ex.Message}");
                    engine.Dispose();
                    MessageBox.Show($"初始化失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 启动引擎
                try
                {
                    Log("正在启动采集引擎...");
                    engine.Start();
                    Log("采集引擎已启动");
                }
                catch (Exception ex)
                {
                    Log($"启动采集引擎失败: {ex.Message}");
                    tray.Dispose();
                    engine.Dispose();
                    MessageBox.Show($"启动失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 注册退出事件
                var trayRef = tray;
                var engineRef = engine;
                Application.ApplicationExit += (s, e) =>
                {
                    Log("应用程序正在退出...");
                    try { trayRef?.Dispose(); } catch { }
                    try { engineRef?.Dispose(); } catch { }
                    try { _instanceMutex?.Dispose(); } catch { }
                    Log("资源已清理");
                    Log("==============================================");
                };

                Log("进入主消息循环");
                Application.Run();
            }
            catch (Exception ex)
            {
                var errorMsg = $"程序遇到致命错误: {ex.Message}";
                Log(errorMsg);
                Log($"堆栈跟踪: {ex.StackTrace}");
                
                try
                {
                    MessageBox.Show(errorMsg, "致命错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
            }
        }

        /// <summary>
        /// 检查是否已有实例在运行
        /// </summary>
        private static bool IsAlreadyRunning()
        {
            const string MutexName = "WinCaptureMVP_SingleInstance_v2";
            try
            {
                // 尝试创建互斥体
                _instanceMutex = new System.Threading.Mutex(false, MutexName, out bool createdNew);
                if (!createdNew)
                {
                    // 互斥体已存在，说明已有实例在运行
                    _instanceMutex.Dispose();
                    _instanceMutex = null;
                    return true;
                }
                // 保持互斥体引用，防止GC回收
                return false;
            }
            catch (Exception ex)
            {
                Log($"互斥体检查失败: {ex.Message}");
                // 出错时保守处理，假设已有实例
                return true;
            }
        }
    }
}

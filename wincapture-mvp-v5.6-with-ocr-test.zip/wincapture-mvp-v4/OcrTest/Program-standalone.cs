using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;

namespace OcrTestStandalone
{
    /// <summary>
    /// OCR 极简验证工具 - 独立版（不依赖主程序）
    /// </summary>
    class Program
    {
        private static string LogPath = "ocr_test.log";
        private static readonly StringBuilder LogBuffer = new StringBuilder();

        static Program()
        {
            try
            {
                var logDir = AppContext.BaseDirectory ?? ".";
                if (!Directory.Exists(logDir))
                {
                    logDir = ".";
                }
                LogPath = Path.Combine(logDir, $"ocr_test_{DateTime.Now:yyyyMMdd_HHmmss}.log");
            }
            catch
            {
                LogPath = "ocr_test.log";
            }
        }

        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Log("==============================================");
                Log("OCR 极简验证工具 - 独立版");
                Log($"启动时间: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                Log($"日志文件: {LogPath}");
                Log("==============================================\n");

                Console.WriteLine("================================");
                Console.WriteLine("OCR 极简验证工具");
                Console.WriteLine("================================\n");

                RunTest();
            }
            catch (Exception ex)
            {
                try
                {
                    var errorMsg = $"未捕获的异常: {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}";
                    Log($"[FATAL] {errorMsg}");
                    Console.WriteLine($"\n❌ 致命错误: {ex.Message}");
                }
                catch
                {
                    Console.WriteLine($"\n❌ 致命错误: {ex}");
                }
            }
            finally
            {
                SaveLog();
                
                Console.WriteLine("\n按任意键退出...");
                try
                {
                    Console.ReadKey();
                }
                catch
                {
                    System.Threading.Thread.Sleep(2000);
                }
            }
        }

        static void RunTest()
        {
            // 步骤 1: 环境检查
            LogStep(1, "环境检查");
            try
            {
                Log($"  当前目录: {Environment.CurrentDirectory}");
                Log($"  程序目录: {AppContext.BaseDirectory ?? "(null)"}");
                Log($"  .NET 版本: {Environment.Version}");
                Log($"  OS 版本: {Environment.OSVersion}");
            }
            catch (Exception ex)
            {
                Log($"[WARN] 环境检查部分失败: {ex.Message}");
            }

            // 步骤 2: 检查模型文件
            LogStep(2, "检查模型文件");
            var modelPath = FindModelPath();
            if (string.IsNullOrEmpty(modelPath))
            {
                Log("[ERROR] 未找到模型文件");
                Console.WriteLine("❌ 未找到 OCR 模型文件");
                Console.WriteLine("\n请确保:");
                Console.WriteLine("  - 模型文件已下载");
                Console.WriteLine("  - 模型路径: ./paddleocr_models/");
                return;
            }
            Log($"[OK] 找到模型路径: {modelPath}");
            Console.WriteLine($"✅ 找到模型: {modelPath}\n");

            // 步骤 3: 初始化 OCR
            LogStep(3, "初始化 OCR 引擎");
            Console.WriteLine("[1/3] 初始化 OCR...");
            
            try
            {
                // 这里简化处理，实际应该调用 PaddleOCRSharp
                Log("  尝试初始化 PaddleOCRSharp...");
                
                // 检查关键文件
                var detPath = Path.Combine(modelPath, "ch_PP-OCRv3_det_infer");
                var recPath = Path.Combine(modelPath, "ch_PP-OCRv3_rec_infer");
                var keysPath = Path.Combine(modelPath, "ppocr_keys_v1.txt");
                
                if (!Directory.Exists(detPath))
                {
                    Log($"[ERROR] 检测模型不存在: {detPath}");
                    Console.WriteLine($"❌ 检测模型不存在");
                    return;
                }
                if (!Directory.Exists(recPath))
                {
                    Log($"[ERROR] 识别模型不存在: {recPath}");
                    Console.WriteLine($"❌ 识别模型不存在");
                    return;
                }
                if (!File.Exists(keysPath))
                {
                    Log($"[ERROR] 字典文件不存在: {keysPath}");
                    Console.WriteLine($"❌ 字典文件不存在");
                    return;
                }
                
                Log("[OK] 模型文件检查通过");
                Console.WriteLine("✅ 模型文件检查通过\n");
            }
            catch (Exception ex)
            {
                Log($"[ERROR] 初始化失败: {ex.Message}");
                Console.WriteLine($"❌ 初始化失败: {ex.Message}");
                return;
            }

            // 步骤 4: 截图
            LogStep(4, "截取屏幕");
            Console.WriteLine("[2/3] 截取屏幕...");
            
            Bitmap? screenshot = null;
            try
            {
                screenshot = CaptureScreen();
                if (screenshot == null)
                {
                    Log("[ERROR] 截图失败");
                    Console.WriteLine("❌ 截图失败");
                    return;
                }
                Log($"[OK] 截图成功: {screenshot.Width}x{screenshot.Height}");
                Console.WriteLine($"✅ 截图成功: {screenshot.Width}x{screenshot.Height}\n");
            }
            catch (Exception ex)
            {
                Log($"[ERROR] 截图异常: {ex.Message}");
                Console.WriteLine($"❌ 截图异常: {ex.Message}");
                return;
            }

            // 步骤 5: 保存测试图片
            LogStep(5, "保存测试图片");
            try
            {
                var testPath = Path.Combine(AppContext.BaseDirectory ?? ".", "ocr_test_screenshot.png");
                screenshot.Save(testPath, ImageFormat.Png);
                Log($"[OK] 测试图片已保存: {testPath}");
                Console.WriteLine($"✅ 测试图片已保存");
                Console.WriteLine($"   路径: {testPath}");
                Console.WriteLine($"   请检查图片是否正常\n");
            }
            catch (Exception ex)
            {
                Log($"[WARN] 保存图片失败: {ex.Message}");
            }
            finally
            {
                screenshot?.Dispose();
            }

            // 步骤 6: 结论
            LogStep(6, "验证结论");
            Console.WriteLine("[3/3] 验证结果:");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("✅ 环境检查: 通过");
            Console.WriteLine("✅ 模型文件: 存在");
            Console.WriteLine("✅ 截图功能: 正常");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("\n注意: 此工具仅验证环境和截图");
            Console.WriteLine("      完整 OCR 功能请在主程序中测试");

            Log("\n==============================================");
            Log("验证完成");
            Log("==============================================");
        }

        static string? FindModelPath()
        {
            // 尝试多个可能的路径
            var paths = new[]
            {
                Path.Combine(AppContext.BaseDirectory ?? ".", "paddleocr_models"),
                Path.Combine(AppContext.BaseDirectory ?? ".", "..", "paddleocr_models"),
                Path.Combine(Environment.CurrentDirectory, "paddleocr_models"),
                @".\paddleocr_models"
            };

            foreach (var path in paths)
            {
                if (Directory.Exists(path))
                {
                    return path;
                }
            }
            return null;
        }

        static Bitmap? CaptureScreen()
        {
            try
            {
                var screen = System.Windows.Forms.Screen.PrimaryScreen;
                if (screen == null) return null;

                var bitmap = new Bitmap(screen.Bounds.Width, screen.Bounds.Height, PixelFormat.Format32bppArgb);
                using (var graphics = Graphics.FromImage(bitmap))
                {
                    graphics.CopyFromScreen(0, 0, 0, 0, screen.Bounds.Size, CopyPixelOperation.SourceCopy);
                }
                return bitmap;
            }
            catch
            {
                return null;
            }
        }

        static void LogStep(int step, string message)
        {
            try
            {
                var logMsg = $"\n[步骤 {step}] {message}";
                Log(logMsg);
            }
            catch { }
        }

        static void Log(string message)
        {
            try
            {
                var timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
                var logLine = $"[{timestamp}] {message}";
                LogBuffer.AppendLine(logLine);
            }
            catch { }
        }

        static void SaveLog()
        {
            try
            {
                if (LogBuffer.Length > 0)
                {
                    File.WriteAllText(LogPath, LogBuffer.ToString());
                    Console.WriteLine($"\n详细日志已保存: {LogPath}");
                }
            }
            catch (Exception ex)
            {
                try
                {
                    Console.WriteLine($"\n保存日志失败: {ex.Message}");
                }
                catch { }
            }
        }
    }
}

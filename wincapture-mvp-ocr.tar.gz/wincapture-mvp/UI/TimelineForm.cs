using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public class TimelineForm : Form
    {
        private List<WorkRecord> _records;
        private ListView _listView;

        public TimelineForm(List<WorkRecord> records)
        {
            _records = records;
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            Text = "今日工作记录";
            Size = new Size(800, 600);
            StartPosition = FormStartPosition.CenterScreen;

            _listView = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            
            _listView.Columns.Add("时间", 80);
            _listView.Columns.Add("应用", 100);
            _listView.Columns.Add("窗口标题", 250);
            _listView.Columns.Add("OCR文字", 300);

            Controls.Add(_listView);

            // 统计标签
            var statsLabel = new Label
            {
                Dock = DockStyle.Top,
                Height = 30,
                TextAlign = ContentAlignment.MiddleLeft
            };
            Controls.Add(statsLabel);
            statsLabel.BringToFront();
        }

        private void LoadData()
        {
            _listView.Items.Clear();
            
            foreach (var record in _records.OrderByDescending(r => r.Timestamp))
            {
                var item = new ListViewItem(record.Timestamp.ToString("HH:mm:ss"));
                item.SubItems.Add(record.AppName);
                item.SubItems.Add(record.WindowTitle);
                item.SubItems.Add(record.OcrText.Length > 50 ? record.OcrText.Substring(0, 50) + "..." : record.OcrText);
                _listView.Items.Add(item);
            }

            // 更新统计
            var stats = Controls.OfType<Label>().FirstOrDefault();
            if (stats != null)
            {
                var appCount = _records.Select(r => r.AppName).Distinct().Count();
                stats.Text = $"共 {_records.Count} 条记录，涉及 {appCount} 个应用";
            }
        }
    }
}
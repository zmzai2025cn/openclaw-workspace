using System;
using System.Drawing;

namespace WinCaptureMVP.Utils
{
    public static class OcrEngine
    {
        private static bool _isInitialized = false;
        private static string _tesseractPath = "";

        public static void Initialize(string dataPath)
        {
            _tesseractPath = dataPath;
            _isInitialized = true;
        }

        public static string Recognize(Bitmap image)
        {
            if (!_isInitialized)
            {
                // MVP 阶段：返回空字符串，提示用户安装 Tesseract
                Console.WriteLine("OCR 未初始化，请先安装 Tesseract 并下载中文语言包");
                return "";
            }

            try
            {
                // TODO: 集成 Tesseract
                // using (var engine = new TesseractEngine(_tesseractPath, "chi_sim+eng"))
                // using (var page = engine.Process(image))
                // {
                //     return page.GetText();
                // }
                
                return "";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"OCR 识别失败: {ex.Message}");
                return "";
            }
        }
    }
}
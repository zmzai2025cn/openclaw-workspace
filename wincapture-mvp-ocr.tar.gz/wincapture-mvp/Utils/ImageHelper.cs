using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace WinCaptureMVP.Utils
{
    public static class ImageHelper
    {
        public static Bitmap CreateThumbnail(Bitmap source, int maxWidth, int maxHeight)
        {
            int width = source.Width;
            int height = source.Height;
            
            // 计算缩放比例
            double ratio = Math.Min((double)maxWidth / width, (double)maxHeight / height);
            
            int newWidth = (int)(width * ratio);
            int newHeight = (int)(height * ratio);
            
            var thumbnail = new Bitmap(newWidth, newHeight);
            using (var graphics = Graphics.FromImage(thumbnail))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.DrawImage(source, 0, 0, newWidth, newHeight);
            }
            
            return thumbnail;
        }

        public static string ToBase64(Bitmap bitmap)
        {
            using (var ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Jpeg);
                return Convert.ToBase64String(ms.ToArray());
            }
        }
    }
}
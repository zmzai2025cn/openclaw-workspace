using System;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class IntervalTrigger : ITrigger
    {
        private readonly Action _callback;
        private System.Threading.Timer? _timer;
        private bool _isPaused;
        private int _isProcessing;
        private readonly int _intervalMs = 30000; // 30 秒

        public IntervalTrigger(Action callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _timer = new Timer(OnInterval, null, _intervalMs, _intervalMs);
        }

        public void Stop()
        {
            _timer?.Dispose();
            _timer = null;
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void OnInterval(object? state)
        {
            if (_isPaused) return;
            
            if (Interlocked.CompareExchange(ref _isProcessing, 1, 0) == 1)
                return;
            
            try
            {
                _callback?.Invoke();
            }
            finally
            {
                _isProcessing = 0;
            }
        }
    }
}
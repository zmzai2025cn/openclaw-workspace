# WinCapture OCR v1.2

## Version 1.2.0
- Added image preprocessing for better OCR accuracy
  - 2x scaling
  - Grayscale conversion
  - Adaptive threshold (Otsu algorithm)
- Improved Chinese text recognition

## Version 1.1.0
- Added comprehensive debug logging
- Fixed all compilation warnings
- Enhanced error handling

## Requirements
- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)

## Quick Start
```powershell
.\scripts\setup.ps1
```

## Manual Setup
1. Install .NET 6.0 SDK
2. Install VC++ Runtime
3. Download language pack to `tessdata/` folder
4. Run `dotnet run`

## Language Pack
Download `chi_sim.traineddata` from:
https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata

## Debug Log
Application logs to `wincapture.log` in the application directory.

## Improve Accuracy
See docs/07-IMPROVE-ACCURACY.md for more optimization tips.

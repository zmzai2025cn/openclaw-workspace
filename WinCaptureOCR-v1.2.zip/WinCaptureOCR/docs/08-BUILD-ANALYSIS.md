# WinCaptureOCR v1.2 编译全流程分析

## 1. 源文件结构

```
WinCaptureOCR/
├── WinCaptureOCR.csproj      # 项目文件
├── Program.cs                 # 主程序入口
└── ImagePreprocessor.cs       # 图像预处理
```

## 2. 编译依赖链

### 2.1 项目文件依赖
```
WinCaptureOCR.csproj
├── Microsoft.NET.Sdk (SDK)
├── PackageReference: Tesseract 5.2.0
├── PackageReference: Tesseract.Drawing 5.2.0
├── Compile: Program.cs
├── Compile: ImagePreprocessor.cs
└── None: tessdata\** (copy to output)
```

### 2.2 代码文件依赖
```
Program.cs
├── System
├── System.Drawing
├── System.IO
├── System.Windows.Forms
├── Tesseract
└── ImagePreprocessor (内部依赖)

ImagePreprocessor.cs
├── System
├── System.Drawing
├── System.Drawing.Imaging
└── System.IO
```

### 2.3 运行时依赖链
```
WinCaptureOCR.exe (输出)
├── WinCaptureOCR.dll (编译生成)
├── ImagePreprocessor.dll (编译生成)
├── Tesseract.dll (NuGet)
├── Tesseract.Drawing.dll (NuGet)
├── leptonica-1.82.0.dll (Tesseract native)
├── tesseract50.dll (Tesseract native)
└── tessdata/ (语言包目录)
    └── chi_sim.traineddata
```

## 3. 编译步骤分析

### 步骤 1: NuGet 还原
```bash
dotnet restore
```
- 下载 Tesseract 5.2.0
- 下载 Tesseract.Drawing 5.2.0
- 下载依赖包（leptonica 等 native dll）

### 步骤 2: 编译 C# 代码
```bash
dotnet build
```
1. 编译 ImagePreprocessor.cs → ImagePreprocessor.dll
2. 编译 Program.cs → WinCaptureOCR.dll
3. 链接生成 WinCaptureOCR.exe

### 步骤 3: 复制依赖文件
- 复制 NuGet 包 DLL 到输出目录
- 复制 native DLL (x64/leptonica-1.82.0.dll, tesseract50.dll)
- 复制 tessdata 文件（如果存在）

## 4. 潜在编译问题分析

### 问题 1: 类型冲突
**风险**: `ImageFormat` 在 `System.Drawing.Imaging` 和 `Tesseract` 中都有定义
**解决**: ✅ 使用完整命名空间 `System.Drawing.Imaging.ImageFormat`

### 问题 2: Nullable 警告
**风险**: CS8618 等 nullable 警告
**解决**: ✅ 在 csproj 中禁用 `<NoWarn>CS8618;CS8600;CS8602;CS8604</NoWarn>`

### 问题 3: 缺少 using
**风险**: ImagePreprocessor 引用了不需要的命名空间
**解决**: ✅ 已移除 `System.Windows.Forms` 和 `Tesseract`

### 问题 4: 文件未包含
**风险**: ImagePreprocessor.cs 未包含在编译中
**解决**: ✅ csproj 中明确包含 `<Compile Include="ImagePreprocessor.cs" />`

### 问题 5: 平台不匹配
**风险**: x86/x64 架构冲突
**解决**: ✅ 强制 x64 `<PlatformTarget>x64</PlatformTarget>`

## 5. 编译验证清单

```powershell
# 1. 清理
Remove-Item -Recurse bin, obj

# 2. 还原
dotnet restore

# 3. 编译
dotnet build -c Release

# 4. 检查输出
Test-Path bin\Release\net6.0-windows\WinCaptureOCR.exe
Test-Path bin\Release\net6.0-windows\x64\leptonica-1.82.0.dll
Test-Path bin\Release\net6.0-windows\x64\tesseract50.dll

# 5. 检查警告
dotnet build -c Release -warnaserror  # 应该成功
```

## 6. 依赖版本锁定

| 组件 | 版本 | 来源 |
|------|------|------|
| .NET | 6.0.x | 运行时 |
| Tesseract | 5.2.0 | NuGet |
| Tesseract.Drawing | 5.2.0 | NuGet |
| leptonica | 1.82.0 | Tesseract 依赖 |
| tesseract | 5.0.x | Tesseract 依赖 |

## 7. 编译成功标准

- [ ] 0 个错误
- [ ] 0 个警告（或已知警告已禁用）
- [ ] WinCaptureOCR.exe 生成
- [ ] x64/leptonica-1.82.0.dll 存在
- [ ] x64/tesseract50.dll 存在
- [ ] 程序可启动

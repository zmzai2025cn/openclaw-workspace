# Tesseract 中文识别优化指南

## 当前问题
- 识别率低，大量错字
- 中文比英文更难识别

## 优化方案（按效果排序）

### 1. 图像预处理（最重要）

#### 1.1 提高分辨率
```csharp
// 截图时放大 2 倍
bitmap = new Bitmap(bitmap, new Size(bitmap.Width * 2, bitmap.Height * 2));
```

#### 1.2 灰度化
```csharp
// 转换为灰度图
using var grayBitmap = new Bitmap(bitmap.Width, bitmap.Height);
using (var g = Graphics.FromImage(grayBitmap))
{
    var colorMatrix = new ColorMatrix(new float[][]
    {
        new float[] {0.299f, 0.299f, 0.299f, 0, 0},
        new float[] {0.587f, 0.587f, 0.587f, 0, 0},
        new float[] {0.114f, 0.114f, 0.114f, 0, 0},
        new float[] {0, 0, 0, 1, 0},
        new float[] {0, 0, 0, 0, 1}
    });
    using var attributes = new ImageAttributes();
    attributes.SetColorMatrix(colorMatrix);
    g.DrawImage(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height),
        0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, attributes);
}
```

#### 1.3 二值化（黑白化）
```csharp
// 使用阈值二值化
for (int y = 0; y < bitmap.Height; y++)
{
    for (int x = 0; x < bitmap.Width; x++)
    {
        var pixel = bitmap.GetPixel(x, y);
        int gray = (pixel.R + pixel.G + pixel.B) / 3;
        var newColor = gray > 128 ? Color.White : Color.Black;
        bitmap.SetPixel(x, y, newColor);
    }
}
```

#### 1.4 去噪
```csharp
// 使用中值滤波去噪
// 或使用高斯模糊
```

### 2. Tesseract 参数调优

```csharp
// 设置页面分割模式
engine.SetVariable("tessedit_pageseg_mode", "6"); // 统一文本块

// 设置白名单字符（可选）
engine.SetVariable("tessedit_char_whitelist", 
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");

// 提高精度模式
engine.SetVariable("tessedit_do_invert", "0");
```

### 3. 使用更好的语言包

#### 3.1 使用 fast 版本（更快，稍低精度）
- 已在使用

#### 3.2 使用 best 版本（更高精度，更慢）
```
https://github.com/tesseract-ocr/tessdata_best/raw/main/chi_sim.traineddata
```

#### 3.3 使用垂直文本语言包（如果是竖排文字）
```
chi_sim_vert.traineddata
```

### 4. 截图区域优化

- 只截取有文字的区域（避免全屏）
- 确保文字清晰
- 避免文字太小（建议最小 12pt）

### 5. 后处理校正

- 使用字典匹配纠正错字
- 使用语言模型提高连贯性

## 推荐实现顺序

1. **立即实现**：图像预处理（灰度+二值化）
2. **短期**：Tesseract 参数调优
3. **中期**：尝试 best 语言包
4. **长期**：后处理校正

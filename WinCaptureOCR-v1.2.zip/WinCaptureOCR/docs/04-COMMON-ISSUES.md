# 常见问题 (持续更新)

## 问题记录原则
1. 每个问题必须有：症状、原因、解决方案
2. 按错误类型分类
3. 定期回顾，删除过时问题

---

## Tesseract 初始化失败

### 症状
```
TesseractException: Failed to initialise tesseract engine
```

### 原因
1. **VC++ 运行时缺失** (90%)
2. **语言包版本不匹配** (5%)
3. **DLL 架构不匹配** (5%)

### 解决方案

#### 方案1: 安装 VC++ 运行时
```powershell
# 下载并安装
https://aka.ms/vs/17/release/vc_redist.x64.exe
```

#### 方案2: 检查语言包版本
```powershell
# 语言包必须与 Tesseract 版本匹配
# Tesseract 5.2.0 需要 5.x 语言包
# 检查文件大小（正常应 > 10MB）
ls tessdata/chi_sim.traineddata
```

#### 方案3: 检查 DLL 架构
```powershell
# 确保所有 DLL 都是 x64
dumpbin /headers x64/leptonica-1.82.0.dll | findstr machine
```

---

## 截图失败

### 症状
```
NullReferenceException: Screen.PrimaryScreen is null
```

### 原因
多显示器环境下可能获取不到主屏幕

### 解决方案
使用 `Screen.AllScreens` 遍历所有屏幕

---

## 识别结果为空

### 症状
识别完成，但无文字输出

### 原因
1. 屏幕上没有文字
2. 文字太小或模糊
3. 语言包不支持该文字类型

### 解决方案
1. 确保屏幕上有清晰的文字
2. 尝试放大文字
3. 检查语言包是否完整

---

## 程序崩溃

### 症状
运行时突然崩溃

### 原因
1. 内存不足（截图分辨率太高）
2. 临时文件未清理导致磁盘满
3. 多线程冲突

### 解决方案
1. 限制截图最大分辨率 4K
2. 使用 `try-finally` 确保清理
3. 避免多线程访问 TesseractEngine

---

## 添加新问题

模板：
```markdown
## 问题标题

### 症状
错误信息或现象

### 原因
1. 原因1 (概率%)
2. 原因2 (概率%)

### 解决方案
#### 方案1: xxx
步骤...

#### 方案2: xxx
步骤...
```

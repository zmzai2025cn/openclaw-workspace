using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WinCaptureMVP.Utils
{
    public static class ScreenCapture
    {
        [DllImport("gdi32.dll")]
        private static extern int GetDeviceCaps(IntPtr hdc, int nIndex);
        
        private const int DESKTOPHORZRES = 118;
        private const int HORZRES = 8;

        public static Bitmap? CaptureScreen()
        {
            var screen = Screen.PrimaryScreen;
            if (screen == null) return null;
            
            try
            {
                // 获取实际分辨率（处理 DPI 缩放）
                var scale = GetScreenScale();
                var width = (int)(screen.Bounds.Width * scale);
                var height = (int)(screen.Bounds.Height * scale);
                
                var bitmap = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                
                using (var graphics = Graphics.FromImage(bitmap))
                {
                    graphics.CopyFromScreen(0, 0, 0, 0, new Size(width, height), CopyPixelOperation.SourceCopy);
                }
                
                return bitmap;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ScreenCapture] 截图失败: {ex.Message}");
                return null;
            }
        }
        
        private static float GetScreenScale()
        {
            try
            {
                using (var g = Graphics.FromHwnd(IntPtr.Zero))
                {
                    var hdc = g.GetHdc();
                    var actualWidth = GetDeviceCaps(hdc, DESKTOPHORZRES);
                    var logicalWidth = GetDeviceCaps(hdc, HORZRES);
                    g.ReleaseHdc(hdc);
                    return (float)actualWidth / logicalWidth;
                }
            }
            catch
            {
                return 1.0f;
            }
        }
    }
}

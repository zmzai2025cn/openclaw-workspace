using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using PaddleOCRSharp;

namespace WinCaptureMVP.Utils
{
    public static class OcrEngine
    {
        private static bool _isInitialized = false;
        private static string _modelPath = "";
        private static PaddleOCRAll? _ocrEngine;

        static OcrEngine()
        {
            Initialize();
        }

        private static void Initialize()
        {
            try
            {
                // 获取程序所在目录
                var exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? "";
                _modelPath = Path.Combine(exePath, "paddleocr_models");

                // 检查模型文件是否存在
                var detPath = Path.Combine(_modelPath, "ch_PP-OCRv4_det_infer");
                var recPath = Path.Combine(_modelPath, "ch_PP-OCRv4_rec_infer");
                var clsPath = Path.Combine(_modelPath, "ch_ppocr_mobile_v2.0_cls_infer");
                var keysPath = Path.Combine(_modelPath, "ppocr_keys.txt");

                if (!Directory.Exists(detPath) || !Directory.Exists(recPath))
                {
                    Console.WriteLine($"PaddleOCR 模型未找到: {_modelPath}");
                    Console.WriteLine("请确保 paddleocr_models 文件夹包含模型文件");
                    _isInitialized = false;
                    return;
                }

                // 配置 OCR 参数
                var parameter = new PaddleOCRParameter();
                parameter.cpu_math_library_num_threads = 4;  // CPU 线程数
                parameter.det_db_thresh = 0.3f;              // 检测阈值
                parameter.det_db_box_thresh = 0.5f;          // 检测框阈值
                parameter.det_db_unclip_ratio = 2.0f;        // 检测框扩展比例
                parameter.use_angle_cls = true;              // 使用方向分类器
                parameter.cls_thresh = 0.9f;                 // 分类阈值
                parameter.rec_batch_num = 6;                 // 识别批处理数量

                // 初始化 OCR 引擎
                _ocrEngine = new PaddleOCRAll(_modelPath, parameter);
                _isInitialized = true;
                
                Console.WriteLine($"PaddleOCR 初始化成功，模型路径: {_modelPath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"PaddleOCR 初始化失败: {ex.Message}");
                Console.WriteLine($"异常详情: {ex.StackTrace}");
                _isInitialized = false;
            }
        }

        public static string Recognize(Bitmap image)
        {
            if (!_isInitialized || _ocrEngine == null)
            {
                Console.WriteLine("[OcrEngine] OCR 未初始化");
                return "";
            }

            if (image == null)
            {
                Console.WriteLine("[OcrEngine] 图片为空");
                return "";
            }

            try
            {
                // 将 Bitmap 转换为字节数组
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    // 保存为 PNG 格式（PaddleOCR 推荐）
                    image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    imageBytes = ms.ToArray();
                }

                // 执行 OCR 识别
                var result = _ocrEngine.OCR(imageBytes);
                
                if (result == null || result.TextBlocks == null)
                {
                    Console.WriteLine("[OcrEngine] OCR 返回空结果");
                    return "";
                }

                // 拼接所有识别的文本
                var text = string.Join("\n", result.TextBlocks.Select(b => b.Text));
                
                Console.WriteLine($"[OcrEngine] 识别到 {result.TextBlocks.Count} 个文本块");
                
                return text?.Trim() ?? "";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[OcrEngine] OCR 识别失败: {ex.Message}");
                Console.WriteLine($"[OcrEngine] 异常详情: {ex.StackTrace}");
                return "";
            }
        }

        public static bool IsInitialized => _isInitialized;

        public static void Dispose()
        {
            _ocrEngine?.Dispose();
            _ocrEngine = null;
            _isInitialized = false;
            Console.WriteLine("[OcrEngine] OCR 引擎已释放");
        }
    }
}

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace WinCaptureMVP.Utils
{
    public static class ImageHelper
    {
        public static Bitmap? CreateThumbnail(Bitmap source, int maxWidth, int maxHeight)
        {
            try
            {
                if (source == null || source.Width == 0 || source.Height == 0)
                    return null;

                int width = source.Width;
                int height = source.Height;
                
                // 计算缩放比例
                double ratio = Math.Min((double)maxWidth / width, (double)maxHeight / height);
                
                int newWidth = Math.Max(1, (int)(width * ratio));
                int newHeight = Math.Max(1, (int)(height * ratio));
                
                var thumbnail = new Bitmap(newWidth, newHeight);
                using (var graphics = Graphics.FromImage(thumbnail))
                {
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.DrawImage(source, 0, 0, newWidth, newHeight);
                }
                
                return thumbnail;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"生成缩略图失败: {ex.Message}");
                return null;
            }
        }

        public static string ToBase64(Bitmap? bitmap)
        {
            if (bitmap == null)
            {
                Console.WriteLine("[ImageHelper] ToBase64: bitmap is null");
                return "";
            }
            
            try
            {
                using (var ms = new MemoryStream())
                {
                    // 使用高质量的 JPEG 编码参数
                    var encoderParams = new System.Drawing.Imaging.EncoderParameters(1);
                    encoderParams.Param[0] = new System.Drawing.Imaging.EncoderParameter(
                        System.Drawing.Imaging.Encoder.Quality, 85L);
                    
                    var jpegCodec = GetEncoder(ImageFormat.Jpeg);
                    if (jpegCodec != null)
                    {
                        bitmap.Save(ms, jpegCodec, encoderParams);
                    }
                    else
                    {
                        bitmap.Save(ms, ImageFormat.Jpeg);
                    }
                    
                    var base64 = Convert.ToBase64String(ms.ToArray());
                    Console.WriteLine($"[ImageHelper] ToBase64 success: {base64.Length} chars");
                    return base64;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ImageHelper] 转换 Base64 失败: {ex.Message}");
                Console.WriteLine($"[ImageHelper] 异常详情: {ex.StackTrace}");
                return "";
            }
        }

        private static System.Drawing.Imaging.ImageCodecInfo? GetEncoder(ImageFormat format)
        {
            var codecs = System.Drawing.Imaging.ImageCodecInfo.GetImageDecoders();
            foreach (var codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }
    }
}
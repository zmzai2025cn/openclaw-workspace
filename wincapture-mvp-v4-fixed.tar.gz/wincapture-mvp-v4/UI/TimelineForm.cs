using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public class TimelineForm : Form
    {
        private System.Collections.Generic.List<WorkRecord> _records;
        private ListView _listView;
        private Label _statsLabel;
        private PictureBox _previewBox;
        private SplitContainer _splitContainer;
        private Label _detailLabel;

        public TimelineForm(System.Collections.Generic.List<WorkRecord> records)
        {
            _records = records;
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            Text = "今日工作记录";
            Size = new Size(1400, 800);
            StartPosition = FormStartPosition.CenterScreen;

            // 分割容器：左侧列表，右侧预览
            _splitContainer = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 800
            };

            // 统计标签
            _statsLabel = new Label
            {
                Dock = DockStyle.Top,
                Height = 30,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10, 0, 0, 0),
                Font = new Font("Microsoft YaHei", 9F)
            };
            Controls.Add(_statsLabel);

            // 左侧列表
            _listView = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                MultiSelect = false
            };
            
            _listView.Columns.Add("时间", 80);
            _listView.Columns.Add("应用", 120);
            _listView.Columns.Add("窗口标题", 300);
            _listView.Columns.Add("OCR文字预览", 280);
            _listView.SelectedIndexChanged += OnSelectionChanged;

            _splitContainer.Panel1.Controls.Add(_listView);

            // 右侧预览区域
            var rightPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10),
                BackColor = Color.FromArgb(240, 240, 240)
            };

            // 预览标题
            var previewTitle = new Label
            {
                Text = "截图预览",
                Dock = DockStyle.Top,
                Height = 30,
                Font = new Font("Microsoft YaHei", 11, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            rightPanel.Controls.Add(previewTitle);

            // 图片预览框
            _previewBox = new PictureBox
            {
                Dock = DockStyle.Top,
                Height = 250,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(0, 10, 0, 10)
            };
            rightPanel.Controls.Add(_previewBox);

            // 详细信息区域
            var detailPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(5)
            };

            var detailTitle = new Label
            {
                Text = "详细信息",
                Dock = DockStyle.Top,
                Height = 25,
                Font = new Font("Microsoft YaHei", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            detailPanel.Controls.Add(detailTitle);

            _detailLabel = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.TopLeft,
                Font = new Font("Consolas", 9F),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(8)
            };
            detailPanel.Controls.Add(_detailLabel);

            rightPanel.Controls.Add(detailPanel);
            _splitContainer.Panel2.Controls.Add(rightPanel);

            Controls.Add(_splitContainer);
        }

        private void OnSelectionChanged(object? sender, EventArgs e)
        {
            if (_listView.SelectedItems.Count == 0)
            {
                _previewBox.Image = null;
                _detailLabel.Text = "";
                return;
            }

            var index = _listView.SelectedItems[0].Index;
            if (index >= 0 && index < _records.Count)
            {
                var record = _records[_records.Count - 1 - index]; // 因为是倒序排列
                ShowThumbnail(record);
                ShowDetails(record);
            }
        }

        private void ShowThumbnail(WorkRecord record)
        {
            _previewBox.Image = null;
            
            if (string.IsNullOrEmpty(record.ThumbnailBase64))
            {
                Console.WriteLine($"[TimelineForm] 记录 {record.Id} 没有缩略图");
                return;
            }

            try
            {
                // Base64 解码并显示图片
                var bytes = Convert.FromBase64String(record.ThumbnailBase64);
                Console.WriteLine($"[TimelineForm] 解码 Base64: {bytes.Length} bytes");
                
                using (var ms = new MemoryStream(bytes))
                {
                    // 必须保持流打开，所以创建副本
                    var img = Image.FromStream(ms);
                    _previewBox.Image = new Bitmap(img); // 创建副本避免流关闭问题
                }
                
                Console.WriteLine($"[TimelineForm] 缩略图加载成功: {_previewBox.Image?.Width}x{_previewBox.Image?.Height}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"[TimelineForm] Base64 格式错误: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TimelineForm] 加载缩略图失败: {ex.Message}");
            }
        }

        private void ShowDetails(WorkRecord record)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"ID: {record.Id}");
            sb.AppendLine($"时间: {record.Timestamp:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"应用: {record.AppName}");
            sb.AppendLine($"窗口: {record.WindowTitle}");
            sb.AppendLine($"触发类型: {record.TriggerType}");
            sb.AppendLine($"缩略图大小: {(string.IsNullOrEmpty(record.ThumbnailBase64) ? "无" : $"{record.ThumbnailBase64.Length} chars")}");
            sb.AppendLine();
            sb.AppendLine("OCR 识别结果:");
            sb.AppendLine(string.IsNullOrEmpty(record.OcrText) ? "(无)" : record.OcrText);
            
            _detailLabel.Text = sb.ToString();
        }

        private void LoadData()
        {
            _listView.Items.Clear();
            
            // 按时间倒序排列
            var sortedRecords = _records.OrderByDescending(r => r.Timestamp).ToList();
            
            foreach (var record in sortedRecords)
            {
                var item = new ListViewItem(record.Timestamp.ToString("HH:mm:ss"));
                item.SubItems.Add(record.AppName);
                item.SubItems.Add(record.WindowTitle);
                
                // OCR 文字预览（前50字符）
                var ocrPreview = record.OcrText?.Length > 50 
                    ? record.OcrText.Substring(0, 50) + "..." 
                    : record.OcrText ?? "";
                item.SubItems.Add(ocrPreview);
                
                // 如果有缩略图，添加标记
                if (!string.IsNullOrEmpty(record.ThumbnailBase64))
                {
                    item.SubItems[0].Text = "📷 " + item.SubItems[0].Text;
                }
                
                _listView.Items.Add(item);
            }

            // 更新统计
            var appCount = _records.Select(r => r.AppName).Distinct().Count();
            var recordsWithThumbnail = _records.Count(r => !string.IsNullOrEmpty(r.ThumbnailBase64));
            _statsLabel.Text = $"共 {_records.Count} 条记录 | {appCount} 个应用 | {recordsWithThumbnail} 条有截图";
            
            Console.WriteLine($"[TimelineForm] 加载了 {_records.Count} 条记录，{recordsWithThumbnail} 条有缩略图");
        }
    }
}

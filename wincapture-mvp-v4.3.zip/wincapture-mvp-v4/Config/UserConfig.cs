using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace WinCaptureMVP.Config
{
    public sealed class UserConfig
    {
        // 实际存储字段
        [JsonPropertyName("userId")]
        public string UserId { get; set; } = string.Empty;
        
        [JsonPropertyName("deviceId")]
        public string DeviceId { get; set; } = string.Empty;
        
        [JsonPropertyName("dataDirectory")]
        public string DataDirectory { get; set; } = string.Empty;
        
        [JsonPropertyName("whiteList")]
        public List<string> WhiteList { get; set; } = new List<string>();

        // 获取安全的数据目录（永不返回null或空）
        public string GetSafeDataDirectory()
        {
            if (!string.IsNullOrWhiteSpace(DataDirectory))
                return DataDirectory;
            
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WinCaptureMVP");
        }

        private static string GetDefaultDataDirectory()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WinCaptureMVP");
        }

        private static string ConfigPath => Path.Combine(
            GetDefaultDataDirectory(),
            "config.json");

        public static UserConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        ReadCommentHandling = JsonCommentHandling.Skip
                    };
                    var config = JsonSerializer.Deserialize<UserConfig>(json, options);
                    
                    if (config != null)
                    {
                        // 修复可能为null的字段
                        config.UserId ??= string.Empty;
                        config.DeviceId = string.IsNullOrWhiteSpace(config.DeviceId) 
                            ? Guid.NewGuid().ToString("N") 
                            : config.DeviceId;
                        config.DataDirectory ??= string.Empty; // 空字符串会在GetSafeDataDirectory中处理
                        config.WhiteList ??= new List<string>();
                        
                        return config;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config load failed: {ex.Message}");
            }
            
            // 返回默认配置
            return new UserConfig
            {
                UserId = string.Empty,
                DeviceId = Guid.NewGuid().ToString("N"),
                DataDirectory = GetDefaultDataDirectory(),
                WhiteList = new List<string>()
            };
        }

        public void Save()
        {
            try
            {
                // 确保关键字段有值
                if (string.IsNullOrWhiteSpace(DeviceId))
                    DeviceId = Guid.NewGuid().ToString("N");
                
                if (string.IsNullOrWhiteSpace(DataDirectory))
                    DataDirectory = GetDefaultDataDirectory();
                
                WhiteList ??= new List<string>();

                var dir = Path.GetDirectoryName(ConfigPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                
                var options = new JsonSerializerOptions 
                { 
                    WriteIndented = true,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                };
                var json = JsonSerializer.Serialize(this, options);
                File.WriteAllText(ConfigPath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config save failed: {ex.Message}");
            }
        }
    }
}

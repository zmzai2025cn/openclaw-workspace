# WinCapture MVP v4.6 部署指南

## 系统要求

| 项目 | 最低要求 | 推荐 |
|------|----------|------|
| Windows 版本 | Windows 7 SP1 (x64) | Windows 10/11 |
| 系统架构 | 64 位 (x64) | 64 位 (x64) |
| 内存 | 4 GB | 8 GB+ |
| 磁盘空间 | 500 MB | 1 GB+ |
| 权限 | 普通用户 | 普通用户 |

## 依赖项检查

### 1. Visual C++ Redistributable
**PaddleOCRSharp 需要 VC++ 运行时**

- **检查方法**: 控制面板 → 程序和功能 → 查找 "Microsoft Visual C++"
- **如果没有**: 下载安装 [VC++ Redist](https://aka.ms/vs/17/release/vc_redist.x64.exe)
- **大多数 Win10/11 已自带**

### 2. 模型文件
**OCR 功能必需，程序启动时会检查**

目录结构:
```
publish/
├── WinCaptureMVP.exe
├── paddleocr_models/
│   ├── ch_PP-OCRv4_det_infer/
│   │   ├── inference.pdmodel
│   │   └── inference.pdiparams
│   ├── ch_PP-OCRv4_rec_infer/
│   │   ├── inference.pdmodel
│   │   └── inference.pdiparams
│   ├── ch_ppocr_mobile_v2.0_cls_infer/ (可选)
│   │   ├── inference.pdmodel
│   │   └── inference.pdiparams
│   └── ppocr_keys.txt
```

**如果缺少模型文件**:
- 程序会启动
- OCR 功能自动禁用
- 截图功能正常
- 日志会记录 "模型文件不完整"

### 3. 数据目录权限
**程序需要写入以下位置**:

```
%LocalAppData%\WinCaptureMVP\
├── worklog.db          (数据库)
├── config.json         (配置文件)
├── app_log.txt         (运行日志)
└── ocr_log.txt         (OCR日志)
```

**权限问题处理**:
- 如果无法写入 LocalAppData，会回退到 `C:\WinCaptureMVP_Data\`
- 如果 C 盘也无权限，程序会报错退出

## 部署步骤

### 方式一：完整部署（推荐）

1. **复制发布文件夹**
   ```
   bin\Release\net6.0-windows\win-x64\publish\
   ```

2. **确保包含**:
   - `WinCaptureMVP.exe`
   - `paddleocr_models\` 文件夹（含模型文件）

3. **运行测试**:
   ```
   WinCaptureMVP.exe
   ```

### 方式二：最小部署（无 OCR）

1. **仅复制**:
   - `WinCaptureMVP.exe`

2. **功能限制**:
   - 截图正常
   - 数据存储正常
   - OCR 文字识别不可用

## 常见问题

### Q1: 程序无法启动，提示缺少 DLL
**原因**: VC++ Redist 未安装  
**解决**: 安装 [VC++ Redist x64](https://aka.ms/vs/17/release/vc_redist.x64.exe)

### Q2: 提示 "不是有效的 Win32 应用程序"
**原因**: 在 32 位 Windows 上运行  
**解决**: 需要 64 位 Windows

### Q3: OCR 初始化失败
**原因**: 
- 模型文件缺失
- VC++ Redist 问题
- 内存不足

**排查**:
1. 检查 `ocr_log.txt`
2. 确认模型文件存在
3. 检查内存使用

### Q4: 数据保存失败
**原因**: 权限问题  
**解决**: 
- 以管理员身份运行（不推荐）
- 或修改 `config.json` 中的 `DataDirectory` 到可写位置

## 兼容性测试清单

在新电脑上测试时，检查以下项目:

- [ ] 程序启动无报错
- [ ] 托盘图标显示正常
- [ ] 配置界面可以打开
- [ ] 数据库文件创建成功 (`worklog.db`)
- [ ] 日志文件有内容 (`app_log.txt`)
- [ ] 截图功能正常（窗口切换时）
- [ ] OCR 识别正常（如果有模型文件）
- [ ] 数据可以保存和查看

## 日志位置

如果出现问题，查看日志:

```
%LocalAppData%\WinCaptureMVP\app_log.txt
%LocalAppData%\WinCaptureMVP\ocr_log.txt
```

或程序目录下的:
```
app_log.txt
ocr_log.txt
```

---

*版本: v4.6*

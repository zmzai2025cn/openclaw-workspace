# WinCapture MVP v4 - PaddleOCRSharp 内嵌版本

## 更新内容

### 1. OCR 引擎更换
- **从**: Tesseract 4.1.1
- **到**: PaddleOCRSharp 4.1.0
- **优势**: 中文识别准确率 95%+（Tesseract 约 85-90%）

### 2. TimelineForm 增强
- 右侧预览区域现在正确显示缩略图
- 新增详细信息面板（ID、时间、应用、窗口、OCR结果）
- 列表中带 📷 标记表示有截图
- 修复了图片流关闭导致的显示问题

## 项目结构

```
wincapture-mvp-v4/
├── WinCaptureMVP.csproj      # 更新：PaddleOCRSharp 依赖
├── Program.cs
├── CaptureEngine.cs
├── Utils/
│   ├── OcrEngine.cs          # 重写：PaddleOCRSharp 版本
│   ├── ScreenCapture.cs
│   ├── ImageHelper.cs
│   └── WindowHelper.cs
├── UI/
│   ├── TimelineForm.cs       # 更新：修复缩略图显示
│   ├── TrayIcon.cs
│   └── ConfigForm.cs
├── Storage/
│   └── WorkLogStorage.cs
├── Config/
│   └── UserConfig.cs
├── Triggers/
│   ├── WindowSwitchTrigger.cs
│   └── IntervalTrigger.cs
└── Sanitizer/
    └── AppFilter.cs
```

## 首次使用步骤

### 1. 下载模型文件

```powershell
# 创建模型目录
mkdir paddleocr_models

# 下载 V4 模型（推荐）
# 从 https://github.com/PaddlePaddle/PaddleOCR/releases 下载：
# - ch_PP-OCRv4_det_infer.tar
# - ch_PP-OCRv4_rec_infer.tar  
# - ch_ppocr_mobile_v2.0_cls_infer.tar
# - ppocr_keys_v1.txt (重命名为 ppocr_keys.txt)
```

### 2. 解压模型

```
paddleocr_models/
├── ch_PP-OCRv4_det_infer/
│   ├── inference.pdmodel
│   └── inference.pdiparams
├── ch_PP-OCRv4_rec_infer/
│   ├── inference.pdmodel
│   └── inference.pdiparams
├── ch_ppocr_mobile_v2.0_cls_infer/
│   ├── inference.pdmodel
│   └── inference.pdiparams
└── ppocr_keys.txt
```

### 3. 编译运行

```bash
cd wincapture-mvp-v4
dotnet restore
dotnet build
dotnet run
```

## 模型文件大小

| 文件 | 大小 |
|------|------|
| ch_PP-OCRv4_det_infer | ~4 MB |
| ch_PP-OCRv4_rec_infer | ~10 MB |
| ch_ppocr_mobile_v2.0_cls_infer | ~1 MB |
| **模型总计** | **~15 MB** |
| PaddleOCRSharp + OpenCvSharp | ~150-200 MB |
| **完整发布包** | **~200 MB** |

## 注意事项

1. **必须 x64**: PaddleOCR 只支持 64 位，项目已配置 `<PlatformTarget>x64</PlatformTarget>`
2. **首次启动慢**: 模型加载需要 2-5 秒，后续识别很快
3. **内存占用**: 约 500MB（比 Tesseract 高，但准确率更好）

## 下载链接

模型文件可以从以下地址下载：
- https://github.com/PaddlePaddle/PaddleOCR/releases/tag/v2.9.1

或者直接使用 PaddleOCRSharp 自带的模型下载功能（首次运行自动下载）。

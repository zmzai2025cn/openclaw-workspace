using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace WinCaptureMVP.Utils
{
    /// <summary>
    /// OCR 引擎 - 基于 PaddleOCRSharp
    /// </summary>
    public static class OcrEngine
    {
        private static readonly object InitLock = new object();
        private static readonly object RecognizeLock = new object(); // 识别操作锁
        private static bool _isInitialized;
        private static bool _initFailed;
        private static PaddleOCRSharp.PaddleOCREngine? _ocrEngine;
        private static readonly string LogPath;

        static OcrEngine()
        {
            // 使用更安全的路径获取方式
            string logDir;
            try
            {
                var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (!string.IsNullOrEmpty(localAppData))
                {
                    logDir = Path.Combine(localAppData, "WinCaptureMVP");
                }
                else
                {
                    logDir = AppContext.BaseDirectory;
                }
            }
            catch
            {
                logDir = AppContext.BaseDirectory;
            }
            
            LogPath = Path.Combine(logDir, "ocr_log.txt");
            
            Initialize();
        }

        private static void Log(string message)
        {
            try
            {
                var dir = Path.GetDirectoryName(LogPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                File.AppendAllText(LogPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}{Environment.NewLine}");
            }
            catch { }
        }

        private static void Initialize()
        {
            lock (InitLock)
            {
                if (_isInitialized || _initFailed) return;

                try
                {
                    // 首先检查 PaddleOCRSharp 是否能正常加载
                    try
                    {
                        var testType = typeof(PaddleOCRSharp.PaddleOCREngine);
                        Log($"PaddleOCRSharp 类型加载成功");
                    }
                    catch (Exception ex)
                    {
                        Log($"错误: 无法加载 PaddleOCRSharp - {ex.Message}");
                        _initFailed = true;
                        return;
                    }

                    var exePath = GetExecutableDirectory();
                    
                    // 确保 exePath 不为空
                    if (string.IsNullOrWhiteSpace(exePath))
                    {
                        Log("错误: 无法获取执行目录");
                        _initFailed = true;
                        return;
                    }
                    
                    // 单文件发布时，尝试多个可能的模型路径
                    string[] possibleModelPaths = new[]
                    {
                        Path.Combine(exePath, "paddleocr_models"),
                        Path.Combine(AppContext.BaseDirectory, "paddleocr_models"),
                        Path.Combine(Environment.CurrentDirectory, "paddleocr_models"),
                        @".\paddleocr_models"
                    };
                    
                    string? modelPath = null;
                    foreach (var path in possibleModelPaths)
                    {
                        Log($"尝试模型路径: {path}");
                        if (Directory.Exists(path))
                        {
                            var detTest = Path.Combine(path, "ch_PP-OCRv4_det_infer");
                            var recTest = Path.Combine(path, "ch_PP-OCRv4_rec_infer");
                            var keysTest = Path.Combine(path, "ppocr_keys.txt");
                            
                            if (Directory.Exists(detTest) && Directory.Exists(recTest) && File.Exists(keysTest))
                            {
                                modelPath = path;
                                Log($"找到有效模型路径: {path}");
                                break;
                            }
                        }
                    }
                    
                    if (modelPath == null)
                    {
                        Log("错误: 无法找到有效的模型路径");
                        _initFailed = true;
                        return;
                    }

                    Log($"初始化开始...");
                    Log($"执行目录: {exePath}");
                    Log($"模型目录: {modelPath}");

                    // 检查模型文件
                    var detPath = Path.Combine(modelPath, "ch_PP-OCRv4_det_infer");
                    var recPath = Path.Combine(modelPath, "ch_PP-OCRv4_rec_infer");
                    var clsPath = Path.Combine(modelPath, "ch_ppocr_mobile_v2.0_cls_infer");
                    var keysPath = Path.Combine(modelPath, "ppocr_keys.txt");

                    var detExists = Directory.Exists(detPath);
                    var recExists = Directory.Exists(recPath);
                    var clsExists = Directory.Exists(clsPath);
                    var keysExists = File.Exists(keysPath);

                    Log($"检测模型: det={detExists}, rec={recExists}, cls={clsExists}, keys={keysExists}");

                    if (!detExists || !recExists || !keysExists)
                    {
                        Log("错误: 模型文件不完整，OCR 功能不可用");
                        _initFailed = true;
                        return;
                    }

                    // 创建配置
                    var config = new PaddleOCRSharp.OCRModelConfig
                    {
                        det_infer = detPath,
                        rec_infer = recPath,
                        cls_infer = clsExists ? clsPath : string.Empty,
                        keys = keysPath
                    };

                    // 创建参数 - 使用保守设置
                    var parameter = new PaddleOCRSharp.OCRParameter
                    {
                        cpu_math_library_num_threads = 2,  // 减少线程数，提高稳定性
                        enable_mkldnn = false,              // 禁用 MKL-DNN，避免兼容性问题
                        cls = clsExists,                    // 只有分类模型存在时才启用
                        use_angle_cls = false,              // 禁用角度分类，简化处理
                        det_db_thresh = 0.3f,
                        det_db_box_thresh = 0.5f,
                        det_db_unclip_ratio = 1.6f,        // 使用更保守的值
                        max_side_len = 960                 // 限制最大边长，减少内存使用
                    };

                    Log("正在创建 OCR 引擎...");
                    _ocrEngine = new PaddleOCRSharp.PaddleOCREngine(config, parameter);
                    _isInitialized = true;
                    Log("OCR 引擎初始化成功");
                }
                catch (DllNotFoundException ex)
                {
                    Log($"错误: 缺少 DLL - {ex.Message}");
                    _initFailed = true;
                }
                catch (BadImageFormatException ex)
                {
                    Log($"错误: DLL 架构不匹配 - {ex.Message}");
                    _initFailed = true;
                }
                catch (Exception ex)
                {
                    Log($"错误: OCR 初始化失败 - {ex.Message}");
                    Log($"堆栈: {ex.StackTrace}");
                    _initFailed = true;
                }
            }
        }

        /// <summary>
        /// 获取执行文件所在目录（支持单文件发布）
        /// </summary>
        private static string GetExecutableDirectory()
        {
            try
            {
                // 方法1: 使用进程主模块
                var mainModule = System.Diagnostics.Process.GetCurrentProcess().MainModule;
                if (mainModule?.FileName != null)
                {
                    var dir = Path.GetDirectoryName(mainModule.FileName);
                    if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                    {
                        return dir;
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"获取执行目录(方法1)失败: {ex.Message}");
            }

            try
            {
                // 方法2: 使用 AppContext
                var baseDir = AppContext.BaseDirectory;
                if (!string.IsNullOrEmpty(baseDir) && Directory.Exists(baseDir))
                {
                    return baseDir;
                }
            }
            catch (Exception ex)
            {
                Log($"获取执行目录(方法2)失败: {ex.Message}");
            }

            try
            {
                // 方法3: 使用当前目录
                var currentDir = Environment.CurrentDirectory;
                if (!string.IsNullOrEmpty(currentDir) && Directory.Exists(currentDir))
                {
                    return currentDir;
                }
            }
            catch (Exception ex)
            {
                Log($"获取执行目录(方法3)失败: {ex.Message}");
            }

            // 最终 fallback
            return ".";
        }

        /// <summary>
        /// 识别图片中的文字
        /// </summary>
        /// <param name="image">图片</param>
        /// <returns>识别出的文字，失败返回 null</returns>
        public static string? Recognize(Bitmap? image)
        {
            // 前置检查
            if (!_isInitialized)
            {
                Log("识别跳过: OCR 未初始化");
                return null;
            }

            if (_ocrEngine == null)
            {
                Log("识别跳过: OCR 引擎为空");
                return null;
            }

            if (image == null)
            {
                Log("识别跳过: 图片为空");
                return null;
            }

            if (image.Width == 0 || image.Height == 0)
            {
                Log("识别跳过: 图片尺寸为0");
                return null;
            }

            try
            {
                // 转换为字节数组
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    // 使用 PNG 格式，无损压缩
                    image.Save(ms, ImageFormat.Png);
                    imageBytes = ms.ToArray();
                }

                if (imageBytes.Length == 0)
                {
                    Log("识别跳过: 图片字节为空");
                    return null;
                }

                Log($"开始识别，图片大小: {imageBytes.Length} bytes");

                // 调用 OCR（加锁确保线程安全）
                PaddleOCRSharp.OCRResult? result;
                lock (RecognizeLock)
                {
                    result = _ocrEngine.DetectText(imageBytes);
                }
                
                if (result == null)
                {
                    Log("识别结果为空");
                    return null;
                }

                var text = result.Text?.Trim();
                
                Log($"识别完成，文字长度: {text?.Length ?? 0}");
                
                return text;
            }
            catch (Exception ex)
            {
                Log($"识别异常: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 获取 OCR 初始化状态
        /// </summary>
        public static bool IsInitialized => _isInitialized;

        /// <summary>
        /// 释放 OCR 资源
        /// </summary>
        public static void Dispose()
        {
            lock (InitLock)
            {
                try
                {
                    _ocrEngine?.Dispose();
                }
                catch (Exception ex)
                {
                    Log($"释放资源异常: {ex.Message}");
                }
                finally
                {
                    _ocrEngine = null;
                    _isInitialized = false;
                    Log("OCR 资源已释放");
                }
            }
        }
    }
}

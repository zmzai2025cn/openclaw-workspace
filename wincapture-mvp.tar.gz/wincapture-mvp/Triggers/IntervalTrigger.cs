using System;
using System.Threading;
using System.Windows.Forms;

namespace WinCaptureMVP.Triggers
{
    public class IntervalTrigger : ITrigger
    {
        private readonly Action<CaptureEngine.TriggerType, string> _callback;
        private Timer _timer;
        private bool _isPaused;
        private readonly int _intervalMs = 30000; // 30 秒

        public IntervalTrigger(Action<CaptureEngine.TriggerType, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _timer = new Timer(OnInterval, null, _intervalMs, _intervalMs);
        }

        public void Stop()
        {
            _timer?.Dispose();
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void OnInterval(object state)
        {
            if (_isPaused) return;
            _callback?.Invoke(CaptureEngine.TriggerType.Interval, "定时兜底");
        }
    }
}
# Windows 采集端构建指南

## 环境要求

- Windows 10/11
- .NET 6 SDK (https://dotnet.microsoft.com/download/dotnet/6.0)
- Visual Studio 2022 或 VS Code

## 快速构建

### 1. 克隆代码

```bash
git clone <repo-url>
cd wincapture-mvp
```

### 2. 还原依赖

```bash
dotnet restore
```

### 3. 构建调试版

```bash
dotnet build
```

### 4. 发布单文件 EXE

```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
```

输出位置：
```
bin/Release/net6.0-windows/win-x64/publish/WinCaptureMVP.exe
```

## 运行测试

### 1. 首次运行

双击 `WinCaptureMVP.exe`：
- 显示配置窗口
- 输入服务器地址和用户ID
- 点击保存

### 2. 正常运行

- 程序最小化到托盘
- 右键托盘图标可暂停/配置/退出
- 自动采集屏幕并上传

### 3. 查看日志

日志位置：
```
%LOCALAPPDATA%/WinCaptureMVP/
```

## 配置说明

配置文件位置：
```
%LOCALAPPDATA%/WinCaptureMVP/config.json
```

示例配置：
```json
{
  "UserId": "user_001",
  "DeviceId": "abc123",
  "ServerUrl": "http://localhost:3000/upload",
  "EncryptionKey": "your-secret-key",
  "WhiteList": ["code", "chrome", "outlook"],
  "CpuThreshold": 10,
  "MemoryThreshold": 100
}
```

## 常见问题

### Q: 运行时报缺少 .NET 运行时？
A: 使用 `--self-contained true` 发布的版本已包含运行时，无需安装。

### Q: 如何完全卸载？
A: 删除以下位置：
- 程序目录
- `%LOCALAPPDATA%/WinCaptureMVP/`

### Q: 如何调试？
A: 使用 Visual Studio 打开项目，F5 运行调试。

## 生产部署

### 方式1：单文件分发
- 复制 `WinCaptureMVP.exe` 到员工电脑
- 双击运行，配置后自动最小化

### 方式2：安装包（推荐）
使用 Inno Setup 创建安装包：
1. 安装 Inno Setup
2. 使用 `setup.iss` 脚本构建
3. 分发安装包给员工

### 方式3：组策略推送
IT 管理员通过 AD 组策略统一安装。

## 下一步集成

1. 启动 Kimiclaw DB 服务
2. 配置采集端指向 DB 服务地址
3. 验证数据上传
4. 查看分析结果
using System;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public class ConfigForm : Form
    {
        private readonly Config.UserConfig _config;
        private TextBox _serverUrlTextBox;
        private TextBox _userIdTextBox;
        private Button _saveButton;
        private Button _cancelButton;

        public ConfigForm(Config.UserConfig config)
        {
            _config = config;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text = "配置";
            Size = new System.Drawing.Size(400, 250);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;

            var y = 20;

            // 服务器地址
            var serverLabel = new Label { Text = "服务器地址:", Location = new System.Drawing.Point(20, y), Width = 100 };
            _serverUrlTextBox = new TextBox 
            { 
                Text = _config.ServerUrl, 
                Location = new System.Drawing.Point(130, y), 
                Width = 220 
            };
            Controls.Add(serverLabel);
            Controls.Add(_serverUrlTextBox);

            y += 40;

            // 用户ID
            var userIdLabel = new Label { Text = "用户ID:", Location = new System.Drawing.Point(20, y), Width = 100 };
            _userIdTextBox = new TextBox 
            { 
                Text = _config.UserId, 
                Location = new System.Drawing.Point(130, y), 
                Width = 220 
            };
            Controls.Add(userIdLabel);
            Controls.Add(_userIdTextBox);

            y += 60;

            // 按钮
            _saveButton = new Button 
            { 
                Text = "保存", 
                Location = new System.Drawing.Point(130, y), 
                Width = 80,
                DialogResult = DialogResult.OK
            };
            _saveButton.Click += OnSave;

            _cancelButton = new Button 
            { 
                Text = "取消", 
                Location = new System.Drawing.Point(230, y), 
                Width = 80,
                DialogResult = DialogResult.Cancel
            };

            Controls.Add(_saveButton);
            Controls.Add(_cancelButton);

            AcceptButton = _saveButton;
            CancelButton = _cancelButton;
        }

        private void OnSave(object sender, EventArgs e)
        {
            _config.ServerUrl = _serverUrlTextBox.Text;
            _config.UserId = _userIdTextBox.Text;
            _config.Save();
            Close();
        }
    }
}
using System;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // 单例检查
            if (IsAlreadyRunning())
            {
                MessageBox.Show("采集端已在运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 加载配置
            var config = Config.UserConfig.Load();
            
            // 首次运行显示配置
            if (string.IsNullOrEmpty(config.ServerUrl))
            {
                using (var form = new UI.ConfigForm(config))
                {
                    if (form.ShowDialog() != DialogResult.OK)
                    {
                        return;
                    }
                }
            }

            // 启动采集引擎
            var engine = new CaptureEngine(config);
            
            // 初始化托盘
            var tray = new UI.TrayIcon(engine);
            
            // 启动引擎
            engine.Start();

            Application.Run();
        }

        static bool IsAlreadyRunning()
        {
            var mutexName = "WinCaptureMVP_SingleInstance";
            try
            {
                System.Threading.Mutex.OpenExisting(mutexName);
                return true;
            }
            catch
            {
                new System.Threading.Mutex(true, mutexName);
                return false;
            }
        }
    }
}
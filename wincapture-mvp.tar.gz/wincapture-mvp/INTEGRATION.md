# 采集端与 Kimiclaw DB 集成接口

## 接口定义

### 上传端点

```
POST /api/capture/upload
Content-Type: application/json
Authorization: Bearer {api_key}
```

### 请求体格式

```json
{
  "timestamp": "2024-02-20T10:30:00Z",
  "user_id": "user_001",
  "device_id": "device_abc123",
  "session_id": "auto_generated",
  "trigger_type": "window_switch|pixel_diff|interval",
  "app_name": "Visual Studio Code",
  "window_title": "Program.cs - WinCaptureMVP",
  "image_encrypted": "base64_aes_encrypted_string",
  "text_features": "perceptual_hash_string",
  "metadata": {
    "screen_resolution": "1920x1080",
    "cpu_usage": 15.5,
    "memory_usage": 256
  }
}
```

### 响应格式

成功：
```json
{
  "success": true,
  "message_id": "msg_abc123",
  "session_id": "sess_xyz789"
}
```

失败：
```json
{
  "success": false,
  "error": "Invalid API key",
  "code": 401
}
```

## 数据流

```
[Windows采集端] --HTTPS--> [Kimiclaw DB API] --> [DuckDB存储] --> [分析处理]
```

## 关键字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| timestamp | ISO8601 | UTC时间 |
| user_id | string | 员工唯一标识 |
| device_id | string | 设备唯一标识 |
| session_id | string | 任务会话ID（服务端生成或客户端计算）|
| trigger_type | enum | 触发类型 |
| app_name | string | 应用名称 |
| window_title | string | 窗口标题 |
| image_encrypted | base64 | AES加密后的图片 |
| text_features | string | 感知哈希（用于相似度检测）|
| metadata | object | 性能指标等 |

## Session 生成规则

客户端计算：
```
session_id = hash(user_id + app_name + window_title + hour_timestamp)
```

服务端可覆盖，支持人工合并/拆分。

## 安全要求

1. **HTTPS 传输**：生产环境必须
2. **API Key 认证**：Header 中携带
3. **AES 加密**：图片加密后传输
4. **原图不存**：服务端解密分析后即焚

## 实现状态

- [x] 采集端数据格式定义
- [x] 加密传输实现
- [ ] Kimiclaw DB 接口端点（待实现）
- [ ] 联调测试（待进行）

## 下一步

1. 在 Kimiclaw DB 中实现 `/api/capture/upload` 端点
2. 配置采集端指向服务端地址
3. 端到端测试验证
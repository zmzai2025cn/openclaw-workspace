# 常见问题解决

## 目的
记录问题及解决方案，避免重复踩坑。

## 问题列表

### 1. 编译错误：Duplicate 'Compile' items
**症状**：
```
error NETSDK1022: Duplicate 'Compile' items were included
```

**原因**：
.NET SDK 默认自动包含所有 .cs 文件，不需要显式指定。

**解决**：
移除 csproj 中的 `<Compile Include="..." />` 行。

---

### 2. Tesseract 初始化失败
**症状**：
```
TesseractException: Failed to initialise tesseract engine
```

**原因**：
1. 缺少 VC++ 2015-2022 x64 运行时（90%）
2. 语言包版本不匹配（5%）
3. x86/x64 架构不匹配（5%）

**解决**：
1. 安装 https://aka.ms/vs/17/release/vc_redist.x64.exe
2. 重新下载语言包
3. 确保 PlatformTarget 为 x64

---

### 3. OCR 识别缺字
**症状**：
识别结果中文字不完整，缺少部分内容。

**原因**：
1. 二值化过度，导致细文字丢失
2. 页面分割模式不适合
3. 小字被过滤

**解决**：
- v1.2.1 已修复
- 降低二值化阈值
- 设置 `tessedit_pageseg_mode=6`
- 设置 `textord_min_linesize=2.5`

---

### 4. 识别率低
**症状**：
大量错字、漏字。

**解决**：
1. 使用图像预处理（v1.2+）
2. 尝试 best 语言包：https://github.com/tesseract-ocr/tessdata_best
3. 确保截图清晰、文字不小于 12pt
4. 只截取文字区域，避免全屏

---

### 5. PowerShell 脚本执行错误
**症状**：
```
表达式或语句中包含意外的标记
```

**原因**：
PowerShell 版本或编码问题。

**解决**：
使用简化版脚本：`.\scripts\setup-minimal.ps1`

## 添加新问题
按以下格式记录：
```markdown
### 问题标题
**症状**：
错误信息或现象

**原因**：
1. 原因1
2. 原因2

**解决**：
具体步骤
```

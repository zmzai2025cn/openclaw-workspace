using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Tesseract;

namespace WinCaptureOCR
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            Log("Program.Main started");
            
            Application.ThreadException += (s, e) => 
            {
                Log($"ThreadException: {e.Exception}");
                MessageBox.Show($"Error: {e.Exception.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Log($"UnhandledException: {e.ExceptionObject}");
                MessageBox.Show($"Fatal: {e.ExceptionObject}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Log("Creating MainForm");
            Application.Run(new MainForm());
            
            Log("Program ended");
        }
        
        private static void Log(string msg)
        {
            var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wincapture.log");
            var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {msg}";
            try { File.AppendAllText(logPath, line + Environment.NewLine); } catch { }
        }
    }

    public class MainForm : Form
    {
        private Button btnCapture = null!;
        private TextBox txtResult = null!;
        private TesseractEngine? engine;
        private bool isInitialized = false;

        public MainForm()
        {
            Log("MainForm constructor started");
            
            Text = "WinCapture OCR v1.2.1";
            Size = new Size(800, 600);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(400, 300);

            Log("Creating controls");
            CreateControls();
            
            Log("Setting up Load event");
            this.Load += (s, e) => InitializeTesseractAsync();
            
            Log("MainForm constructor completed");
        }

        private void CreateControls()
        {
            Log("CreateControls started");
            
            btnCapture = new Button
            {
                Text = "Capture & OCR",
                Location = new Point(10, 10),
                Size = new Size(120, 35),
                Enabled = false
            };
            btnCapture.Click += async (s, e) => await OnCaptureClickAsync();

            txtResult = new TextBox
            {
                Multiline = true,
                Location = new Point(10, 55),
                Size = new Size(760, 490),
                ScrollBars = ScrollBars.Both,
                ReadOnly = true,
                Text = "Initializing..."
            };

            this.Resize += (s, e) =>
            {
                txtResult.Size = new Size(this.ClientSize.Width - 20, this.ClientSize.Height - 65);
            };

            Controls.Add(btnCapture);
            Controls.Add(txtResult);
            
            Log("CreateControls completed");
        }

        private async void InitializeTesseractAsync()
        {
            Log("InitializeTesseractAsync started");
            await System.Threading.Tasks.Task.Run(() => InitializeTesseract());
            Log("InitializeTesseractAsync completed");
        }

        private void InitializeTesseract()
        {
            Log("InitializeTesseract started");
            
            try
            {
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                Log($"Base directory: {baseDir}");
                
                var tessdataPath = Path.Combine(baseDir, "tessdata");
                Log($"Tessdata path: {tessdataPath}");
                
                if (!Directory.Exists(tessdataPath))
                {
                    Log("ERROR: tessdata directory not found");
                    Invoke(() => ShowError("Missing tessdata directory",
                        "Please download language pack to tessdata folder."));
                    return;
                }
                Log("tessdata directory exists");

                var chiSimPath = Path.Combine(tessdataPath, "chi_sim.traineddata");
                Log($"Checking: {chiSimPath}");
                
                if (!File.Exists(chiSimPath))
                {
                    Log("ERROR: chi_sim.traineddata not found");
                    Invoke(() => ShowError("Missing language pack",
                        "Please download chi_sim.traineddata to tessdata folder."));
                    return;
                }
                
                var fileInfo = new FileInfo(chiSimPath);
                Log($"chi_sim.traineddata found, size: {fileInfo.Length} bytes");

                var engPath = Path.Combine(tessdataPath, "eng.traineddata");
                var lang = File.Exists(engPath) ? "chi_sim+eng" : "chi_sim";
                Log($"Language: {lang}");

                Invoke(() => txtResult.Text = "Loading OCR engine...");
                
                Log("Creating TesseractEngine...");
                engine = new TesseractEngine(tessdataPath, lang, EngineMode.Default);
                
                // 设置 Tesseract 参数以提高识别率和字符数
                engine.SetVariable("tessedit_pageseg_mode", "6"); // 统一文本块模式，适合连续文本
                engine.SetVariable("preserve_interword_spaces", "1"); // 保留空格
                engine.SetVariable("textord_min_linesize", "2.5"); // 最小行高，识别小字
                
                isInitialized = true;
                Log($"TesseractEngine created, version: {engine.Version}");

                Invoke(() =>
                {
                    btnCapture.Enabled = true;
                    txtResult.Text = $"Ready! Version: {engine.Version}, Language: {lang}";
                });
            }
            catch (TesseractException ex) when (ex.Message.Contains("Failed to initialise"))
            {
                Log($"TesseractException: {ex.Message}");
                Invoke(() => ShowError("Tesseract init failed",
                    "Missing VC++ runtime or language pack mismatch.\n\n" +
                    "Install: https://aka.ms/vs/17/release/vc_redist.x64.exe"));
            }
            catch (DllNotFoundException ex)
            {
                Log($"DllNotFoundException: {ex.Message}");
                Invoke(() => ShowError("Missing DLL",
                    $"Required DLL not found: {ex.Message}"));
            }
            catch (Exception ex)
            {
                Log($"Exception: {ex.GetType().Name}: {ex.Message}");
                Invoke(() => ShowError("Init failed", $"{ex.GetType().Name}: {ex.Message}"));
            }
            
            Log("InitializeTesseract completed");
        }

        private async System.Threading.Tasks.Task OnCaptureClickAsync()
        {
            Log("OnCaptureClickAsync started");
            
            if (!isInitialized || engine == null)
            {
                Log("ERROR: Engine not initialized");
                MessageBox.Show("OCR engine not initialized", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnCapture.Enabled = false;
            txtResult.Text = "Processing...";

            try
            {
                Log("Minimizing window");
                this.WindowState = FormWindowState.Minimized;
                await System.Threading.Tasks.Task.Delay(500);

                Log("Starting capture and recognize");
                var result = await System.Threading.Tasks.Task.Run(() => CaptureAndRecognize());
                
                Log("Restoring window");
                this.WindowState = FormWindowState.Normal;
                this.Activate();
                txtResult.Text = result;
            }
            catch (Exception ex)
            {
                Log($"Exception in OnCaptureClickAsync: {ex}");
                this.WindowState = FormWindowState.Normal;
                txtResult.Text = $"Error: {ex.Message}";
            }
            finally
            {
                btnCapture.Enabled = true;
            }
            
            Log("OnCaptureClickAsync completed");
        }

        private string CaptureAndRecognize()
        {
            Log("CaptureAndRecognize started");
            
            var screen = Screen.PrimaryScreen;
            if (screen == null)
            {
                Log("ERROR: Screen.PrimaryScreen is null");
                return "Error: Cannot get screen info";
            }
            
            Log($"Screen bounds: {screen.Bounds.Width}x{screen.Bounds.Height}");

            int width = Math.Min(screen.Bounds.Width, 3840);
            int height = Math.Min(screen.Bounds.Height, 2160);
            Log($"Capture size: {width}x{height}");

            try
            {
                using var bitmap = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                using (var g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, new Size(width, height));
                }
                Log("Screen captured");

                // 预处理图像
                Log("Preprocessing image...");
                using var processedBitmap = ImagePreprocessor.Preprocess(bitmap);
                Log("Image preprocessed");

                var tempPath = Path.Combine(Path.GetTempPath(), $"ocr_{Guid.NewGuid()}.png");
                Log($"Temp file: {tempPath}");
                
                processedBitmap.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);
                Log("Processed bitmap saved");

                using var img = Pix.LoadFromFile(tempPath);
                Log("Pix loaded");
                
                using var page = engine!.Process(img);
                Log("Page processed");
                
                // 获取详细识别信息
                var text = page.GetText()?.Trim();
                var confidence = page.GetMeanConfidence();
                var wordCount = page.GetWordCount();
                
                Log($"OCR Stats - Chars: {text?.Length ?? 0}, Words: {wordCount}, Confidence: {confidence:P}");

                try { File.Delete(tempPath); } catch { }

                if (string.IsNullOrWhiteSpace(text))
                {
                    return "No text recognized.";
                }

                return $"Result ({text.Length} chars, {wordCount} words, {confidence:P} confidence):\n{text}";
            }
            catch (Exception ex)
            {
                Log($"Exception in CaptureAndRecognize: {ex}");
                return $"Error: {ex.Message}";
            }
        }

        private void ShowError(string title, string message)
        {
            Log($"ShowError: {title}");
            txtResult.Text = $"ERROR: {title}\n\n{message}";
            txtResult.ForeColor = Color.DarkRed;
        }

        private void Log(string msg)
        {
            var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wincapture.log");
            var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [MainForm] {msg}";
            try { File.AppendAllText(logPath, line + Environment.NewLine); } catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Log("OnFormClosing");
            try { engine?.Dispose(); } catch { }
            base.OnFormClosing(e);
        }
    }
}

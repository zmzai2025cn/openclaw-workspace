# WinCaptureOCR v1.2.1

## 最新版本

### v1.2.1 (2026-02-20)
- 修复 OCR 识别缺字问题
  - 优化 Tesseract 参数（页面分割模式、空格保留、小字识别）
  - 调整二值化阈值，防止过度处理
  - 增强调试信息（字符数、单词数统计）

### v1.2.0 (2026-02-20)
- 添加图像预处理提高识别率
  - 2x 放大
  - 灰度转换
  - 自适应二值化（Otsu 算法）

### v1.1.0 (2026-02-20)
- 添加调试日志
- 修复编译警告
- 增强错误处理

## 系统要求
- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)

## 快速开始
```powershell
# 1. 解压
# 2. 运行安装脚本
.\scripts\setup.ps1

# 3. 复制语言包
Copy-Item "chi_sim.traineddata" "tessdata\" -Force

# 4. 运行
dotnet run
```

## 语言包下载
- 中文：https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata
- 英文：https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata

## 调试
查看 `wincapture.log` 了解详细执行过程。

## 文档导航
| 文档 | 内容 |
|------|------|
| docs/01-QUICKSTART.md | 5分钟快速上手 |
| docs/04-COMMON-ISSUES.md | 常见问题解决 |
| docs/07-IMPROVE-ACCURACY.md | 提高识别率指南 |
| docs/08-BUILD-ANALYSIS.md | 编译流程分析 |

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace WinCaptureOCR
{
    public static class ImagePreprocessor
    {
        /// <summary>
        /// 预处理图像以提高 OCR 识别率
        /// </summary>
        public static Bitmap Preprocess(Bitmap source)
        {
            Log("Preprocess started");
            
            // 1. 放大 2 倍（提高分辨率）
            var scaled = ScaleImage(source, 2.0);
            Log($"Scaled to {scaled.Width}x{scaled.Height}");
            
            // 2. 转换为灰度图
            var gray = ConvertToGrayscale(scaled);
            Log("Converted to grayscale");
            
            // 3. 二值化（自适应阈值）
            var binary = AdaptiveThreshold(gray);
            Log("Applied adaptive threshold");
            
            // 清理中间图像
            scaled.Dispose();
            gray.Dispose();
            
            Log("Preprocess completed");
            return binary;
        }
        
        /// <summary>
        /// 放大图像
        /// </summary>
        private static Bitmap ScaleImage(Bitmap source, double scale)
        {
            int newWidth = (int)(source.Width * scale);
            int newHeight = (int)(source.Height * scale);
            
            var result = new Bitmap(newWidth, newHeight);
            using (var g = Graphics.FromImage(result))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(source, 0, 0, newWidth, newHeight);
            }
            return result;
        }
        
        /// <summary>
        /// 转换为灰度图
        /// </summary>
        private static Bitmap ConvertToGrayscale(Bitmap source)
        {
            var result = new Bitmap(source.Width, source.Height);
            
            using (var g = Graphics.FromImage(result))
            {
                var colorMatrix = new ColorMatrix(new float[][]
                {
                    new float[] {0.299f, 0.299f, 0.299f, 0, 0},
                    new float[] {0.587f, 0.587f, 0.587f, 0, 0},
                    new float[] {0.114f, 0.114f, 0.114f, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1}
                });
                
                using var attributes = new ImageAttributes();
                attributes.SetColorMatrix(colorMatrix);
                g.DrawImage(source, new Rectangle(0, 0, result.Width, result.Height),
                    0, 0, source.Width, source.Height, GraphicsUnit.Pixel, attributes);
            }
            
            return result;
        }
        
        /// <summary>
        /// 自适应阈值二值化（调整阈值保留更多文字）
        /// </summary>
        private static Bitmap AdaptiveThreshold(Bitmap source)
        {
            var result = new Bitmap(source.Width, source.Height);
            
            // 使用 Otsu 算法计算阈值
            int otsuThreshold = CalculateOtsuThreshold(source);
            
            // 降低阈值以保留更多文字（防止过度二值化导致文字丢失）
            int threshold = Math.Max(0, otsuThreshold - 10);
            
            Log($"Otsu threshold: {otsuThreshold}, Adjusted: {threshold}");
            
            int whitePixels = 0;
            int blackPixels = 0;
            
            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    var pixel = source.GetPixel(x, y);
                    int gray = pixel.R; // 已经是灰度图
                    var newColor = gray > threshold ? Color.White : Color.Black;
                    result.SetPixel(x, y, newColor);
                    
                    if (newColor == Color.White) whitePixels++;
                    else blackPixels++;
                }
            }
            
            Log($"Binary result: {whitePixels} white, {blackPixels} black pixels");
            
            return result;
        }
        
        /// <summary>
        /// Otsu 算法计算最佳阈值
        /// </summary>
        private static int CalculateOtsuThreshold(Bitmap source)
        {
            int[] histogram = new int[256];
            int totalPixels = source.Width * source.Height;
            
            // 计算直方图
            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    var pixel = source.GetPixel(x, y);
                    histogram[pixel.R]++;
                }
            }
            
            // Otsu 算法
            float sum = 0;
            for (int i = 0; i < 256; i++) sum += i * histogram[i];
            
            float sumB = 0;
            int wB = 0;
            int wF = 0;
            float maxVariance = 0;
            int threshold = 0;
            
            for (int i = 0; i < 256; i++)
            {
                wB += histogram[i];
                if (wB == 0) continue;
                
                wF = totalPixels - wB;
                if (wF == 0) break;
                
                sumB += i * histogram[i];
                float mB = sumB / wB;
                float mF = (sum - sumB) / wF;
                float variance = (float)wB * wF * (mB - mF) * (mB - mF);
                
                if (variance > maxVariance)
                {
                    maxVariance = variance;
                    threshold = i;
                }
            }
            
            return threshold;
        }
        
        private static void Log(string msg)
        {
            var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wincapture.log");
            var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [Preprocessor] {msg}";
            try { File.AppendAllText(logPath, line + Environment.NewLine); } catch { }
        }
    }
}

# 运行脚本
dotnet run --project .\WinCaptureOCR.csproj

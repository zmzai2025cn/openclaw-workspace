using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WinCaptureOCR
{
    /// <summary>
    /// OCR 日志管理器
    /// </summary>
    public static class OcrLogManager
    {
        private static readonly List<OcrLogEntry> Entries = new List<OcrLogEntry>();
        private static readonly object Lock = new object();
        private static readonly string LogFilePath;
        
        static OcrLogManager()
        {
            LogFilePath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, 
                "ocr_history.txt");
            LoadFromFile();
        }
        
        /// <summary>
        /// 添加 OCR 记录
        /// </summary>
        public static void AddEntry(string text, double confidence)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            
            var entry = new OcrLogEntry
            {
                Timestamp = DateTime.Now,
                Text = text.Trim(),
                Confidence = confidence
            };
            
            lock (Lock)
            {
                Entries.Add(entry);
                // 只保留最近 1000 条
                if (Entries.Count > 1000)
                {
                    Entries.RemoveAt(0);
                }
            }
            
            // 异步保存到文件
            System.Threading.Tasks.Task.Run(() => SaveToFile(entry));
        }
        
        /// <summary>
        /// 获取所有记录
        /// </summary>
        public static List<OcrLogEntry> GetAllEntries()
        {
            lock (Lock)
            {
                return new List<OcrLogEntry>(Entries);
            }
        }
        
        /// <summary>
        /// 清空记录
        /// </summary>
        public static void Clear()
        {
            lock (Lock)
            {
                Entries.Clear();
            }
            try { File.Delete(LogFilePath); } catch { }
        }
        
        /// <summary>
        /// 搜索记录
        /// </summary>
        public static List<OcrLogEntry> Search(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
                return GetAllEntries();
            
            lock (Lock)
            {
                return Entries.FindAll(e => 
                    e.Text.Contains(keyword, StringComparison.OrdinalIgnoreCase));
            }
        }
        
        private static void SaveToFile(OcrLogEntry entry)
        {
            try
            {
                var line = $"[{entry.Timestamp:yyyy-MM-dd HH:mm:ss}] [{entry.Confidence:P}] {entry.Text.Replace('\n', ' ')}";
                File.AppendAllText(LogFilePath, line + Environment.NewLine);
            }
            catch { }
        }
        
        private static void LoadFromFile()
        {
            try
            {
                if (!File.Exists(LogFilePath)) return;
                
                var lines = File.ReadAllLines(LogFilePath);
                foreach (var line in lines)
                {
                    // 简单解析，格式：[2026-02-20 21:00:00] [95.5%] 识别的文字
                    if (line.Length < 30) continue;
                    
                    var entry = new OcrLogEntry
                    {
                        Timestamp = DateTime.Now, // 简化处理
                        Text = line.Length > 30 ? line.Substring(30) : line,
                        Confidence = 0
                    };
                    Entries.Add(entry);
                }
                
                // 只保留最近 1000 条
                if (Entries.Count > 1000)
                {
                    Entries.RemoveRange(0, Entries.Count - 1000);
                }
            }
            catch { }
        }
    }
    
    /// <summary>
    /// OCR 日志条目
    /// </summary>
    public class OcrLogEntry
    {
        public DateTime Timestamp { get; set; }
        public string Text { get; set; } = "";
        public double Confidence { get; set; }
    }
}

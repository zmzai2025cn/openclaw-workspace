using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Tesseract;

namespace WinCaptureOCR
{
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            Log("Program.Main started");
            
            Application.ThreadException += (s, e) => 
            {
                Log($"ThreadException: {e.Exception}");
            };
            
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Log($"UnhandledException: {e.ExceptionObject}");
            };

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Log("Creating MainForm");
            Application.Run(new MainForm());
            
            Log("Program ended");
        }
        
        private static readonly object LogLock = new object();
        
        private static void Log(string msg)
        {
            lock (LogLock)
            {
                var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wincapture.log");
                var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {msg}";
                try { File.AppendAllText(logPath, line + Environment.NewLine); } catch { }
            }
        }
    }

    public class MainForm : Form
    {
        private NotifyIcon notifyIcon;
        private ContextMenuStrip trayMenu;
        private System.Timers.Timer captureTimer;
        private TesseractEngine? engine;
        private bool isInitialized = false;
        private int captureInterval = 10000; // 10 seconds
        
        // UI Controls (only shown when opening settings)
        private Button btnCapture;
        private TextBox txtResult;
        private NumericUpDown numInterval;

        public MainForm()
        {
            Text = "WinCapture OCR v1.5.0";
            Size = new Size(800, 600);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(600, 400);
            
            // Hide window initially, show only settings
            WindowState = FormWindowState.Minimized;
            ShowInTaskbar = false;
            
            InitializeTrayIcon();
            InitializeTimer();
            InitializeUI();
            
            // Initialize OCR in background
            System.Threading.Tasks.Task.Run(() => InitializeTesseract());
        }
        
        private void InitializeTrayIcon()
        {
            trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("View Logs", null, OnViewLogs);
            trayMenu.Items.Add("Settings", null, OnShowSettings);
            trayMenu.Items.Add(new ToolStripSeparator());
            trayMenu.Items.Add("Exit", null, OnExit);
            
            notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "WinCapture OCR v1.5.0",
                Visible = true,
                ContextMenuStrip = trayMenu
            };
            
            notifyIcon.DoubleClick += OnViewLogs;
        }
        
        private void InitializeTimer()
        {
            captureTimer = new System.Timers.Timer(captureInterval);
            captureTimer.Elapsed += OnTimerElapsed;
            captureTimer.AutoReset = true;
            captureTimer.Start();
            Log($"Timer started with interval: {captureInterval}ms");
        }
        
        private void InitializeUI()
        {
            // Manual capture button
            btnCapture = new Button
            {
                Text = "Capture Now",
                Location = new Point(10, 10),
                Size = new Size(120, 35),
                Enabled = false
            };
            btnCapture.Click += (s, e) => System.Threading.Tasks.Task.Run(() => CaptureAndLog());
            
            // Interval setting
            var lblInterval = new Label
            {
                Text = "Capture interval (seconds):",
                Location = new Point(10, 55),
                AutoSize = true
            };
            
            numInterval = new NumericUpDown
            {
                Location = new Point(180, 53),
                Size = new Size(80, 25),
                Minimum = 5,
                Maximum = 300,
                Value = captureInterval / 1000
            };
            numInterval.ValueChanged += OnIntervalChanged;
            
            // Result display
            txtResult = new TextBox
            {
                Multiline = true,
                Location = new Point(10, 90),
                Size = new Size(760, 450),
                ScrollBars = ScrollBars.Both,
                ReadOnly = true,
                Text = "Initializing..."
            };
            
            Controls.Add(btnCapture);
            Controls.Add(lblInterval);
            Controls.Add(numInterval);
            Controls.Add(txtResult);
        }
        
        private void InitializeTesseract()
        {
            Log("InitializeTesseract started");
            
            try
            {
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                var tessdataPath = Path.Combine(baseDir, "tessdata");
                
                if (!Directory.Exists(tessdataPath))
                {
                    Log("ERROR: tessdata directory not found");
                    UpdateStatus("Error: Missing tessdata directory");
                    return;
                }

                var chiSimPath = Path.Combine(tessdataPath, "chi_sim.traineddata");
                if (!File.Exists(chiSimPath))
                {
                    Log("ERROR: chi_sim.traineddata not found");
                    UpdateStatus("Error: Missing language pack");
                    return;
                }

                var engPath = Path.Combine(tessdataPath, "eng.traineddata");
                var lang = File.Exists(engPath) ? "chi_sim+eng" : "chi_sim";

                engine = new TesseractEngine(tessdataPath, lang, EngineMode.Default);
                engine.SetVariable("tessedit_pageseg_mode", "6");
                engine.SetVariable("preserve_interword_spaces", "1");
                engine.SetVariable("textord_min_linesize", "2.5");
                
                isInitialized = true;
                Log($"TesseractEngine created, version: {engine.Version}");
                
                Invoke(() =>
                {
                    btnCapture.Enabled = true;
                    txtResult.Text = $"Ready! Auto-capturing every {captureInterval/1000}s\nVersion: {engine.Version}";
                });
            }
            catch (Exception ex)
            {
                Log($"InitializeTesseract error: {ex.Message}");
                UpdateStatus($"Error: {ex.Message}");
            }
        }
        
        private void OnTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!isInitialized || engine == null) return;
            CaptureAndLog();
        }
        
        private void CaptureAndLog()
        {
            try
            {
                Log("Auto capture started");
                
                var screen = Screen.PrimaryScreen;
                if (screen == null) return;

                int width = Math.Min(screen.Bounds.Width, 3840);
                int height = Math.Min(screen.Bounds.Height, 2160);

                using var bitmap = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                using (var g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, new Size(width, height));
                }

                using var processedBitmap = ImagePreprocessor.Preprocess(bitmap);
                
                var tempPath = Path.Combine(Path.GetTempPath(), $"ocr_{Guid.NewGuid()}.png");
                processedBitmap.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);

                using var img = Pix.LoadFromFile(tempPath);
                using var page = engine!.Process(img);
                
                var text = page.GetText()?.Trim();
                var confidence = page.GetMeanConfidence();

                try { File.Delete(tempPath); } catch { }

                if (!string.IsNullOrWhiteSpace(text))
                {
                    // Save to log
                    OcrLogManager.AddEntry(text, confidence);
                    Log($"OCR captured: {text.Length} chars, {confidence:P} confidence");
                    
                    // Update status (last 50 chars)
                    var preview = text.Length > 50 ? text.Substring(0, 50) + "..." : text;
                    UpdateStatus($"[{DateTime.Now:HH:mm:ss}] Captured: {preview}");
                }
            }
            catch (Exception ex)
            {
                Log($"CaptureAndLog error: {ex.Message}");
            }
        }
        
        private void OnIntervalChanged(object sender, EventArgs e)
        {
            captureInterval = (int)(numInterval.Value * 1000);
            captureTimer.Interval = captureInterval;
            Log($"Interval changed to: {captureInterval}ms");
        }
        
        private void OnViewLogs(object sender, EventArgs e)
        {
            var viewer = new LogViewerForm();
            viewer.Show();
        }
        
        private void OnShowSettings(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Normal;
            ShowInTaskbar = true;
            Show();
            Activate();
        }
        
        private void OnExit(object sender, EventArgs e)
        {
            captureTimer?.Stop();
            captureTimer?.Dispose();
            engine?.Dispose();
            notifyIcon?.Dispose();
            Application.Exit();
        }
        
        private void UpdateStatus(string message)
        {
            if (InvokeRequired)
            {
                Invoke(() => UpdateStatus(message));
                return;
            }
            txtResult.Text = message;
        }
        
        private void Log(string msg)
        {
            var logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wincapture.log");
            var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [MainForm] {msg}";
            try { File.AppendAllText(logPath, line + Environment.NewLine); } catch { }
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Minimize to tray instead of closing
                e.Cancel = true;
                WindowState = FormWindowState.Minimized;
                ShowInTaskbar = false;
                Hide();
            }
            else
            {
                OnExit(null, null);
            }
        }
    }
}

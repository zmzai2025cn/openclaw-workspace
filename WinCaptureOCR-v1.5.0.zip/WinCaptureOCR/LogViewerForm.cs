using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureOCR
{
    /// <summary>
    /// OCR 日志查看窗口
    /// </summary>
    public class LogViewerForm : Form
    {
        private ListView listView;
        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnClear;
        private Button btnRefresh;
        private Label lblCount;
        
        public LogViewerForm()
        {
            Text = "OCR Log Viewer";
            Size = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(600, 400);
            
            CreateControls();
            LoadData();
        }
        
        private void CreateControls()
        {
            // 搜索栏
            var panelTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 40,
                Padding = new Padding(5)
            };
            
            txtSearch = new TextBox
            {
                Location = new Point(5, 8),
                Size = new Size(300, 25),
                PlaceholderText = "Search..."
            };
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) btnSearch.PerformClick(); };
            
            btnSearch = new Button
            {
                Text = "Search",
                Location = new Point(310, 6),
                Size = new Size(80, 28)
            };
            btnSearch.Click += OnSearch;
            
            btnRefresh = new Button
            {
                Text = "Refresh",
                Location = new Point(395, 6),
                Size = new Size(80, 28)
            };
            btnRefresh.Click += (s, e) => LoadData();
            
            btnClear = new Button
            {
                Text = "Clear All",
                Location = new Point(480, 6),
                Size = new Size(80, 28),
                ForeColor = Color.Red
            };
            btnClear.Click += OnClear;
            
            lblCount = new Label
            {
                Location = new Point(570, 10),
                AutoSize = true,
                Text = "0 entries"
            };
            
            panelTop.Controls.Add(txtSearch);
            panelTop.Controls.Add(btnSearch);
            panelTop.Controls.Add(btnRefresh);
            panelTop.Controls.Add(btnClear);
            panelTop.Controls.Add(lblCount);
            
            // ListView
            listView = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                MultiSelect = false
            };
            
            listView.Columns.Add("Time", 150);
            listView.Columns.Add("Confidence", 80);
            listView.Columns.Add("Text", 600);
            
            Controls.Add(listView);
            Controls.Add(panelTop);
        }
        
        private void LoadData()
        {
            listView.Items.Clear();
            var entries = OcrLogManager.GetAllEntries();
            
            foreach (var entry in entries)
            {
                var item = new ListViewItem(entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"));
                item.SubItems.Add($"{entry.Confidence:P0}");
                item.SubItems.Add(entry.Text.Length > 100 ? entry.Text.Substring(0, 100) + "..." : entry.Text);
                item.Tag = entry;
                listView.Items.Add(item);
            }
            
            lblCount.Text = $"{entries.Count} entries";
        }
        
        private void OnSearch(object sender, EventArgs e)
        {
            listView.Items.Clear();
            var entries = OcrLogManager.Search(txtSearch.Text);
            
            foreach (var entry in entries)
            {
                var item = new ListViewItem(entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"));
                item.SubItems.Add($"{entry.Confidence:P0}");
                item.SubItems.Add(entry.Text.Length > 100 ? entry.Text.Substring(0, 100) + "..." : entry.Text);
                item.Tag = entry;
                listView.Items.Add(item);
            }
            
            lblCount.Text = $"{entries.Count} entries (filtered)";
        }
        
        private void OnClear(object sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to clear all OCR logs?",
                "Confirm Clear",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            
            if (result == DialogResult.Yes)
            {
                OcrLogManager.Clear();
                LoadData();
            }
        }
    }
}

# WinCaptureOCR 质量管理要求

## 目的
确保代码质量和一致性。

## 核心原则

### 1. 问题只解决一次
- 遇到的问题 → 记录到 docs/04-COMMON-ISSUES.md
- 下次遇到同样问题 → 直接查文档

### 2. 代码规范
- 所有异常必须捕获
- 资源必须正确释放（using/finally）
- 添加详细调试日志
- 版本号同步更新（csproj + Program.cs）

### 3. 文档同步
- 代码变更 → 更新相关文档
- 新增问题 → 记录到 04-COMMON-ISSUES.md
- 功能更新 → 更新 README.md 版本历史

### 4. 发布标准
- 编译 0 错误 0 警告
- 功能测试通过
- 文档已更新
- 版本号一致

## 依赖管理

### Tesseract 依赖链
```
WinCaptureOCR.exe
├── Tesseract.dll (C# wrapper)
├── Tesseract.Drawing.dll
├── leptonica-1.82.0.dll (native x64)
├── tesseract50.dll (native x64)
└── tessdata/chi_sim.traineddata
```

### 版本锁定
| 组件 | 版本 |
|------|------|
| .NET | 6.0.x |
| Tesseract | 5.2.0 |
| Platform | x64 |

## 检查清单
见 docs/06-CHECKLIST.md

# 编译流程分析

## 目的
理解编译全流程，确保可重复构建。

## 源文件结构
```
WinCaptureOCR/
├── WinCaptureOCR.csproj      # 项目配置
├── Program.cs                 # 主程序（UI + OCR 调用）
└── ImagePreprocessor.cs       # 图像预处理
```

## 编译依赖链

### NuGet 包
```
Tesseract 5.2.0
└── Tesseract.Drawing 5.2.0
    └── leptonica-1.82.0.dll (native)
    └── tesseract50.dll (native)
```

### 编译输出
```
bin/Release/net6.0-windows/
├── WinCaptureOCR.exe          # 入口程序
├── WinCaptureOCR.dll          # 主程序
├── Tesseract.dll              # OCR 包装器
├── x64/
│   ├── leptonica-1.82.0.dll   # 图像处理
│   └── tesseract50.dll        # OCR 引擎
└── tessdata/                  # 语言包（运行时复制）
    └── chi_sim.traineddata
```

## 编译步骤

### 1. 还原
```bash
dotnet restore
```
下载 NuGet 包及其依赖。

### 2. 编译
```bash
dotnet build -c Release
```
1. 编译 C# 代码为 IL
2. 生成 WinCaptureOCR.dll
3. 复制 NuGet 包 DLL
4. 复制 native DLL (x64/)

### 3. 发布（可选）
```bash
dotnet publish -c Release -r win-x64
```
生成独立部署包。

## 关键配置

### csproj 关键项
```xml
<PlatformTarget>x64</PlatformTarget>          <!-- 强制 x64 -->
<NoWarn>CS8618;...</NoWarn>                    <!-- 禁用已知警告 -->
<Version>1.2.1</Version>                        <!-- 版本号 -->
```

### 隐式编译
SDK 自动包含项目目录下所有 `.cs` 文件，**不需要**显式指定：
```xml
<!-- 不需要 -->
<Compile Include="ImagePreprocessor.cs" />
```

## 常见问题

### 类型冲突
`ImageFormat` 在 `System.Drawing.Imaging` 和 `Tesseract` 中都有定义。

**解决**：使用完整命名空间
```csharp
bitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png);
```

### 警告处理
已知 nullable 警告已禁用：
```xml
<NoWarn>CS8618;CS8600;CS8602;CS8604</NoWarn>
```

## 验证编译

```powershell
# 清理并重新编译
Remove-Item -Recurse bin, obj
dotnet restore
dotnet build -c Release

# 检查输出
Test-Path bin\Release\net6.0-windows\WinCaptureOCR.exe
Test-Path bin\Release\net6.0-windows\x64\leptonica-1.82.0.dll
```

## 版本历史

| 版本 | 编译变更 |
|------|----------|
| v1.0 | 初始版本 |
| v1.1 | 添加调试日志 |
| v1.2 | 添加 ImagePreprocessor.cs |
| v1.2.1 | 修复 Compile 重复包含问题 |
| v1.3.0 | 启用 AllowUnsafeBlocks 优化性能 |

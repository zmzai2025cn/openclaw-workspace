# WinCapture OCR v1.5.0

## 最新版本 v1.5.0

### 新增功能
- **系统托盘**：最小化到托盘，后台运行
- **自动截屏**：每 10 秒自动截屏 OCR
- **OCR 日志**：查看历史识别结果

### 使用方式
1. 启动后自动最小化到托盘
2. 每 10 秒自动截屏识别
3. 双击托盘图标查看日志
4. 右键托盘图标打开设置

### 设置选项
- 调整截屏间隔（5-300 秒）
- 手动触发截屏
- 查看/搜索/清空 OCR 日志

## 系统要求
- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)

## 快速开始
```powershell
.\scripts\setup.ps1
dotnet run
```

## 语言包下载
- 中文：https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata

## 历史版本
- v1.5.0 - 托盘、定时截屏、日志查看
- v1.3.0 - 性能优化
- v1.2.0 - 图像预处理
- v1.1.0 - 调试日志

using System;
using System.IO;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    /// <summary>
    /// 程序入口
    /// </summary>
    internal static class Program
    {
        private static readonly string LogPath;

        static Program()
        {
            // 初始化日志路径
            string logDir;
            try
            {
                var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (!string.IsNullOrEmpty(localAppData))
                {
                    logDir = Path.Combine(localAppData, "WinCaptureMVP");
                }
                else
                {
                    logDir = AppContext.BaseDirectory;
                }
            }
            catch
            {
                logDir = AppContext.BaseDirectory;
            }
            
            LogPath = Path.Combine(logDir, "app_log.txt");
        }

        /// <summary>
        /// 写入日志
        /// </summary>
        private static void Log(string message)
        {
            try
            {
                var dir = Path.GetDirectoryName(LogPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                File.AppendAllText(LogPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}{Environment.NewLine}");
            }
            catch { }
        }

        [STAThread]
        private static void Main()
        {
            Log("==============================================");
            Log("应用程序启动");

            // 检查是否已有实例在运行
            if (IsAlreadyRunning())
            {
                Log("检测到已有实例在运行，退出");
                MessageBox.Show("采集端已在运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                // 初始化 Windows 窗体应用程序
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Log("UI 框架初始化完成");

                // 加载配置
                Config.UserConfig config;
                try
                {
                    config = Config.UserConfig.Load();
                    Log($"配置加载完成，用户ID: {config.UserId ?? "(未设置)"}");
                }
                catch (Exception ex)
                {
                    Log($"配置加载失败: {ex.Message}，使用默认配置");
                    config = new Config.UserConfig();
                }

                // 首次运行显示配置界面
                if (string.IsNullOrWhiteSpace(config.UserId))
                {
                    Log("首次运行，显示配置界面");
                    using var form = new UI.ConfigForm(config);
                    var result = form.ShowDialog();
                    if (result != DialogResult.OK)
                    {
                        Log("用户取消配置，退出程序");
                        return;
                    }
                    Log("配置完成");
                }

                // 再次检查配置是否有效
                if (string.IsNullOrWhiteSpace(config.UserId))
                {
                    Log("错误: 用户ID仍为空");
                    MessageBox.Show("配置无效，请重新运行程序", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 创建采集引擎
                CaptureEngine engine;
                try
                {
                    Log("正在创建采集引擎...");
                    engine = new CaptureEngine(config);
                    Log("采集引擎创建成功");
                }
                catch (Exception ex)
                {
                    Log($"创建采集引擎失败: {ex.Message}");
                    Log($"堆栈跟踪: {ex.StackTrace}");
                    MessageBox.Show($"初始化失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 创建托盘图标
                UI.TrayIcon tray;
                try
                {
                    Log("正在创建托盘图标...");
                    tray = new UI.TrayIcon(engine);
                    Log("托盘图标创建成功");
                }
                catch (Exception ex)
                {
                    Log($"创建托盘图标失败: {ex.Message}");
                    engine.Dispose();
                    MessageBox.Show($"初始化失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 启动引擎
                try
                {
                    Log("正在启动采集引擎...");
                    engine.Start();
                    Log("采集引擎已启动");
                }
                catch (Exception ex)
                {
                    Log($"启动采集引擎失败: {ex.Message}");
                    tray.Dispose();
                    engine.Dispose();
                    MessageBox.Show($"启动失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 注册退出事件
                Application.ApplicationExit += (s, e) =>
                {
                    Log("应用程序正在退出...");
                    try { tray.Dispose(); } catch { }
                    try { engine.Dispose(); } catch { }
                    Log("资源已清理");
                    Log("==============================================");
                };

                Log("进入主消息循环");
                Application.Run();
            }
            catch (Exception ex)
            {
                var errorMsg = $"程序遇到致命错误: {ex.Message}";
                Log(errorMsg);
                Log($"堆栈跟踪: {ex.StackTrace}");
                
                try
                {
                    MessageBox.Show(errorMsg, "致命错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
            }
        }

        /// <summary>
        /// 检查是否已有实例在运行
        /// </summary>
        private static bool IsAlreadyRunning()
        {
            const string MutexName = "WinCaptureMVP_SingleInstance";
            try
            {
                // 尝试打开已存在的互斥体
                using (var mutex = System.Threading.Mutex.OpenExisting(MutexName))
                {
                    // 如果成功打开，说明已有实例在运行
                    return true;
                }
            }
            catch (System.Threading.WaitHandleCannotBeOpenedException)
            {
                // 互斥体不存在，创建新的
                try
                {
                    var mutex = new System.Threading.Mutex(true, MutexName);
                    // 注意：这里不释放互斥体，保持锁定直到程序退出
                    return false;
                }
                catch
                {
                    // 创建失败，假设已有实例
                    return true;
                }
            }
            catch
            {
                // 其他错误，假设已有实例
                return true;
            }
        }
    }
}

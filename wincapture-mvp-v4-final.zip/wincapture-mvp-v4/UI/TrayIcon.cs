using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public sealed class TrayIcon : IDisposable
    {
        private readonly CaptureEngine _engine;
        private NotifyIcon? _notifyIcon;
        private ContextMenuStrip? _contextMenu;
        private ToolStripMenuItem? _statusItem;
        private ToolStripMenuItem? _pauseItem;
        private bool _disposed;

        public TrayIcon(CaptureEngine engine)
        {
            _engine = engine ?? throw new ArgumentNullException(nameof(engine));
            Initialize();
        }

        private void Initialize()
        {
            _notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "WinCapture MVP",
                Visible = true
            };

            _contextMenu = new ContextMenuStrip();
            
            _statusItem = new ToolStripMenuItem("状态: 运行中") { Enabled = false };
            _contextMenu.Items.Add(_statusItem);
            _contextMenu.Items.Add(new ToolStripSeparator());
            
            _pauseItem = new ToolStripMenuItem("暂停采集", null, OnPauseClick);
            _contextMenu.Items.Add(_pauseItem);
            _contextMenu.Items.Add(new ToolStripMenuItem("查看今日记录", null, OnViewClick));
            _contextMenu.Items.Add(new ToolStripMenuItem("生成日报", null, OnReportClick));
            _contextMenu.Items.Add(new ToolStripSeparator());
            _contextMenu.Items.Add(new ToolStripMenuItem("退出", null, OnExitClick));

            _notifyIcon.ContextMenuStrip = _contextMenu;
            _notifyIcon.DoubleClick += OnViewClick;
            _contextMenu.Opening += (s, e) => UpdateStatus();
        }

        private void UpdateStatus()
        {
            if (_statusItem == null || _pauseItem == null || _notifyIcon == null) 
                return;

            if (_engine.IsPaused)
            {
                _statusItem.Text = "状态: 已暂停";
                _pauseItem.Text = "恢复采集";
                _notifyIcon.Text = "WinCapture MVP (已暂停)";
            }
            else
            {
                _statusItem.Text = "状态: 运行中";
                _pauseItem.Text = "暂停采集";
                _notifyIcon.Text = "WinCapture MVP";
            }
        }

        private void OnPauseClick(object? sender, EventArgs e)
        {
            if (_engine.IsPaused)
                _engine.Resume();
            else
                _engine.Pause();
            UpdateStatus();
        }

        private void OnViewClick(object? sender, EventArgs e)
        {
            var records = _engine.GetTodayRecords();
            using var form = new TimelineForm(records);
            form.ShowDialog();
        }

        private void OnReportClick(object? sender, EventArgs e)
        {
            var report = _engine.GenerateDailyReport();
            MessageBox.Show(report.Summary, "今日工作日报", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OnExitClick(object? sender, EventArgs e)
        {
            _notifyIcon?.Hide();
            Application.Exit();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            
            _notifyIcon?.Dispose();
            _contextMenu?.Dispose();
        }
    }
}

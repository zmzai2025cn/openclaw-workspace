using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            if (IsAlreadyRunning())
            {
                MessageBox.Show("采集端已在运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var config = Config.UserConfig.Load();
            
            if (string.IsNullOrEmpty(config.UserId))
            {
                using var form = new UI.ConfigForm(config);
                if (form.ShowDialog() != DialogResult.OK)
                {
                    return;
                }
            }

            using var engine = new CaptureEngine(config);
            using var tray = new UI.TrayIcon(engine);
            
            engine.Start();

            Application.ApplicationExit += (s, e) =>
            {
                engine.Dispose();
                tray.Dispose();
            };

            Application.Run();
        }

        private static bool IsAlreadyRunning()
        {
            const string MutexName = "WinCaptureMVP_SingleInstance";
            try
            {
                System.Threading.Mutex.OpenExisting(MutexName);
                return true;
            }
            catch
            {
                new System.Threading.Mutex(true, MutexName);
                return false;
            }
        }
    }
}

using System;
using System.Linq;
using System.Reflection;

class Program
{
    static void Main()
    {
        try
        {
            // 加载 PaddleOCRSharp 程序集
            var assembly = Assembly.LoadFrom(@"C:\Users\earsz\.nuget\packages\paddleocrsharp\4.1.0\lib\net6.0\PaddleOCRSharp.dll");
            
            // 查找 PaddleOCREngine 类型
            var engineType = assembly.GetTypes().FirstOrDefault(t => t.Name == "PaddleOCREngine");
            
            if (engineType == null)
            {
                Console.WriteLine("PaddleOCREngine 类型未找到");
                return;
            }
            
            Console.WriteLine("=== PaddleOCREngine 构造函数 ===");
            foreach (var ctor in engineType.GetConstructors())
            {
                var parameters = string.Join(", ", ctor.GetParameters().Select(p => $"{p.ParameterType.Name} {p.Name}"));
                Console.WriteLine($"PaddleOCREngine({parameters})");
            }
            
            Console.WriteLine("\n=== PaddleOCREngine 公共方法 ===");
            foreach (var method in engineType.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly))
            {
                var parameters = string.Join(", ", method.GetParameters().Select(p => $"{p.ParameterType.Name} {p.Name}"));
                Console.WriteLine($"{method.ReturnType.Name} {method.Name}({parameters})");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"错误: {ex.Message}");
        }
    }
}

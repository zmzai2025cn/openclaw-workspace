using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    public class CaptureEngine : IDisposable
    {
        private readonly Config.UserConfig _config;
        private readonly Triggers.WindowSwitchTrigger _windowTrigger;
        private readonly Triggers.IntervalTrigger _intervalTrigger;
        private readonly Storage.WorkLogStorage _storage;
        private bool _isRunning;
        private bool _isPaused;

        public bool IsRunning => _isRunning;
        public bool IsPaused => _isPaused;

        public CaptureEngine(Config.UserConfig config)
        {
            _config = config;
            _storage = new Storage.WorkLogStorage(config);
            _windowTrigger = new Triggers.WindowSwitchTrigger(OnWindowSwitch);
            _intervalTrigger = new Triggers.IntervalTrigger(OnIntervalTrigger);
        }

        public void Start()
        {
            if (_isRunning) return;
            
            _isRunning = true;
            _windowTrigger.Start();
            _intervalTrigger.Start();
        }

        public void Stop()
        {
            _isRunning = false;
            _windowTrigger.Stop();
            _intervalTrigger.Stop();
        }

        public void Pause()
        {
            _isPaused = true;
            _windowTrigger.Pause();
            _intervalTrigger.Pause();
        }

        public void Resume()
        {
            _isPaused = false;
            _windowTrigger.Resume();
            _intervalTrigger.Resume();
        }

        private void OnWindowSwitch(string appName, string windowTitle)
        {
            if (_isPaused) return;
            RecordActivity(appName, windowTitle, "window_switch");
        }

        private void OnIntervalTrigger()
        {
            if (_isPaused) return;
            var windowInfo = Utils.WindowHelper.GetActiveWindowInfo();
            RecordActivity(windowInfo.AppName, windowInfo.Title, "interval");
        }

        private void RecordActivity(string appName, string windowTitle, string triggerType)
        {
            try
            {
                // 应用过滤
                if (!Sanitizer.AppFilter.IsAllowed(appName, _config.WhiteList))
                {
                    return;
                }

                // 截图
                using (var screenshot = Utils.ScreenCapture.CaptureScreen())
                {
                    if (screenshot == null) return;

                    // OCR 识别文字
                    string ocrText = "";
                    try
                    {
                        ocrText = Utils.OcrEngine.Recognize(screenshot);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"OCR 失败: {ex.Message}");
                    }

                    // 生成缩略图
                    using (var thumbnail = Utils.ImageHelper.CreateThumbnail(screenshot, 320, 180))
                    {
                        string thumbnailBase64 = Utils.ImageHelper.ToBase64(thumbnail);

                        // 保存记录
                        var record = new WorkRecord
                        {
                            Timestamp = DateTime.Now,
                            AppName = appName,
                            WindowTitle = windowTitle,
                            OcrText = ocrText ?? "",
                            ThumbnailBase64 = thumbnailBase64,
                            TriggerType = triggerType
                        };

                        _storage.Save(record);
                        Console.WriteLine($"记录: {appName} - {windowTitle}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"记录失败: {ex.Message}");
            }
        }

        public List<WorkRecord> GetTodayRecords()
        {
            return _storage.GetRecords(DateTime.Now.Date, DateTime.Now.Date.AddDays(1));
        }

        public DailyReport GenerateDailyReport()
        {
            return _storage.GenerateDailyReport(DateTime.Now.Date);
        }

        public void Dispose()
        {
            Stop();
            _storage?.Dispose();
        }
    }

    public class WorkRecord
    {
        public long Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string AppName { get; set; } = "";
        public string WindowTitle { get; set; } = "";
        public string OcrText { get; set; } = "";
        public string ThumbnailBase64 { get; set; } = "";
        public string TriggerType { get; set; } = "";
    }

    public class DailyReport
    {
        public DateTime Date { get; set; }
        public int TotalRecords { get; set; }
        public TimeSpan TotalWorkTime { get; set; }
        public List<AppUsage> AppUsages { get; set; } = new();
        public string Summary { get; set; } = "";
    }

    public class AppUsage
    {
        public string AppName { get; set; } = "";
        public TimeSpan Duration { get; set; }
        public int RecordCount { get; set; }
    }
}
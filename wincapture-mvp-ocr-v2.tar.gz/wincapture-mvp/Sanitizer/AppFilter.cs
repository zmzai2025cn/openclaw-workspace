using System;
using System.Collections.Generic;
using System.Linq;

namespace WinCaptureMVP.Sanitizer
{
    public static class AppFilter
    {
        private static readonly HashSet<string> DefaultWhiteList = new HashSet<string>
        {
            "chrome", "msedge", "firefox",
            "code", "devenv", "rider",
            "outlook", "foxmail",
            "wechat", "dingtalk", "feishu", "qq",
            "notepad", "notepad++", "sublime_text",
            "word", "excel", "powerpoint",
            "cmd", "powershell", "wt",
            "explorer"
        };

        public static bool IsAllowed(string appName, List<string> customWhiteList)
        {
            if (string.IsNullOrEmpty(appName)) return false;

            // DEBUG 模式：白名单包含 "*" 允许所有
            if (customWhiteList?.Contains("*") == true)
                return true;

            var lowerName = appName.ToLowerInvariant();

            // 使用自定义白名单或默认白名单
            var whiteList = customWhiteList?.Count > 0 ? customWhiteList : DefaultWhiteList.ToList();
            
            return whiteList.Any(w => lowerName.Contains(w.ToLowerInvariant()));
        }
    }
}
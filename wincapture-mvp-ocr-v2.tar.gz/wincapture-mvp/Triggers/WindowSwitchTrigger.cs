using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class WindowSwitchTrigger : ITrigger
    {
        private readonly Action<string, string> _callback;
        private IntPtr _lastHwnd;
        private System.Threading.Timer? _timer;
        private bool _isPaused;

        public WindowSwitchTrigger(Action<string, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _timer = new Timer(CheckWindow, null, 0, 500);
        }

        public void Stop()
        {
            _timer?.Dispose();
            _timer = null;
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void CheckWindow(object? state)
        {
            if (_isPaused) return;

            var currentHwnd = GetForegroundWindow();
            if (currentHwnd != _lastHwnd)
            {
                _lastHwnd = currentHwnd;
                var title = GetWindowTitle(currentHwnd);
                var appName = GetAppName(currentHwnd);
                _callback?.Invoke(appName, title);
            }
        }

        private string GetWindowTitle(IntPtr hwnd)
        {
            var sb = new StringBuilder(256);
            int length = GetWindowText(hwnd, sb, sb.Capacity);
            return length > 0 ? sb.ToString() : "Unknown";
        }

        private string GetAppName(IntPtr hwnd)
        {
            try
            {
                GetWindowThreadProcessId(hwnd, out uint pid);
                var process = System.Diagnostics.Process.GetProcessById((int)pid);
                return process.ProcessName;
            }
            catch
            {
                return "Unknown";
            }
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    }
}
using System.Drawing;

namespace WinCaptureMVP.Utils
{
    public static class ImageDiff
    {
        public static double CalculateDiff(Bitmap img1, Bitmap img2)
        {
            if (img1 == null || img2 == null) return 1.0;
            if (img1.Size != img2.Size) return 1.0;

            int width = img1.Width;
            int height = img1.Height;
            
            // 防止整数溢出，使用 long
            long diffPixels = 0;
            long totalPixels = width * height;

            // 采样检查（提高性能）
            int step = 10; // 每10像素采样一次

            for (int y = 0; y < height; y += step)
            {
                for (int x = 0; x < width; x += step)
                {
                    var p1 = img1.GetPixel(x, y);
                    var p2 = img2.GetPixel(x, y);

                    // 计算颜色差异
                    int diff = System.Math.Abs(p1.R - p2.R) +
                               System.Math.Abs(p1.G - p2.G) +
                               System.Math.Abs(p1.B - p2.B);

                    if (diff > 30) // 阈值30
                    {
                        diffPixels++;
                    }
                }
            }

            long sampledPixels = totalPixels / (step * step);
            return sampledPixels > 0 ? (double)diffPixels / sampledPixels : 0.0;
        }
    }
}
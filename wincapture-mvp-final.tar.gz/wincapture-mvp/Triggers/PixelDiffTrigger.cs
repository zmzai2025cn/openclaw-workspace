using System;
using System.Drawing;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class PixelDiffTrigger : ITrigger
    {
        private readonly Action<TriggerType, string> _callback;
        private System.Threading.Timer _timer;
        private Bitmap _lastScreenshot;
        private readonly object _lockObj = new object();  // 添加锁对象
        private bool _isPaused;
        private DateTime _lastTriggerTime;
        private readonly TimeSpan _minInterval = TimeSpan.FromSeconds(5); // 防抖 5s

        public PixelDiffTrigger(Action<TriggerType, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            lock (_lockObj)
            {
                _lastScreenshot?.Dispose();
                _lastScreenshot = Utils.ScreenCapture.CaptureScreen();
            }
            _timer = new Timer(CheckDiff, null, 1000, 1000); // 每秒检查
        }

        public void Stop()
        {
            _timer?.Dispose();
            lock (_lockObj)
            {
                _lastScreenshot?.Dispose();
                _lastScreenshot = null;
            }
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void CheckDiff(object state)
        {
            if (_isPaused) return;

            // 防抖检查
            if (DateTime.Now - _lastTriggerTime < _minInterval) return;

            Bitmap current = null;
            Bitmap lastScreenshotCopy = null;

            try
            {
                current = Utils.ScreenCapture.CaptureScreen();
                if (current == null) return;

                lock (_lockObj)
                {
                    if (_lastScreenshot == null)
                    {
                        _lastScreenshot = current;
                        return;
                    }
                    // 创建副本用于比较，避免多线程问题
                    lastScreenshotCopy = new Bitmap(_lastScreenshot);
                }

                var diff = Utils.ImageDiff.CalculateDiff(lastScreenshotCopy, current);

                if (diff > 0.15) // 变化率 > 15%
                {
                    _lastTriggerTime = DateTime.Now;
                    _callback?.Invoke(TriggerType.PixelDiff, $"像素变化: {diff:P}");
                }

                // 更新基准图
                lock (_lockObj)
                {
                    _lastScreenshot?.Dispose();
                    _lastScreenshot = current;
                    current = null; // 标记为已转移所有权
                }
            }
            catch
            {
                // 异常时释放 current
                current?.Dispose();
            }
            finally
            {
                lastScreenshotCopy?.Dispose();
            }
        }
    }
}
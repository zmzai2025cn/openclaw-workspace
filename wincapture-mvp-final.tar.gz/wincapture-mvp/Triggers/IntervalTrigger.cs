using System;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class IntervalTrigger : ITrigger
    {
        private readonly Action<TriggerType, string> _callback;
        private System.Threading.Timer _timer;
        private bool _isPaused;
        private int _isProcessing;  // 防止重入
        private readonly int _intervalMs = 30000; // 30 秒

        public IntervalTrigger(Action<TriggerType, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _timer = new Timer(OnInterval, null, _intervalMs, _intervalMs);
        }

        public void Stop()
        {
            _timer?.Dispose();
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void OnInterval(object state)
        {
            if (_isPaused) return;
            
            // 防止重入
            if (Interlocked.CompareExchange(ref _isProcessing, 1, 0) == 1)
                return;
            
            try
            {
                _callback?.Invoke(TriggerType.Interval, "定时兜底");
            }
            finally
            {
                _isProcessing = 0;
            }
        }
    }
}
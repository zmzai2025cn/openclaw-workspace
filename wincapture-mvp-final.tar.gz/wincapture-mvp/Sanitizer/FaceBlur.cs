using System.Drawing;
using System.Drawing.Drawing2D;

namespace WinCaptureMVP.Sanitizer
{
    public static class FaceBlur
    {
        public static Bitmap Apply(Bitmap image)
        {
            // MVP 简化版：使用高斯模糊效果模糊图片上部 1/3（常见人脸位置）
            var result = new Bitmap(image);
            
            // 定义模糊区域（上部 1/3）
            var blurHeight = image.Height / 3;
            var blurRect = new Rectangle(0, 0, image.Width, blurHeight);
            
            using (var graphics = Graphics.FromImage(result))
            {
                // 设置高质量模糊
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                
                // 创建缩小再放大的效果来模拟模糊
                using (var tempBitmap = new Bitmap(image.Width / 10, blurHeight / 10))
                {
                    using (var tempGraphics = Graphics.FromImage(tempBitmap))
                    {
                        tempGraphics.DrawImage(image, 
                            new Rectangle(0, 0, tempBitmap.Width, tempBitmap.Height),
                            blurRect, 
                            GraphicsUnit.Pixel);
                    }
                    
                    // 放大回原始大小（产生模糊效果）
                    graphics.DrawImage(tempBitmap, blurRect);
                }
            }
            
            return result;
        }
    }
}
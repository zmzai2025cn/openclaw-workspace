using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    public class CaptureEngine : IDisposable
    {
        private readonly Config.UserConfig _config;
        private readonly Triggers.WindowSwitchTrigger _windowTrigger;
        private readonly Triggers.PixelDiffTrigger _pixelTrigger;
        private readonly Triggers.IntervalTrigger _intervalTrigger;
        private readonly Storage.UploadQueue _uploadQueue;
        private bool _isRunning;
        private bool _isPaused;

        public bool IsRunning => _isRunning;
        public bool IsPaused => _isPaused;

        public CaptureEngine(Config.UserConfig config)
        {
            _config = config;
            _uploadQueue = new Storage.UploadQueue(config);
            _windowTrigger = new Triggers.WindowSwitchTrigger(OnTrigger);
            _pixelTrigger = new Triggers.PixelDiffTrigger(OnTrigger);
            _intervalTrigger = new Triggers.IntervalTrigger(OnTrigger);
        }

        public void Start()
        {
            if (_isRunning) return;
            
            _isRunning = true;
            _uploadQueue.Start();
            _windowTrigger.Start();
            _pixelTrigger.Start();
            _intervalTrigger.Start();
        }

        public void Stop()
        {
            _isRunning = false;
            _windowTrigger.Stop();
            _pixelTrigger.Stop();
            _intervalTrigger.Stop();
            _uploadQueue.Stop();
        }

        public void Pause()
        {
            _isPaused = true;
            _windowTrigger.Pause();
            _pixelTrigger.Pause();
            _intervalTrigger.Pause();
        }

        public void Resume()
        {
            _isPaused = false;
            _windowTrigger.Resume();
            _pixelTrigger.Resume();
            _intervalTrigger.Resume();
        }

        private void OnTrigger(TriggerType type, string reason)
        {
            if (_isPaused) return;

            Bitmap screenshot = null;
            try
            {
                // 截图
                screenshot = Utils.ScreenCapture.CaptureScreen();
                if (screenshot == null)
                {
                    Console.WriteLine("截图失败: 返回 null");
                    return;
                }
                
                // 获取当前窗口信息
                var windowInfo = Utils.WindowHelper.GetActiveWindowInfo();
                
                // 应用过滤
                if (!Sanitizer.AppFilter.IsAllowed(windowInfo.AppName, _config.WhiteList))
                {
                    return;
                }

                // 脱敏处理
                var sanitized = Sanitizer.ImageSanitizer.Sanitize(screenshot, _config);
                
                // 构建数据包
                var packet = new DataPacket
                {
                    Timestamp = DateTime.UtcNow,
                    UserId = _config.UserId,
                    DeviceId = _config.DeviceId,
                    TriggerType = type.ToString(),
                    AppName = windowInfo.AppName,
                    WindowTitle = windowInfo.Title,
                    ImageEncrypted = sanitized.EncryptedImage,
                    TextFeatures = sanitized.TextHash,
                    Metadata = new Dictionary<string, object>
                    {
                        ["ScreenResolution"] = $"{screenshot.Width}x{screenshot.Height}",
                        ["CpuUsage"] = Utils.PerformanceMonitor.GetCpuUsage(),
                        ["MemoryUsage"] = Utils.PerformanceMonitor.GetMemoryUsage()
                    }
                };

                // 加入上传队列
                _uploadQueue.Enqueue(packet);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"采集失败: {ex.Message}");
            }
            finally
            {
                screenshot?.Dispose();
            }
        }

        public void Dispose()
        {
            Stop();
            _uploadQueue?.Dispose();
        }
    }

    public enum TriggerType
    {
        WindowSwitch,
        PixelDiff,
        Interval
    }

    public class DataPacket
    {
        public DateTime Timestamp { get; set; }
        public string UserId { get; set; }
        public string DeviceId { get; set; }
        public string TriggerType { get; set; }
        public string AppName { get; set; }
        public string WindowTitle { get; set; }
        public string ImageEncrypted { get; set; }
        public string TextFeatures { get; set; }
        public object Metadata { get; set; }
    }
}
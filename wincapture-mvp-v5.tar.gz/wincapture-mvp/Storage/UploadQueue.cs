using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;

namespace WinCaptureMVP.Storage
{
    public class UploadQueue : IDisposable
    {
        private readonly Config.UserConfig _config;
        private readonly string _dbPath;
        private SqliteConnection _connection;
        private Timer _uploadTimer;
        private bool _isRunning;
        private readonly object _dbLock = new object();  // 数据库访问锁

        public UploadQueue(Config.UserConfig config)
        {
            _config = config;
            _dbPath = $"{_config.DataDirectory}/queue.db";
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            _connection = new SqliteConnection($"Data Source={_dbPath}");
            _connection.Open();

            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = @"
                    CREATE TABLE IF NOT EXISTS upload_queue (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        data TEXT NOT NULL,
                        retry_count INTEGER DEFAULT 0,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
                    CREATE INDEX IF NOT EXISTS idx_timestamp ON upload_queue(timestamp);
                ";
                cmd.ExecuteNonQuery();
            }
        }

        public void Enqueue(global::WinCaptureMVP.DataPacket packet)
        {
            var json = JsonSerializer.Serialize(packet);
            
            lock (_dbLock)
            {
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.CommandText = "INSERT INTO upload_queue (timestamp, data) VALUES (@ts, @data)";
                    cmd.Parameters.AddWithValue("@ts", packet.Timestamp.ToString("O"));
                    cmd.Parameters.AddWithValue("@data", json);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Start()
        {
            _isRunning = true;
            _uploadTimer = new Timer(ProcessQueue, null, 5000, 5000); // 每5秒处理一次
        }

        public void Stop()
        {
            _isRunning = false;
            _uploadTimer?.Dispose();
        }

        private void ProcessQueue(object state)
        {
            if (!_isRunning) return;

            lock (_dbLock)
            {
                try
                {
                    List<(long, string, int)> items;
                    using (var cmd = _connection.CreateCommand())
                    {
                        cmd.CommandText = "SELECT id, data, retry_count FROM upload_queue ORDER BY id LIMIT 10";
                        
                        items = new List<(long, string, int)>();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                items.Add((reader.GetInt64(0), reader.GetString(1), reader.GetInt32(2)));
                            }
                        }
                    }

                    foreach (var (id, data, retryCount) in items)
                    {
                        if (UploadItem(data))
                        {
                            // 上传成功，删除记录
                            using (var deleteCmd = _connection.CreateCommand())
                            {
                                deleteCmd.CommandText = "DELETE FROM upload_queue WHERE id = @id";
                                deleteCmd.Parameters.AddWithValue("@id", id);
                                deleteCmd.ExecuteNonQuery();
                            }
                        }
                        else if (retryCount < 3)
                        {
                            // 失败，增加重试计数
                            using (var updateCmd = _connection.CreateCommand())
                            {
                                updateCmd.CommandText = "UPDATE upload_queue SET retry_count = retry_count + 1 WHERE id = @id";
                                updateCmd.Parameters.AddWithValue("@id", id);
                                updateCmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            // 超过重试次数，移到死信队列或记录日志
                            Console.WriteLine($"上传失败超过3次: id={id}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"处理队列失败: {ex.Message}");
                }
            }
        }

        private bool UploadItem(string json)
        {
            try
            {
                // MVP 简化版：直接 HTTP POST
                using (var client = new System.Net.Http.HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                    var content = new System.Net.Http.StringContent(json, System.Text.Encoding.UTF8, "application/json");
                    // 使用 GetAwaiter 避免死锁
                    var response = client.PostAsync(_config.ServerUrl, content).ConfigureAwait(false).GetAwaiter().GetResult();
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        public void Dispose()
        {
            Stop();
            _connection?.Close();
            _connection?.Dispose();
        }
    }
}
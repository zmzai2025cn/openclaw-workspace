using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class WindowSwitchTrigger : ITrigger
    {
        private readonly Action<TriggerType, string> _callback;
        private IntPtr _lastHwnd;
        private System.Threading.Timer _timer;
        private bool _isPaused;

        public WindowSwitchTrigger(Action<TriggerType, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _timer = new Timer(CheckWindow, null, 0, 500); // 500ms 检查一次
        }

        public void Stop()
        {
            _timer?.Dispose();
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void CheckWindow(object state)
        {
            if (_isPaused) return;

            var currentHwnd = GetForegroundWindow();
            if (currentHwnd != _lastHwnd)
            {
                _lastHwnd = currentHwnd;
                var title = GetWindowTitle(currentHwnd);
                _callback?.Invoke(TriggerType.WindowSwitch, $"切换到: {title}");
            }
        }

        private string GetWindowTitle(IntPtr hwnd)
        {
            const int nChars = 256;
            var buff = new StringBuilder(nChars);
            return GetWindowText(hwnd, buff, nChars) > 0 ? buff.ToString() : "Unknown";
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    }
}
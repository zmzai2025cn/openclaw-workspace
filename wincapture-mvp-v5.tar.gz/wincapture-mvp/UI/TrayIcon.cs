using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public class TrayIcon : IDisposable
    {
        private readonly CaptureEngine _engine;
        private NotifyIcon _notifyIcon;
        private ContextMenuStrip _contextMenu;

        public TrayIcon(CaptureEngine engine)
        {
            _engine = engine;
            Initialize();
        }

        private void Initialize()
        {
            _notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "WinCapture MVP",
                Visible = true
            };

            _contextMenu = new ContextMenuStrip();
            
            var statusItem = new ToolStripMenuItem("状态: 运行中");
            statusItem.Enabled = false;
            _contextMenu.Items.Add(statusItem);
            
            _contextMenu.Items.Add(new ToolStripSeparator());
            
            var pauseItem = new ToolStripMenuItem("暂停采集", null, OnPauseClick);
            _contextMenu.Items.Add(pauseItem);
            
            var configItem = new ToolStripMenuItem("配置", null, OnConfigClick);
            _contextMenu.Items.Add(configItem);
            
            _contextMenu.Items.Add(new ToolStripSeparator());
            
            var exitItem = new ToolStripMenuItem("退出", null, OnExitClick);
            _contextMenu.Items.Add(exitItem);

            _notifyIcon.ContextMenuStrip = _contextMenu;
            _notifyIcon.DoubleClick += OnDoubleClick;
        }

        private void OnPauseClick(object? sender, EventArgs e)
        {
            if (sender is not ToolStripMenuItem menuItem) return;
            
            if (_engine.IsPaused)
            {
                _engine.Resume();
                menuItem.Text = "暂停采集";
            }
            else
            {
                _engine.Pause();
                menuItem.Text = "恢复采集";
            }
        }

        private void OnConfigClick(object? sender, EventArgs e)
        {
            // 显示配置窗口
            MessageBox.Show("配置功能待实现", "提示");
        }

        private void OnExitClick(object? sender, EventArgs e)
        {
            _notifyIcon.Visible = false;
            Application.Exit();
        }

        private void OnDoubleClick(object? sender, EventArgs e)
        {
            OnConfigClick(sender, e);
        }

        public void Dispose()
        {
            _notifyIcon?.Dispose();
            _contextMenu?.Dispose();
        }
    }
}
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WinCaptureMVP
{
    internal static class Program
    {
        private static readonly string LogPath = Path.Combine(AppContext.BaseDirectory, "app_log.txt");

        private static void Log(string message)
        {
            try
            {
                File.AppendAllText(LogPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}\n");
            }
            catch { }
        }

        [STAThread]
        private static void Main()
        {
            Log("Application starting...");

            if (IsAlreadyRunning())
            {
                Log("Another instance is running");
                MessageBox.Show("采集端已在运行", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Log("UI initialized");

                var config = Config.UserConfig.Load();
                Log($"Config loaded, UserId: {config.UserId}");

                if (string.IsNullOrEmpty(config.UserId))
                {
                    Log("Showing config form");
                    using var form = new UI.ConfigForm(config);
                    if (form.ShowDialog() != DialogResult.OK)
                    {
                        Log("Config form cancelled");
                        return;
                    }
                }

                Log("Creating engine...");
                using var engine = new CaptureEngine(config);
                Log("Creating tray icon...");
                using var tray = new UI.TrayIcon(engine);

                Log("Starting engine...");
                engine.Start();
                Log("Engine started");

                Application.ApplicationExit += (s, e) =>
                {
                    Log("Application exiting...");
                    engine.Dispose();
                    tray.Dispose();
                };

                Log("Running application...");
                Application.Run();
            }
            catch (Exception ex)
            {
                Log($"Fatal error: {ex.Message}");
                Log($"Stack trace: {ex.StackTrace}");
                MessageBox.Show($"程序启动失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool IsAlreadyRunning()
        {
            const string MutexName = "WinCaptureMVP_SingleInstance";
            try
            {
                System.Threading.Mutex.OpenExisting(MutexName);
                return true;
            }
            catch
            {
                new System.Threading.Mutex(true, MutexName);
                return false;
            }
        }
    }
}

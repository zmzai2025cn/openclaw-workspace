# Windows 采集端 MVP 设计文档

## 概述

员工数字孪生生产力协同系统 - Windows 采集端 MVP

- 目标：5000 行有效代码
- 平台：Windows 10/11
- 技术：C# + WinForms + .NET 6
- 输出：单文件 EXE (~15MB)

## 核心功能

### 3 级触发引擎

1. **应用切换触发**
   - 监听窗口切换事件
   - 白名单过滤（仅采集工作应用）
   - 立即截图

2. **像素差分触发**
   - 定时对比屏幕像素
   - 变化率 > 15% 触发
   - 防抖处理（最小间隔 5s）

3. **兜底定时触发**
   - 每 30 秒强制采集
   - 确保不遗漏

### 分层脱敏

| 层级 | 处理 | 说明 |
|------|------|------|
| 图像层 | 人脸模糊 | OpenCV 检测 + 高斯模糊 |
| 文本层 | AES 加密 | 代码/文档内容加密上传 |
| 过滤层 | 黑名单丢弃 | 微信、游戏等非工作应用 |

### 数据流

```
屏幕捕获 → 脱敏处理 → 本地缓存(SQLite) → HTTP上传 → Kimiclaw DB
```

## 模块设计

### 1. 主程序 (Program.cs)
- 单例检查
- 托盘初始化
- 配置加载

### 2. 采集引擎 (CaptureEngine.cs)
- 屏幕截图 (GDI+)
- 3级触发管理
- 性能监控

### 3. 触发器 (Triggers/)
- WindowSwitchTrigger.cs
- PixelDiffTrigger.cs
- IntervalTrigger.cs

### 4. 脱敏模块 (Sanitizer/)
- FaceBlur.cs
- TextEncrypt.cs
- AppFilter.cs

### 5. 存储模块 (Storage/)
- LocalCache.cs (SQLite)
- UploadQueue.cs
- HttpUploader.cs

### 6. UI (UI/)
- TrayIcon.cs
- ConfigForm.cs
- StatusForm.cs

### 7. 配置 (Config/)
- AppSettings.cs
- UserConfig.cs

## 接口定义

### 上传格式

```json
{
  "timestamp": "2024-02-20T10:30:00Z",
  "user_id": "user_001",
  "device_id": "device_001",
  "session_id": "sess_xxx",
  "trigger_type": "window_switch|pixel_diff|interval",
  "app_name": "Visual Studio Code",
  "window_title": "Program.cs - Project",
  "image_encrypted": "base64_aes_encrypted",
  "text_features": "hashed_text_content",
  "metadata": {
    "screen_resolution": "1920x1080",
    "cpu_usage": 15,
    "memory_usage": 256
  }
}
```

## 文件结构

```
WinCaptureMVP/
├── Program.cs                    (100行)
├── CaptureEngine.cs              (300行)
├── Triggers/
│   ├── ITrigger.cs               (20行)
│   ├── WindowSwitchTrigger.cs    (150行)
│   ├── PixelDiffTrigger.cs       (200行)
│   └── IntervalTrigger.cs        (80行)
├── Sanitizer/
│   ├── FaceBlur.cs               (150行)
│   ├── TextEncrypt.cs            (100行)
│   └── AppFilter.cs              (80行)
├── Storage/
│   ├── LocalCache.cs             (200行)
│   ├── UploadQueue.cs            (150行)
│   └── HttpUploader.cs           (100行)
├── UI/
│   ├── TrayIcon.cs               (150行)
│   ├── ConfigForm.cs             (200行)
│   └── StatusForm.cs             (100行)
├── Config/
│   ├── AppSettings.cs            (100行)
│   └── UserConfig.cs             (80行)
└── Utils/
    ├── ScreenCapture.cs          (100行)
    ├── ImageDiff.cs              (150行)
    └── CryptoHelper.cs           (100行)

总计：约 2500 行核心代码 + 配置/异常处理 = 5000 行
```

## 依赖包

```xml
<PackageReference Include="System.Drawing.Common" Version="6.0.0" />
<PackageReference Include="Microsoft.Data.Sqlite" Version="6.0.0" />
<PackageReference Include="OpenCvSharp4" Version="4.6.0" />
<PackageReference Include="Newtonsoft.Json" Version="13.0.1" />
```

## 发布配置

```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
```

## 下一步

1. 创建项目结构
2. 实现核心采集引擎
3. 实现 3 级触发器
4. 实现脱敏模块
5. 实现上传模块
6. UI 界面
7. 集成测试
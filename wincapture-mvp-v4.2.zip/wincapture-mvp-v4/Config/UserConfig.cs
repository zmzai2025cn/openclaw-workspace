using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace WinCaptureMVP.Config
{
    public sealed class UserConfig
    {
        private string? _userId;
        private string? _deviceId;
        private string? _dataDirectory;
        private List<string>? _whiteList;

        [JsonPropertyName("userId")]
        public string UserId 
        { 
            get => _userId ?? string.Empty; 
            set => _userId = value; 
        }
        
        [JsonPropertyName("deviceId")]
        public string DeviceId 
        { 
            get => _deviceId ?? Guid.NewGuid().ToString("N"); 
            set => _deviceId = value; 
        }
        
        [JsonPropertyName("dataDirectory")]
        public string DataDirectory 
        { 
            get => GetSafeDataDirectory(); 
            set => _dataDirectory = value; 
        }
        
        [JsonPropertyName("whiteList")]
        public List<string> WhiteList 
        { 
            get => _whiteList ?? new List<string>(); 
            set => _whiteList = value; 
        }

        private string GetSafeDataDirectory()
        {
            if (!string.IsNullOrEmpty(_dataDirectory))
                return _dataDirectory;
            
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WinCaptureMVP");
        }

        private static string ConfigPath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "WinCaptureMVP",
            "config.json");

        public static UserConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var config = JsonSerializer.Deserialize<UserConfig>(json);
                    if (config != null)
                    {
                        return config;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config load failed: {ex.Message}");
            }
            return new UserConfig();
        }

        public void Save()
        {
            try
            {
                var dir = Path.GetDirectoryName(ConfigPath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                var json = JsonSerializer.Serialize(this, new JsonSerializerOptions 
                { 
                    WriteIndented = true 
                });
                File.WriteAllText(ConfigPath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Config save failed: {ex.Message}");
            }
        }
    }
}

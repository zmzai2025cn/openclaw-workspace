# 依赖分析

## 目的
明确项目依赖，便于故障排查。

## 运行时依赖

### 必需
| 依赖 | 版本 | 检查方法 |
|------|------|----------|
| .NET Runtime | 6.0.x | `dotnet --version` |
| VC++ Redist | 2015-2022 x64 | 注册表检查 |
| chi_sim.traineddata | 5.x | 文件存在性 |

### 可选
| 依赖 | 用途 |
|------|------|
| eng.traineddata | 英文识别 |

## DLL 依赖链

### 托管 DLL
- WinCaptureOCR.dll
- Tesseract.dll
- Tesseract.Drawing.dll

### Native DLL（自动复制）
- x64/leptonica-1.82.0.dll
- x64/tesseract50.dll
- x64/libtiff.dll
- x64/libpng.dll
- x64/libjpeg.dll

## 常见问题

### leptonica 加载失败
**症状**：Failed to initialise tesseract engine  
**原因**：VC++ 运行时缺失  
**解决**：安装 VC++ 2015-2022 x64

### DLL 未找到
**症状**：DllNotFoundException  
**原因**：x86/x64 不匹配  
**解决**：确保 PlatformTarget=x64

### 语言包版本不匹配
**症状**：识别率极低或失败  
**原因**：语言包与 Tesseract 版本不兼容  
**解决**：下载对应版本语言包

# WinCapture OCR v1.3.0

## 最新版本

### v1.3.0 (2026-02-20)
- 性能优化
  - 使用 LockBits 优化图像处理（10-50倍速度提升）
  - 添加线程安全的日志锁
  - 修复跨线程 UI 更新问题
- Bug 修复
  - 移除不存在的 GetWordCount 方法
  - 添加 IsDisposed 检查

### v1.2.1 (2026-02-20)
- 修复 OCR 识别缺字问题
  - 优化 Tesseract 参数
  - 调整二值化阈值

### v1.2.0 (2026-02-20)
- 添加图像预处理提高识别率

### v1.1.0 (2026-02-20)
- 添加调试日志

## 系统要求
- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)

## 快速开始
```powershell
.\scripts\setup.ps1
```

## 语言包下载
- 中文：https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata
- 英文：https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata

## 调试
查看 `wincapture.log` 了解详细执行过程。

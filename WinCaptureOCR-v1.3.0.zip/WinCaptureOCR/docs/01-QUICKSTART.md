# 快速开始指南

## 目标
5分钟内让程序运行起来。

## 步骤

### 1. 环境检查（1分钟）
确保已安装：
- .NET 6.0 SDK：https://dotnet.microsoft.com/download/dotnet/6.0
- VC++ 2015-2022 x64：https://aka.ms/vs/17/release/vc_redist.x64.exe

### 2. 下载语言包（2分钟）
```powershell
# 创建目录
mkdir tessdata

# 下载中文语言包（必须）
Invoke-WebRequest "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata" -OutFile "tessdata/chi_sim.traineddata"

# 下载英文语言包（可选）
Invoke-WebRequest "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata" -OutFile "tessdata/eng.traineddata"
```

### 3. 编译运行（2分钟）
```powershell
# 编译
dotnet build -c Release

# 运行
dotnet run
```

## 一键安装
```powershell
.\scripts\setup.ps1
```

## 常见问题

### "找不到 .NET 6.0"
安装 .NET 6.0 SDK

### "Tesseract 初始化失败"
安装 VC++ 2015-2022 x64 运行时

### "缺少语言包"
下载 chi_sim.traineddata 到 tessdata 目录

## 下一步
- 提高识别率：docs/07-IMPROVE-ACCURACY.md
- 解决问题：docs/04-COMMON-ISSUES.md

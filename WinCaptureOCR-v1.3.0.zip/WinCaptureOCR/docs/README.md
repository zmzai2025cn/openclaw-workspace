# 文档导航

## 快速入口

| 我想... | 看这里 |
|---------|--------|
| 快速运行 | [01-QUICKSTART.md](01-QUICKSTART.md) |
| 解决问题 | [04-COMMON-ISSUES.md](04-COMMON-ISSUES.md) |
| 提高识别率 | [07-IMPROVE-ACCURACY.md](07-IMPROVE-ACCURACY.md) |
| 理解编译 | [08-BUILD-ANALYSIS.md](08-BUILD-ANALYSIS.md) |
| 发布版本 | [06-CHECKLIST.md](06-CHECKLIST.md) |

## 文档目的

### 01-QUICKSTART.md
**目的**：5分钟快速上手  
**读者**：新用户  
**内容**：环境准备、编译运行、常见问题

### 04-COMMON-ISSUES.md
**目的**：问题记录和解决方案  
**读者**：遇到问题的用户  
**内容**：已知问题、原因分析、解决方法

### 06-CHECKLIST.md
**目的**：发布前质量检查  
**读者**：开发者/发布者  
**内容**：检查项、发布流程

### 07-IMPROVE-ACCURACY.md
**目的**：提高 OCR 识别率  
**读者**：需要更高精度的用户  
**内容**：优化方法、参数调整、预期效果

### 08-BUILD-ANALYSIS.md
**目的**：理解编译流程  
**读者**：开发者  
**内容**：依赖关系、编译步骤、配置说明

## 维护原则

1. **问题只解决一次** → 记录到 04-COMMON-ISSUES.md
2. **流程标准化** → 更新 06-CHECKLIST.md
3. **知识可传承** → 技术细节写入对应文档
4. **保持简洁** → 每个文档有明确目的和读者

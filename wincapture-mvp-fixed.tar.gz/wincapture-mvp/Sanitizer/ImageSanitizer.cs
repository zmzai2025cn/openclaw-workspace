using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace WinCaptureMVP.Sanitizer
{
    public static class ImageSanitizer
    {
        public class SanitizeResult
        {
            public string EncryptedImage { get; set; }
            public string TextHash { get; set; }
        }

        public static SanitizeResult Sanitize(Bitmap image, Config.UserConfig config)
        {
            var result = new SanitizeResult();

            // 1. 人脸模糊
            using (var blurred = FaceBlur.Apply(image))
            {
                // 2. 压缩图片
                using (var compressed = CompressImage(blurred, 80))
                {
                    // 3. 加密图片
                    result.EncryptedImage = EncryptImage(compressed, config.EncryptionKey);
                }
            }

            // 4. 提取文本特征（SimHash）
            result.TextHash = ExtractTextHash(image);

            return result;
        }

        private static Bitmap CompressImage(Bitmap source, int quality)
        {
            var ms = new MemoryStream();
            var encoder = GetEncoder(ImageFormat.Jpeg);
            var parameters = new EncoderParameters(1);
            parameters.Param[0] = new EncoderParameter(Encoder.Quality, quality);
            source.Save(ms, encoder, parameters);
            ms.Position = 0;
            return new Bitmap(ms);
        }

        private static ImageCodecInfo GetEncoder(ImageFormat format)
        {
            var codecs = ImageCodecInfo.GetImageDecoders();
            foreach (var codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                    return codec;
            }
            return null;
        }

        private static string EncryptImage(Bitmap image, string key)
        {
            using (var ms = new MemoryStream())
            {
                image.Save(ms, ImageFormat.Jpeg);
                var bytes = ms.ToArray();
                var encrypted = EncryptBytes(bytes, key);
                return Convert.ToBase64String(encrypted);
            }
        }

        private static byte[] EncryptBytes(byte[] data, string key)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = DeriveKey(key);
                aes.IV = new byte[16];
                using (var encryptor = aes.CreateEncryptor())
                {
                    return encryptor.TransformFinalBlock(data, 0, data.Length);
                }
            }
        }

        private static byte[] DeriveKey(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            }
        }

        private static string ExtractTextHash(Bitmap image)
        {
            // 简化版：计算图片感知哈希
            using (var small = new Bitmap(image, new Size(8, 8)))
            {
                var hash = new StringBuilder();
                for (int y = 0; y < 8; y++)
                {
                    for (int x = 0; x < 8; x++)
                    {
                        var pixel = small.GetPixel(x, y);
                        var gray = (pixel.R + pixel.G + pixel.B) / 3;
                        hash.Append(gray > 128 ? "1" : "0");
                    }
                }
                return hash.ToString();
            }
        }
    }
}
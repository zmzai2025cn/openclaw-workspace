using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureMVP.UI
{
    public class TrayIcon : IDisposable
    {
        private readonly CaptureEngine _engine;
        private NotifyIcon _notifyIcon;
        private ContextMenuStrip _contextMenu;
        private ToolStripMenuItem _statusItem;
        private ToolStripMenuItem _pauseItem;

        public TrayIcon(CaptureEngine engine)
        {
            _engine = engine;
            Initialize();
        }

        private void Initialize()
        {
            _notifyIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "WinCapture MVP",
                Visible = true
            };

            _contextMenu = new ContextMenuStrip();
            
            _statusItem = new ToolStripMenuItem("状态: 运行中");
            _statusItem.Enabled = false;
            _contextMenu.Items.Add(_statusItem);
            
            _contextMenu.Items.Add(new ToolStripSeparator());
            
            _pauseItem = new ToolStripMenuItem("暂停采集", null, OnPauseClick);
            _contextMenu.Items.Add(_pauseItem);
            
            var configItem = new ToolStripMenuItem("配置", null, OnConfigClick);
            _contextMenu.Items.Add(configItem);
            
            _contextMenu.Items.Add(new ToolStripSeparator());
            
            var exitItem = new ToolStripMenuItem("退出", null, OnExitClick);
            _contextMenu.Items.Add(exitItem);

            _notifyIcon.ContextMenuStrip = _contextMenu;
            _notifyIcon.DoubleClick += OnDoubleClick;
            
            // 菜单打开时更新状态
            _contextMenu.Opening += (s, e) => UpdateStatus();
        }

        private void UpdateStatus()
        {
            if (_engine.IsPaused)
            {
                _statusItem.Text = "状态: 已暂停";
                _pauseItem.Text = "恢复采集";
                _notifyIcon.Text = "WinCapture MVP (已暂停)";
            }
            else
            {
                _statusItem.Text = "状态: 运行中";
                _pauseItem.Text = "暂停采集";
                _notifyIcon.Text = "WinCapture MVP";
            }
        }

        private void OnPauseClick(object? sender, EventArgs e)
        {
            if (_engine.IsPaused)
            {
                _engine.Resume();
            }
            else
            {
                _engine.Pause();
            }
            UpdateStatus();
        }

        private void OnConfigClick(object? sender, EventArgs e)
        {
            // 显示配置窗口
            using (var form = new ConfigForm(_engine.GetConfig()))
            {
                form.ShowDialog();
            }
        }

        private void OnExitClick(object? sender, EventArgs e)
        {
            _notifyIcon.Visible = false;
            Application.Exit();
        }

        private void OnDoubleClick(object? sender, EventArgs e)
        {
            OnConfigClick(sender, e);
        }

        public void Dispose()
        {
            _notifyIcon?.Dispose();
            _contextMenu?.Dispose();
        }
    }
}
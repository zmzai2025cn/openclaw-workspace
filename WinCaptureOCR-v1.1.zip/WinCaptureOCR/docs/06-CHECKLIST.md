# 发布检查清单

## 发布前必须完成

### 代码检查
- [ ] 编译无警告 (`dotnet build -warnaserror`)
- [ ] 所有异常已捕获
- [ ] 资源释放已确保 (using/finally)
- [ ] 无硬编码路径
- [ ] 版本号已更新

### 依赖检查
- [ ] NuGet 包版本锁定
- [ ] 语言包版本匹配
- [ ] VC++ 运行时要求已记录
- [ ] .NET 版本要求已记录

### 文档检查
- [ ] README.md 已更新
- [ ] 04-COMMON-ISSUES.md 已更新
- [ ] 版本更新日志已添加

### 测试检查
- [ ] 干净环境测试通过
- [ ] 无语言包时错误提示正确
- [ ] 有语言包时功能正常
- [ ] 异常处理测试通过

### 发布检查
- [ ] publish.ps1 测试通过
- [ ] 输出目录结构正确
- [ ] 启动脚本可用
- [ ] 文件大小合理

## 发布流程

```powershell
# 1. 运行检查清单
.\scripts\checklist.ps1

# 2. 编译发布
.\scripts\release.ps1

# 3. 测试发布包
.\scripts\test-release.ps1

# 4. 打包
Compress-Archive -Path publish -DestinationPath WinCaptureOCR-v1.x.zip
```

## 发布后

- [ ] 更新版本号
- [ ] 创建 Git Tag
- [ ] 记录发布日期
- [ ] 通知相关人员

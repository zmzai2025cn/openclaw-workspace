# WinCaptureOCR DLL 依赖分析

## 核心依赖链

### 1. .NET 托管层
| DLL | 来源 | 用途 | 风险 |
|-----|------|------|------|
| Tesseract.dll | NuGet | C# Wrapper | 低 |
| Tesseract.Drawing.dll | NuGet | 图像处理 | 低 |

### 2. Native C++ 层
| DLL | 来源 | 用途 | 风险 | 解决方案 |
|-----|------|------|------|----------|
| tesseract50.dll | NuGet | OCR 引擎 | 中 | 随 NuGet 自动复制 |
| leptonica-1.82.0.dll | NuGet | 图像处理库 | **高** | 需要 VC++ 运行时 |
| libtiff.dll | 间接 | 图像格式 | 低 | 随 leptonica |
| libpng.dll | 间接 | PNG 处理 | 低 | 随 leptonica |
| libjpeg.dll | 间接 | JPEG 处理 | 低 | 随 leptonica |

### 3. 系统运行时
| 组件 | 版本 | 必需 | 检查方法 |
|------|------|------|----------|
| .NET Runtime | 6.0.x | 是 | `dotnet --version` |
| VC++ Redist | 2015-2022 x64 | **是** | 注册表检查 |

## 依赖问题解决方案

### 问题 1: leptonica 加载失败
**症状**: "Failed to initialise tesseract engine"
**原因**: VC++ 运行时缺失
**解决**: 安装 https://aka.ms/vs/17/release/vc_redist.x64.exe

### 问题 2: DLL 未找到
**症状**: "DllNotFoundException"
**原因**: NuGet 未正确复制
**解决**: 检查输出目录 x64/ 子目录

### 问题 3: x86/x64 不匹配
**症状**: "BadImageFormatException"
**原因**: 32位/64位混用
**解决**: 强制 PlatformTarget=x64

## 自动检查脚本

```powershell
# 检查 VC++ 运行时
function Check-VCRedist {
    $keys = @(
        "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"
    )
    foreach ($key in $keys) {
        if (Test-Path $key) { return $true }
    }
    return $false
}

# 检查 .NET 版本
function Check-DotNet {
    try {
        $version = dotnet --version
        return $version.StartsWith("6.0")
    } catch {
        return $false
    }
}

# 检查 DLL 存在
function Check-Dlls($path) {
    $required = @("leptonica-1.82.0.dll", "tesseract50.dll")
    foreach ($dll in $required) {
        if (-not (Test-Path (Join-Path $path $dll))) {
            return $false
        }
    }
    return $true
}
```

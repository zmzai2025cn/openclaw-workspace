# WinCapture OCR v1.6.0

## 🎯 核心特性

### 自动截屏 OCR
- 每 10 秒自动截屏识别文字
- 后台运行，最小化到系统托盘
- 支持调整截屏间隔（3-300 秒）

### 缩略图记录
- 每次截屏保存 320x180 缩略图
- 方便回顾文字出现的场景
- 自动清理旧缩略图（保留 1000 张）

### 日志查看器
- 查看历史 OCR 结果
- 搜索功能
- 显示字符数、置信度、缩略图

## 🚀 快速开始

```powershell
# 1. 解压
# 2. 安装依赖
.\scripts\setup.ps1

# 3. 复制语言包
Copy-Item "chi_sim.traineddata" "tessdata\" -Force

# 4. 运行
dotnet run
```

## 📋 使用说明

1. **启动**：程序自动最小化到托盘
2. **自动识别**：每 10 秒自动截屏 OCR
3. **查看日志**：双击托盘图标
4. **设置**：右键托盘图标 → Settings
5. **退出**：右键托盘图标 → Exit

## 💻 系统要求

- Windows 10/11 (x64)
- .NET 6.0 SDK
- VC++ 2015-2022 Redistributable (x64)
- 4GB+ RAM

## 📥 语言包下载

```powershell
# 中文（必需）
Invoke-WebRequest "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata" -OutFile "tessdata/chi_sim.traineddata"

# 英文（可选）
Invoke-WebRequest "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata" -OutFile "tessdata/eng.traineddata"
```

## 📊 版本历史

| 版本 | 日期 | 特性 |
|------|------|------|
| v1.6.0 | 2026-02-20 | 全面优化、缩略图、稳定性 |
| v1.5.0 | 2026-02-20 | 托盘、定时截屏、日志查看 |
| v1.3.0 | 2026-02-20 | 性能优化 |
| v1.2.0 | 2026-02-20 | 图像预处理 |
| v1.1.0 | 2026-02-20 | 调试日志 |

## 📚 文档导航

| 文档 | 说明 |
|------|------|
| docs/01-QUICKSTART.md | 快速上手 |
| docs/04-COMMON-ISSUES.md | 常见问题 |
| docs/07-IMPROVE-ACCURACY.md | 提高识别率 |
| docs/08-BUILD-ANALYSIS.md | 编译分析 |
| docs/12-LAST-CHECK.md | 质量检查 |

## 🔧 技术栈

- .NET 6 + WinForms
- Tesseract OCR 5.2.0
- LockBits 图像处理
- CSV 日志存储

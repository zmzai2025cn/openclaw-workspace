using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace WinCaptureOCR
{
    /// <summary>
    /// OCR 日志管理器
    /// </summary>
    public static class OcrLogManager
    {
        private static readonly List<OcrLogEntry> Entries = new List<OcrLogEntry>();
        private static readonly object Lock = new object();
        private static readonly string LogFilePath;
        
        static OcrLogManager()
        {
            LogFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ocr_history.csv");
            LoadFromFile();
        }
        
        public static void AddEntry(string text, double confidence, string thumbnailPath)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            
            var entry = new OcrLogEntry
            {
                Timestamp = DateTime.Now,
                Text = text.Trim(),
                Confidence = confidence,
                ThumbnailPath = thumbnailPath,
                CharCount = text.Length
            };
            
            lock (Lock)
            {
                Entries.Insert(0, entry); // Add to beginning
                if (Entries.Count > 1000)
                {
                    // Remove old thumbnails
                    for (int i = 1000; i < Entries.Count; i++)
                    {
                        try
                        {
                            if (!string.IsNullOrEmpty(Entries[i].ThumbnailPath) && File.Exists(Entries[i].ThumbnailPath))
                            {
                                File.Delete(Entries[i].ThumbnailPath);
                            }
                        }
                        catch { }
                    }
                    Entries.RemoveRange(1000, Entries.Count - 1000);
                }
            }
            
            System.Threading.Tasks.Task.Run(() => SaveToFile(entry));
        }
        
        public static List<OcrLogEntry> GetAllEntries()
        {
            lock (Lock)
            {
                return Entries.ToList();
            }
        }
        
        public static void Clear()
        {
            lock (Lock)
            {
                // Delete all thumbnails
                foreach (var entry in Entries)
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(entry.ThumbnailPath) && File.Exists(entry.ThumbnailPath))
                        {
                            File.Delete(entry.ThumbnailPath);
                        }
                    }
                    catch { }
                }
                Entries.Clear();
            }
            try { File.Delete(LogFilePath); } catch { }
        }
        
        public static List<OcrLogEntry> Search(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
                return GetAllEntries();
            
            lock (Lock)
            {
                return Entries.Where(e => 
                    e.Text.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }
        }
        
        private static void SaveToFile(OcrLogEntry entry)
        {
            try
            {
                var line = $"{entry.Timestamp:yyyy-MM-dd HH:mm:ss},{entry.Confidence:F2},{entry.CharCount},\"{entry.Text.Replace("\"", "\"\"")}\",\"{entry.ThumbnailPath}\"";
                File.AppendAllText(LogFilePath, line + Environment.NewLine);
            }
            catch { }
        }
        
        private static void LoadFromFile()
        {
            try
            {
                if (!File.Exists(LogFilePath)) return;
                
                var lines = File.ReadAllLines(LogFilePath);
                foreach (var line in lines)
                {
                    try
                    {
                        var parts = ParseCsvLine(line);
                        if (parts.Length >= 4)
                        {
                            var entry = new OcrLogEntry
                            {
                                Timestamp = DateTime.Parse(parts[0]),
                                Confidence = double.Parse(parts[1]),
                                CharCount = int.Parse(parts[2]),
                                Text = parts[3],
                                ThumbnailPath = parts.Length > 4 ? parts[4] : ""
                            };
                            Entries.Add(entry);
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }
        
        private static string[] ParseCsvLine(string line)
        {
            var result = new List<string>();
            bool inQuotes = false;
            var current = new System.Text.StringBuilder();
            
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                
                if (c == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        current.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    result.Add(current.ToString());
                    current.Clear();
                }
                else
                {
                    current.Append(c);
                }
            }
            
            result.Add(current.ToString());
            return result.ToArray();
        }
    }
    
    public class OcrLogEntry
    {
        public DateTime Timestamp { get; set; }
        public string Text { get; set; } = "";
        public double Confidence { get; set; }
        public string ThumbnailPath { get; set; } = "";
        public int CharCount { get; set; }
    }
}

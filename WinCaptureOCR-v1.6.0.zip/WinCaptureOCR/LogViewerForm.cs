using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinCaptureOCR
{
    /// <summary>
    /// 现代化深色主题日志查看器
    /// </summary>
    public class LogViewerForm : Form
    {
        private ListView? listView;
        private TextBox? txtSearch;
        private PictureBox? picThumbnail;
        private TextBox? txtDetail;
        private Label? lblStatus;
        
        // 配色方案 - 深色主题
        private readonly Color bgDark = Color.FromArgb(30, 30, 35);
        private readonly Color bgMedium = Color.FromArgb(45, 45, 55);
        private readonly Color bgLight = Color.FromArgb(60, 60, 75);
        private readonly Color accentBlue = Color.FromArgb(100, 150, 255);
        private readonly Color textPrimary = Color.FromArgb(240, 240, 245);
        private readonly Color textSecondary = Color.FromArgb(180, 180, 190);
        
        public LogViewerForm()
        {
            Text = "OCR History";
            Size = new Size(1200, 750);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(900, 600);
            BackColor = bgDark;
            Font = new Font("Segoe UI", 9);
            
            CreateControls();
            LoadData();
        }
        
        private void CreateControls()
        {
            // 标题栏
            var lblTitle = new Label
            {
                Text = "📋 OCR History",
                Location = new Point(20, 15),
                Size = new Size(300, 30),
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = textPrimary
            };
            
            // 搜索栏
            var panelSearch = new Panel
            {
                Location = new Point(20, 55),
                Size = new Size(1140, 45),
                BackColor = bgMedium,
                BorderStyle = BorderStyle.None
            };
            
            // 搜索图标
            var lblSearchIcon = new Label
            {
                Text = "🔍",
                Location = new Point(12, 10),
                Size = new Size(25, 25),
                Font = new Font("Segoe UI", 12)
            };
            
            txtSearch = new TextBox
            {
                Location = new Point(45, 10),
                Size = new Size(300, 25),
                BorderStyle = BorderStyle.None,
                BackColor = bgLight,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 10),
                PlaceholderText = "Search text..."
            };
            
            var btnSearch = CreateModernButton("Search", 360, 8, 80);
            btnSearch.Click += (s, e) => LoadData();
            
            var btnRefresh = CreateModernButton("🔄 Refresh", 450, 8, 100);
            btnRefresh.Click += (s, e) => LoadData();
            
            var btnClear = CreateModernButton("🗑 Clear", 950, 8, 100, Color.FromArgb(255, 100, 100));
            btnClear.Click += OnClear;
            
            lblStatus = new Label
            {
                Location = new Point(1070, 14),
                Size = new Size(60, 20),
                ForeColor = textSecondary,
                TextAlign = ContentAlignment.MiddleRight
            };
            
            panelSearch.Controls.Add(lblSearchIcon);
            panelSearch.Controls.Add(txtSearch);
            panelSearch.Controls.Add(btnSearch);
            panelSearch.Controls.Add(btnRefresh);
            panelSearch.Controls.Add(btnClear);
            panelSearch.Controls.Add(lblStatus);
            
            // 主内容区 - 分割面板
            var splitMain = new SplitContainer
            {
                Location = new Point(20, 110),
                Size = new Size(1140, 580),
                Orientation = Orientation.Horizontal,
                SplitterDistance = 380,
                BackColor = bgMedium,
                Panel1MinSize = 200,
                Panel2MinSize = 150
            };
            
            // 上半部分 - 列表
            listView = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = false,
                MultiSelect = false,
                BackColor = bgMedium,
                ForeColor = textPrimary,
                Font = new Font("Segoe UI", 9),
                BorderStyle = BorderStyle.None,
                HeaderStyle = ColumnHeaderStyle.Nonclickable
            };
            
            listView.Columns.Add("Time", 120, HorizontalAlignment.Left);
            listView.Columns.Add("Chars", 60, HorizontalAlignment.Center);
            listView.Columns.Add("Confidence", 80, HorizontalAlignment.Center);
            listView.Columns.Add("Preview", 850, HorizontalAlignment.Left);
            
            // 自定义绘制表头
            listView.OwnerDraw = true;
            listView.DrawColumnHeader += (s, e) =>
            {
                e.Graphics.FillRectangle(new SolidBrush(bgLight), e.Bounds);
                e.Graphics.DrawString(e.Header.Text, new Font("Segoe UI", 9, FontStyle.Bold), 
                    new SolidBrush(textPrimary), e.Bounds, new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center });
            };
            listView.DrawItem += (s, e) =>
            {
                e.DrawDefault = true;
            };
            listView.DrawSubItem += (s, e) =>
            {
                e.DrawDefault = true;
            };
            
            listView.SelectedIndexChanged += OnSelectionChanged;
            
            splitMain.Panel1.Controls.Add(listView);
            
            // 下半部分 - 详情
            var panelDetail = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = bgMedium
            };
            
            // 缩略图卡片
            var panelThumb = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(360, 190),
                BackColor = bgLight,
                BorderStyle = BorderStyle.None
            };
            
            var lblThumbTitle = new Label
            {
                Text = "🖼 Screenshot",
                Location = new Point(10, 8),
                Size = new Size(200, 20),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = textPrimary
            };
            
            picThumbnail = new PictureBox
            {
                Location = new Point(10, 35),
                Size = new Size(340, 145),
                BackColor = bgDark,
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.None
            };
            
            panelThumb.Controls.Add(lblThumbTitle);
            panelThumb.Controls.Add(picThumbnail);
            
            // 详情文本卡片
            var panelText = new Panel
            {
                Location = new Point(375, 0),
                Size = new Size(760, 190),
                BackColor = bgLight,
                BorderStyle = BorderStyle.None
            };
            
            var lblTextTitle = new Label
            {
                Text = "📝 Recognized Text",
                Location = new Point(10, 8),
                Size = new Size(200, 20),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = textPrimary
            };
            
            txtDetail = new TextBox
            {
                Location = new Point(10, 35),
                Size = new Size(740, 145),
                Multiline = true,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 9),
                BackColor = bgDark,
                ForeColor = textPrimary,
                BorderStyle = BorderStyle.None,
                ReadOnly = true
            };
            
            panelText.Controls.Add(lblTextTitle);
            panelText.Controls.Add(txtDetail);
            
            panelDetail.Controls.Add(panelThumb);
            panelDetail.Controls.Add(panelText);
            
            splitMain.Panel2.Controls.Add(panelDetail);
            
            // 添加所有控件
            Controls.Add(lblTitle);
            Controls.Add(panelSearch);
            Controls.Add(splitMain);
        }
        
        private Button CreateModernButton(string text, int x, int y, int width, Color? bgColor = null)
        {
            var btn = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 28),
                FlatStyle = FlatStyle.Flat,
                BackColor = bgColor ?? accentBlue,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = bgColor != null 
                ? Color.FromArgb(bgColor.Value.R + 20, bgColor.Value.G + 20, bgColor.Value.B + 20)
                : Color.FromArgb(120, 170, 255);
            btn.FlatAppearance.MouseDownBackColor = bgColor != null
                ? Color.FromArgb(bgColor.Value.R - 20, bgColor.Value.G - 20, bgColor.Value.B - 20)
                : Color.FromArgb(80, 130, 230);
            return btn;
        }
        
        private void LoadData()
        {
            if (listView == null) return;
            
            listView.Items.Clear();
            var entries = OcrLogManager.Search(txtSearch?.Text ?? "");
            
            foreach (var entry in entries)
            {
                var preview = entry.Text.Length > 60 
                    ? entry.Text.Substring(0, 60).Replace('\n', ' ') + "..." 
                    : entry.Text.Replace('\n', ' ');
                
                var item = new ListViewItem(entry.Timestamp.ToString("MM-dd HH:mm"));
                item.SubItems.Add(entry.CharCount.ToString());
                item.SubItems.Add($"{entry.Confidence:P0}");
                item.SubItems.Add(preview);
                item.Tag = entry;
                item.BackColor = listView.Items.Count % 2 == 0 ? bgMedium : bgDark;
                item.ForeColor = textPrimary;
                listView.Items.Add(item);
            }
            
            if (lblStatus != null)
                lblStatus.Text = $"{entries.Count} items";
        }
        
        private void OnSelectionChanged(object? sender, EventArgs e)
        {
            if (listView?.SelectedItems.Count == 0)
            {
                if (picThumbnail != null) picThumbnail.Image = null;
                if (txtDetail != null) txtDetail.Text = "";
                return;
            }
            
            var entry = listView?.SelectedItems[0].Tag as OcrLogEntry;
            if (entry == null) return;
            
            // Show detail
            if (txtDetail != null)
            {
                txtDetail.Text = $"Time: {entry.Timestamp:yyyy-MM-dd HH:mm:ss}\r\n" +
                                $"Characters: {entry.CharCount}\r\n" +
                                $"Confidence: {entry.Confidence:P}\r\n" +
                                $"\r\n{entry.Text}";
            }
            
            // Show thumbnail with detailed logging
            if (picThumbnail != null)
            {
                try
                {
                    picThumbnail.Image?.Dispose();
                    picThumbnail.Image = null;
                    picThumbnail.BackColor = bgDark;
                    
                    if (string.IsNullOrEmpty(entry.ThumbnailPath))
                    {
                        // No thumbnail
                    }
                    else if (!File.Exists(entry.ThumbnailPath))
                    {
                        // Thumbnail not found
                    }
                    else
                    {
                        using var stream = new FileStream(entry.ThumbnailPath, FileMode.Open, FileAccess.Read, FileShare.Read);
                        picThumbnail.Image = Image.FromStream(stream);
                    }
                }
                catch
                {
                    picThumbnail.Image = null;
                }
            }
        }
        
        private void OnClear(object? sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Clear all OCR history and thumbnails?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            
            if (result == DialogResult.Yes)
            {
                OcrLogManager.Clear();
                picThumbnail?.Image?.Dispose();
                if (picThumbnail != null) picThumbnail.Image = null;
                LoadData();
            }
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            picThumbnail?.Image?.Dispose();
            base.OnFormClosing(e);
        }
    }
}

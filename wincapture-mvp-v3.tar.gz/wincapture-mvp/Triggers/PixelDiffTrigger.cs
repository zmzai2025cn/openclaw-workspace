using System;
using System.Drawing;
using System.Threading;

namespace WinCaptureMVP.Triggers
{
    public class PixelDiffTrigger : ITrigger
    {
        private readonly Action<TriggerType, string> _callback;
        private System.Threading.Timer _timer;
        private Bitmap _lastScreenshot;
        private bool _isPaused;
        private DateTime _lastTriggerTime;
        private readonly TimeSpan _minInterval = TimeSpan.FromSeconds(5); // 防抖 5s

        public PixelDiffTrigger(Action<TriggerType, string> callback)
        {
            _callback = callback;
        }

        public void Start()
        {
            _lastScreenshot = Utils.ScreenCapture.CaptureScreen();
            _timer = new Timer(CheckDiff, null, 1000, 1000); // 每秒检查
        }

        public void Stop()
        {
            _timer?.Dispose();
            _lastScreenshot?.Dispose();
        }

        public void Pause() => _isPaused = true;
        public void Resume() => _isPaused = false;

        private void CheckDiff(object state)
        {
            if (_isPaused) return;

            // 防抖检查
            if (DateTime.Now - _lastTriggerTime < _minInterval) return;

            var current = Utils.ScreenCapture.CaptureScreen();
            try
            {
                var diff = Utils.ImageDiff.CalculateDiff(_lastScreenshot, current);
                
                if (diff > 0.15) // 变化率 > 15%
                {
                    _lastTriggerTime = DateTime.Now;
                    _callback?.Invoke(TriggerType.PixelDiff, $"像素变化: {diff:P}");
                }

                // 更新基准图
                _lastScreenshot?.Dispose();
                _lastScreenshot = current;
            }
            catch
            {
                current?.Dispose();
            }
        }
    }
}